package com.example.MSNotificaciones;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import java.util.List;
import java.util.Optional;
import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
public class PlantillaTest {

    private ProductoRepositoryFake productoRepository;

    @InjectMocks
    private ProductoServiceFake productoService;

    @Test
    void testListarElementos_EnVivo() {
        ProductoFake p1 = new ProductoFake(1L, "---");
        ProductoFake p2 = new ProductoFake(2L, "----");

        List<ProductoFake> listaSimulada = List.of(p1, p2);

        Mockito.when(productoRepository.findAll()).thenReturn(listaSimulada);

        List<ProductoFake> resultado = productoService.obtenerTodos();

        assertNotNull(resultado);
        assertEquals(2, resultado.size());
        assertEquals("---", resultado.get(0).getNombre());
        assertEquals("----", resultado.get(1).getNombre());
    }

    static class ProductoFake {
        private Long id; private String nombre;
        public ProductoFake(Long id, String nombre) { this.id = id; this.nombre = nombre; }
        public Long getId() { return id; } public String getNombre() { return nombre; }
    }
    interface ProductoRepositoryFake { List<ProductoFake> findAll(); }
    static class ProductoServiceFake {
        private ProductoRepositoryFake repo;
        public List<ProductoFake> obtenerTodos() { return repo.findAll(); }
    }
}