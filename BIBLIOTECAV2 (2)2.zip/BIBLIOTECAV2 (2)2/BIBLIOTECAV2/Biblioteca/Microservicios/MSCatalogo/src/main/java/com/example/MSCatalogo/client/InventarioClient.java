package com.example.MSCatalogo.client;

import com.example.MSCatalogo.model.InventarioDTO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;


@Slf4j
@Component
public class InventarioClient {

    @Autowired
    private WebClient.Builder webClientBuilder;

    public int obtenerStock(Long idLibro) {
        try {
            // Llamamos a ms-inventario de forma interna
            InventarioDTO respuesta = webClientBuilder.build()
                    .get()
                    // Si usas Eureka con balanceo de carga, asegúrate de que el nombre coincida (ej: MS-INVENTARIO)
                    .uri("http://MSInventario/api/v1/inventario/" + idLibro)
                    .retrieve()
                    .bodyToMono(InventarioDTO.class)
                    .block();

            // CORRECCIÓN: Usamos el método getter estándar de Java (.getCantidadDisponible())
            if (respuesta != null) {
                return respuesta.getCantidadDisponible();
            }

            return 0;
        } catch (Exception e) {
            // Es una excelente práctica loggear el error exacto para saber si es un 401, un 404 o un Timeout
            log.error("Error conectando con ms-inventario para el libro ID {}: {}", idLibro, e.getMessage());
            // Si el inventario falla, por seguridad asumimos que no hay stock
            return 0;
        }
    }
    public void descontarStock(Long idLibro) {
        try {
            log.info("Enviando petición PUT a ms-inventario para descontar libro ID: {}", idLibro);

            webClientBuilder.build()
                    .put()
                    // Apuntamos al endpoint de descuento en ms-inventario
                    .uri("http://MSInventario/api/v1/inventario/" + idLibro + "/descontar")
                    .retrieve()
                    .toBodilessEntity() // Solo esperamos un 200 OK, no necesitamos mapear un JSON de respuesta
                    .block();

            log.info("Stock descontado exitosamente en ms-inventario para el libro ID: {}", idLibro);

        } catch (Exception e) {
            log.error("Error crítico al descontar stock en ms-inventario para el libro ID {}: {}", idLibro, e.getMessage());
            // Aquí sí lanzamos la excepción porque si falla el descuento, el préstamo debe saberlo
            throw new RuntimeException("Fallo en la comunicación con ms-inventario al descontar el stock.");
        }
    }
}