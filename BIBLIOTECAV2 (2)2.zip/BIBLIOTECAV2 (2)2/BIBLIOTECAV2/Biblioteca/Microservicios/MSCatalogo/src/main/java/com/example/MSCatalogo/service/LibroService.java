package com.example.MSCatalogo.service;

import com.example.MSCatalogo.client.InventarioClient;
import com.example.MSCatalogo.model.*;
import com.example.MSCatalogo.repository.AutorRepository;
import com.example.MSCatalogo.repository.CategoriaRepository;
import com.example.MSCatalogo.repository.LibroRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;
@Slf4j
@Service
public class LibroService {

    @Autowired
    private LibroRepository libroRepository;

    @Autowired
    private CategoriaRepository categoriaRepository;

    @Autowired
    private InventarioClient inventarioClient;

    @Autowired
    private AutorRepository autorRepository;

    public List<LibroResponseDTO> obtenerTodos() {
        List<Libro> libros = libroRepository.findAll();

        return libros.stream()
                .map(libro -> mapearADto(libro, 0)) // Enviamos 0 en stock por defecto para las listas
                .collect(Collectors.toList());
    }

    public LibroResponseDTO guardarLibro(LibroRequestDTO request) {
        // A. Validar y obtener el Autor desde la Base de Datos
        Autor autor = autorRepository.findById(request.getIdAutor())
                .orElseThrow(() -> new RuntimeException("No se puede crear el libro. El Autor con ID " + request.getIdAutor() + " no existe."));

        // B. Validar y obtener la Categoría desde la Base de Datos
        Categoria categoria = categoriaRepository.findById(request.getIdCategoria())
                .orElseThrow(() -> new RuntimeException("No se puede crear el libro. La Categoría con ID " + request.getIdCategoria() + " no existe."));

        // C. Construir la Entidad Libro original para la Base de Datos
        Libro nuevoLibro = new Libro();
        nuevoLibro.setTitulo(request.getTitulo());
        nuevoLibro.setAutor(autor);
        nuevoLibro.setCategoria(categoria);

        // D. Guardar en la base de datos de ms-catalogo
        Libro libroGuardado = libroRepository.save(nuevoLibro);

        // E. Retornar el DTO de respuesta. Como es nuevo, asumimos stock 0 hasta que ms-inventario lo registre.
        return mapearADto(libroGuardado, 0);
    }

    // 1. Obtener UN libro con su stock real (para cuando ven el detalle)
    public LibroResponseDTO obtenerLibroConStock(Long idLibro) {
        Libro libro = libroRepository.findById(idLibro)
                .orElseThrow(() -> new RuntimeException("Libro no encontrado"));

        int stock = inventarioClient.obtenerStock(idLibro);
        return mapearADto(libro, stock);
    }

    // 2. Obtener libros por Categoria (sin llamar al inventario por rendimiento)
    public List<LibroResponseDTO> obtenerPorCategoria(Long idCategoria) {
        List<Libro> libros = libroRepository.findByCategoriaId(idCategoria);

        return libros.stream()
                .map(libro -> mapearADto(libro, 0)) // Stock en 0 o no aplicable para la vista de lista
                .collect(Collectors.toList());
    }

    // 3. Obtener libros por Autor
    public List<LibroResponseDTO> obtenerPorAutor(Long idAutor) {
        List<Libro> libros = libroRepository.findByAutorId(idAutor);

        return libros.stream()
                .map(libro -> mapearADto(libro, 0))
                .collect(Collectors.toList());
    }

    // =====================================================================
    // 🚀 NUEVO MÉTODO: Descontar stock comunicándose con ms-inventario
    // =====================================================================
    public void descontarStock(Long idLibro) {
        log.info("🔹 [LibroService] Verificando existencia del libro ID: {} antes de descontar stock.", idLibro);

        // 1. Validar que el libro exista físicamente en el catálogo
        if (!libroRepository.existsById(idLibro)) {
            log.error("❌ [LibroService] El libro ID {} no existe en el catálogo.", idLibro);
            throw new RuntimeException("El libro solicitado no existe en el catálogo.");
        }

        // 2. Ordenar al ms-inventario que descuente la unidad
        try {
            log.info("🔹 [LibroService] Solicitando descuento a ms-inventario para el libro ID: {}", idLibro);

            inventarioClient.descontarStock(idLibro); // 👈 Llamada a tu cliente Feign/WebClient

            log.info("✅ [LibroService] Descuento de stock confirmado por ms-inventario para el libro ID: {}", idLibro);
        } catch (Exception e) {
            log.error("❌ [LibroService] Falló la comunicación con ms-inventario al descontar: {}", e.getMessage());
            throw new RuntimeException("Error al actualizar el stock en el inventario. Detalle: " + e.getMessage());
        }
    }

    // Método auxiliar privado para no repetir código
    private LibroResponseDTO mapearADto(Libro libro, int stock) {
        LibroResponseDTO dto = new LibroResponseDTO();
        dto.setLibroId(libro.getId());
        dto.setTitulo(libro.getTitulo());
        dto.setAutor(libro.getAutor().getNombre());
        dto.setCategoria(libro.getCategoria().getNombre());
        dto.setStockDisponible(stock);
        return dto;
    }
}