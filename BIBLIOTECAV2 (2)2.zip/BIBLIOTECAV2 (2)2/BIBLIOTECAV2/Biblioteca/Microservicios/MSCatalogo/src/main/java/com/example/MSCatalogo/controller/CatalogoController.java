package com.example.MSCatalogo.controller;

import com.example.MSCatalogo.model.*;
import com.example.MSCatalogo.service.AutorService;
import com.example.MSCatalogo.service.CategoriaService;
import com.example.MSCatalogo.service.LibroService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/v1/catalogo")
@Slf4j
public class CatalogoController {

    @Autowired
    private LibroService libroService;

    @Autowired
    private AutorService autorService;

    @Autowired
    private CategoriaService categoriaService;


    @GetMapping
    @PreAuthorize("hasAnyRole('ADMIN', 'USUARIO', 'TRABAJADOR')")
    public ResponseEntity<List<LibroResponseDTO>> obtenerTodos() {
        log.info("Solicitando la lista completa de libros");
        // Asumiendo que agregas el método obtenerTodos() en LibroService que devuelva List<LibroResponseDTO> sin stock
        return ResponseEntity.ok(libroService.obtenerTodos());
    }


    @GetMapping("/libro/id/{id}")
    public ResponseEntity<?> obtenerPorId(@PathVariable Long id) {
        try {
            log.info("aqui estoy");
            return ResponseEntity.ok(libroService.obtenerLibroConStock(id));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(Map.of("error", e.getMessage()));
        }
    }
    @PutMapping("/libro/{id}/descontar")
    public ResponseEntity<?> descontarStock(@PathVariable Long id) {
        try {
            libroService.descontarStock(id);
            return ResponseEntity.ok(Map.of("mensaje", "Stock descontado exitosamente"));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(Map.of("error", e.getMessage()));
        }
    }

    @PostMapping("/libro")
    @PreAuthorize("hasAnyRole('ADMIN', 'USUARIO', 'TRABAJADOR')")
    public ResponseEntity<?> crearLibro(@RequestBody LibroRequestDTO request) { // 👈 Usamos el DTO de entrada
        try {
            // 👈 El servicio recibe el DTO, busca el autor/categoría y guarda la entidad
            LibroResponseDTO nuevoLibro = libroService.guardarLibro(request);
            return ResponseEntity.status(HttpStatus.CREATED).body(nuevoLibro);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(Map.of("error", e.getMessage()));
        }
    }


    @PostMapping("/autor")
    @PreAuthorize("hasAnyRole('ADMIN', 'USUARIO', 'TRABAJADOR')")
    public ResponseEntity<Autor> crearAutor(@RequestBody Autor autor) {
        return ResponseEntity.status(HttpStatus.CREATED).body(autorService.guardarAutor(autor));
    }


    @PostMapping("/categoria")
    @PreAuthorize("hasAnyRole('ADMIN', 'USUARIO', 'TRABAJADOR')")
    public ResponseEntity<Categoria> crearCategoria(@RequestBody Categoria categoria) {
        return ResponseEntity.status(HttpStatus.CREATED).body(categoriaService.guardarCategoria(categoria));
    }
}