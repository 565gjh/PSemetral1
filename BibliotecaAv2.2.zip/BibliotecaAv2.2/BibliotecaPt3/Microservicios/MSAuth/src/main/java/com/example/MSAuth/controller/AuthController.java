package com.example.MSAuth.controller;

import com.example.MSAuth.model.Usuario;
import com.example.MSAuth.security.jwt.JwtService;
import com.example.MSAuth.service.UsuarioService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.*;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/v1/auth")
public class AuthController {

    private final AuthenticationManager authManager;
    private final JwtService jwtService;
    private final UsuarioService usuarioService;

    public AuthController(AuthenticationManager authManager, JwtService jwtService, UsuarioService usuarioService) {
        this.authManager = authManager;
        this.jwtService = jwtService;
        this.usuarioService = usuarioService;
    }
    @PostMapping("/register")
    public ResponseEntity<?> register(@RequestBody Map<String, String> body) {
        try {
            // Extraemos los datos de autenticación
            String username = body.get("username");
            String password = body.get("password");
            String email = body.get("email");
            String rol = body.getOrDefault("rol", "USUARIO"); // Por defecto USUARIO si no lo envían

            // Extraemos los datos del perfil
            String nombre1 = body.get("nombre1");
            String apellido1 = body.get("apellido1");

            boolean estado = true;

            // Validamos que no vengan nulos o vacíos (puedes agregar más validaciones si gustas)
            if (username == null || password == null || username.isBlank() || password.isBlank() ||
                    nombre1 == null || apellido1 == null || email == null) {
                return ResponseEntity.badRequest()
                        .body(Map.of("error", "Username, password, email, nombre1 y apellido1 son requeridos"));
            }

            // Validar rol
            if (!rol.equals("USUARIO") && !rol.equals("ADMIN") && !rol.equals("TRABAJADOR")){
                return ResponseEntity.badRequest()
                        .body(Map.of("error", "Debes especificar un rol válido (USUARIO, ADMIN o TRABAJADOR)"));
            }

            // Llamamos al servicio pasándole el Map completo
            usuarioService.register(body, rol, estado);

            return ResponseEntity.status(HttpStatus.CREATED).body(Map.of(
                    "message", "Usuario registrado correctamente",
                    "rol", rol
            ));

        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.CONFLICT)
                    .body(Map.of("error", "Error al registrar el usuario: " + e.getMessage()));
        }
    }

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody Map<String, String> body) {
        try {
            String username = body.get("username");
            String password = body.get("password");

            Authentication auth = authManager.authenticate(
                    new UsernamePasswordAuthenticationToken(username, password));

            if (auth.isAuthenticated()) {
                // Obtener rol del usuario
                Usuario usuario = usuarioService.findByUsername(username)
                        .orElseThrow(() -> new RuntimeException("Usuario no encontrado"));

                String token = jwtService.generateToken(username, usuario.getRol());
                return ResponseEntity.ok(Map.of(
                        "token", token,
                        "username", username,
                        "rol", usuario.getRol()// Devolver rol
                ));
            }

            return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                    .body(Map.of("error", "Credenciales inválidas"));

        } catch (BadCredentialsException e) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                    .body(Map.of("error", "Usuario o contraseña incorrectos"));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Map.of("error", "Error al procesar la solicitud"));
        }
    }

    @GetMapping("/validate")
    public ResponseEntity<?> validateToken() {
        return ResponseEntity.ok(Map.of("valid", true));
    }

    // 2. READ (Obtener todos)
    @GetMapping
    public ResponseEntity<List<Usuario>> obtenerTodos() {

        return ResponseEntity.ok(usuarioService.obtenerTodos());
    }

    // filtra por id
    @GetMapping("/id/{id}")
    public ResponseEntity<Usuario> findById(@PathVariable Long id) {
        try {
            Usuario usuario = usuarioService.findById(id);
            return ResponseEntity.ok(usuario);
        } catch (Exception e) {
            return ResponseEntity.notFound().build(); // Retorna 404
        }
    }

    //filtra por usuario
    @GetMapping("/username/{username}")
    public ResponseEntity<Usuario> findByUsername(@PathVariable String username) {
        return usuarioService.findByUsername(username)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build()); // Retorna 404
    }

    // filtra por email
    @GetMapping("/email/{email}")
    public ResponseEntity<Usuario> findByEmail(@PathVariable String email) {
        return usuarioService.findByEmail(email)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build()); // Retorna 404
    }

    //filtra por Usuarios activos
    @GetMapping("/estado/{estado}")
    public ResponseEntity<List<Usuario>> findByEstado(@PathVariable boolean estado){
        try {
            return ResponseEntity.ok(usuarioService.findByEstado(estado));
        } catch (Exception e) {
            return ResponseEntity.notFound().build(); // Retorna 404
        }


    }
}