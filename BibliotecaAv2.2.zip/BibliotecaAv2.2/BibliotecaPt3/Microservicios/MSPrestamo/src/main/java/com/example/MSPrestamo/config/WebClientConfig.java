package com.example.MSPrestamo.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.reactive.function.client.WebClient;

@Configuration
public class WebClientConfig {

    @Bean
    public WebClient inventarioWebClient() {
        return WebClient.builder()
                .baseUrl("http://localhost:8082/api/v1/inventario")
                .build();
    }

    @Bean
    public WebClient catalogoWebClient() {
        return WebClient.builder()
                .baseUrl("http://localhost:8083/api/v1/libros")
                .build();
    }

    @Bean
    public WebClient usuarioWebClient() {
        return WebClient.builder()
                .baseUrl("http://localhost:8081/api/v1/usuarios")
                .build();
    }

    @Bean
    public WebClient multasWebClient() {
        return WebClient.builder()
                .baseUrl("http://localhost:8084/api/v1/multas")
                .build();
    }
    @Bean
    public WebClient notificacionesWebClient() {
        return WebClient.builder()
                .baseUrl("http://localhost:8085/api/v1/notificaciones")
                .build();
    }
}
