package com.example.MSPrestamo.client;

import com.example.MSPrestamo.dto.inventarioDTO;
import com.example.MSPrestamo.model.Inventario;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

@Component
public class InventarioClient {

    private final WebClient inventarioWebClient;

    public InventarioClient(WebClient inventarioWebClient) {
        this.inventarioWebClient = inventarioWebClient;
    }

    public Mono<inventarioDTO> obtenerItemInventario(Long inventarioId) {
        return this.inventarioWebClient.get()
                .uri("/{id}", inventarioId)
                .retrieve()
                .bodyToMono(inventarioDTO.class)
                // Si el item no existe o falla, retorna un Mono vacío controlado
                .onErrorResume(e -> Mono.empty());
    }
}