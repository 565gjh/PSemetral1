package com.example.MSPrestamo.controller;

import com.example.MSPrestamo.dto.PrestamoResponseDto;
import com.example.MSPrestamo.model.Prestamo;
import com.example.MSPrestamo.service.prestamoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/prestamos")
public class prestamoController {

    @Autowired
    private prestamoService prestamoService;

    @GetMapping("/{id}")
    public ResponseEntity<PrestamoResponseDto> buscarPrestamoPorId(@PathVariable Long id) {
        Prestamo prestamoLocal = prestamoService.obtenerPorId(id).orElse(null);

        if (prestamoLocal == null) {
            return ResponseEntity.notFound().build();
        }

        PrestamoResponseDto responseDto = new PrestamoResponseDto();
        responseDto.setId(prestamoLocal.getId());


        responseDto.setRutUsuario(String.valueOf(prestamoLocal.getUsuarioId()));
        responseDto.setLibroId(prestamoLocal.getInventarioId());
        responseDto.setCodigoBarra("Ver historial completo para detalles");

        responseDto.setFechaPrestamo(prestamoLocal.getFechaPrestamo());
        responseDto.setFechaDevolucion(prestamoLocal.getFechaDevolucionMaxima());
        responseDto.setEstadoPrestamo(prestamoLocal.getEstado());
        responseDto.setMensajeInformativo("Préstamo consultado con éxito en la base de datos local.");

        return ResponseEntity.ok(responseDto);
    }
}