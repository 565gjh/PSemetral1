package com.example.MSInventario.service;

import com.example.MSInventario.client.CatalogoClient;
import com.example.MSInventario.model.Inventario;
import com.example.MSInventario.model.InventarioDetalle;
import com.example.MSInventario.repository.inventarioRepository;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

import java.util.List;
import java.util.Optional;

@Service
public class inventarioService {

    private final inventarioRepository inventarioRepository;
    private final CatalogoClient catalogoClient;

    public inventarioService(inventarioRepository inventarioRepository, CatalogoClient catalogoClient) {
        this.inventarioRepository = inventarioRepository;
        this.catalogoClient = catalogoClient;
    }

    public List<Inventario> findAll() {
        return inventarioRepository.findAll();
    }

    public Optional<Inventario> findById(Long id) {
        return inventarioRepository.findById(id);
    }

    public Inventario save(Inventario inventario) {
        return inventarioRepository.save(inventario);
    }
    public void delete(Long id) {
        inventarioRepository.deleteById(id);
    }

    public Mono<InventarioDetalle> obtenerItemConCatalogo(Long id) {
        return Mono.justOrEmpty(inventarioRepository.findById(id))
                .flatMap(item -> {
                    InventarioDetalle dto = new InventarioDetalle();
                    dto.setInventarioId(item.getId());
                    dto.setLibroId(item.getLibroId());
                    dto.setCodigoBarra(item.getCodigoBarra());
                    dto.setEstado(item.getEstado());

                    return catalogoClient.obtenerDatosLibro(item.getLibroId())
                            .map(libro -> {
                                dto.setTituloLibro(libro.getTitulo());
                                return dto;
                            })
                            .defaultIfEmpty(dto);
                })
                .doOnNext(dto -> {
                    if (dto.getTituloLibro() == null) {
                        dto.setTituloLibro("Título no disponible temporalmente");
                    }
                });
    }

    public Mono<Inventario> guardarEjemplar(Inventario nuevoItem) {
        return catalogoClient.obtenerDatosLibro(nuevoItem.getLibroId())
                .switchIfEmpty(Mono.error(new RuntimeException("Error: El id de libro " + nuevoItem.getLibroId() + " no existe en el Catálogo.")))
                .map(libroDto -> {
                    return inventarioRepository.save(nuevoItem);
                });
    }

    public Mono<Inventario> actualizarEstado(Long id, String nuevoEstado) {
        return Mono.justOrEmpty(inventarioRepository.findById(id))
                .map(item -> {
                    item.setEstado(nuevoEstado);
                    return inventarioRepository.save(item);
                })
                .switchIfEmpty(Mono.error(new RuntimeException("Item de inventario no encontrado")));
    }
}