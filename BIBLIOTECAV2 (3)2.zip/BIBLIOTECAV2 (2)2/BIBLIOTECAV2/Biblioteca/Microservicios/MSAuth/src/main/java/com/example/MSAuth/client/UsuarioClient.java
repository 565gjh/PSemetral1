package com.example.MSAuth.client;

import com.example.MSAuth.model.RegistroUsuarioDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

@Component
public class UsuarioClient {

    @Autowired
    private WebClient.Builder webClientBuilder;

    public Mono<Void> enviarPerfil(RegistroUsuarioDTO dto) {
        return webClientBuilder.build()
                .post()
                // Enviamos información usando POST según los métodos de la guía
                .uri("http://ms-usuario/api/v1/usuarios")
                .bodyValue(dto)
                .retrieve()
                .bodyToMono(Void.class);
    }
}