package com.example.MSPrestamo.client;

import com.example.MSPrestamo.model.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;


@Component
public class CatalogoClient {

    @Autowired
    private WebClient.Builder webClientBuilder;

    // Fíjate que ahora pedimos el token como parámetro
    public LibroResponseDTO obtenerLibro(Long libroId) {
        try{
            return webClientBuilder.build()
                    .get()
                    .uri("http://ms-catalogo/api/v1/catalogo/libro/id/" + libroId)
                    .retrieve()
                    .bodyToMono(LibroResponseDTO.class)
                    .block(); // Usamos block para esperar la respuesta
        } catch (Exception e) {
            // Si el ms-usuarios devuelve un error (ej. 404 porque el usuario no existe), aquí lo capturas
            System.out.println("Error al comunicarse con ms-catalogo: " + e.getMessage());
            return null;
        }
    }
    public void descontarStockLibro(Long idLibro) {
        try {
            webClientBuilder.build()
                    .put()
                    // Asegúrate de usar el mismo nombre de Eureka que descubrimos antes (MSCatalogo o MS-CATALOGO)
                    .uri("http://MSCatalogo/api/v1/catalogo/libro/" + idLibro + "/descontar")
                    .retrieve()
                    .toBodilessEntity() // No esperamos un cuerpo de respuesta, solo que responda un 200 OK
                    .block(); // Bloqueamos para que sea síncrono en el flujo del préstamo
        } catch (Exception e) {
            throw new RuntimeException("Error crítico: No se pudo descontar el stock en el catálogo. " + e.getMessage());
        }
    }
}