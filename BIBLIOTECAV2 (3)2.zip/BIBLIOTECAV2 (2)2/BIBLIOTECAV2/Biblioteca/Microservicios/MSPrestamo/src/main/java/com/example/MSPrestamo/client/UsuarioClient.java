package com.example.MSPrestamo.client;

import com.example.MSPrestamo.model.UsuarioDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;
@Component
// 🚨 ¡ESTA ES LA LÍNEA QUE TE FALTA!
public class UsuarioClient {
    @Autowired
    private WebClient.Builder webClientBuilder;

    public UsuarioDTO obtenerUsuario(Long usuarioId) {
        try{
            return webClientBuilder.build()
                    .get()
                    .uri("http://ms-usuario/api/v1/usuarios/id/" + usuarioId)//
                    .retrieve()
                    .bodyToMono(UsuarioDTO.class)
                    .block();
        } catch (Exception e) {
            // Si el ms-usuarios devuelve un error (ej. 404 porque el usuario no existe), aquí lo capturas
            System.out.println("Error al comunicarse con ms-usuarios: " + e.getMessage());
            return null;
        }
    }
}