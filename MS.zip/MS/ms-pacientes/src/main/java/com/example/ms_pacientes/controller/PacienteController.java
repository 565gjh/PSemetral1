package com.example.ms_pacientes.controller;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;
import com.example.ms_pacientes.model.Paciente;
import com.example.ms_pacientes.service.PacienteService;
import jakarta.persistence.Id;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;

@RestController
@RequestMapping("/api/v1/pacientes")
@RequiredArgsConstructor
public class PacienteController {

    private final PacienteService service;

    @GetMapping
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<List<Paciente>> findAll() {
        return ResponseEntity.ok(service.findAll());
    }


    @GetMapping("id/{id}")
    public ResponseEntity<Paciente> findById(@PathVariable Long id) {
        Optional<Paciente> pacienteOpt = service.findById(id);
        if (pacienteOpt.isEmpty()){
            return ResponseEntity.notFound().build();
        }
        Paciente paciente = pacienteOpt.get();
        paciente.add(linkTo(methodOn(PacienteController.class).findAll()).withRel("pacientes"));
        return ResponseEntity.ok(paciente);

    }

    @PostMapping
    public ResponseEntity<Paciente> save(@Valid @RequestBody Paciente paciente) {
        Paciente pac = service.save(paciente);
        pac.add(linkTo(methodOn(PacienteController.class).findAll()).withRel("todos"));
        pac.add(linkTo(methodOn(PacienteController.class).findById(pac.getIdPaciente())).withSelfRel());
        pac.add(linkTo(methodOn(PacienteController.class).update(pac)).withRel("update"));;
        pac.add(linkTo(methodOn(PacienteController.class).deleteById(pac.getIdPaciente())).withRel("delete"));
        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body(pac);
    }

    @PutMapping
    public ResponseEntity<Paciente> update(@RequestBody Paciente paciente) {
        return ResponseEntity.status(HttpStatus.OK).body(service.save(paciente));
    }

    @DeleteMapping
    public ResponseEntity delete(@RequestBody Paciente paciente){
        service.delete(paciente);
        return ResponseEntity.noContent().build();
    }

    @DeleteMapping("{id}")
    public ResponseEntity deleteById(@PathVariable Long id){
        try{
            service.deleteById(id);
        }catch (NoSuchElementException ex){
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.noContent().build();
    }


}
