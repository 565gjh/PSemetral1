//package com.example.ms_pacientes.assemblers;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;

import com.example.ms_pacientes.model.Paciente;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.server.RepresentationModelAssembler;
import org.springframework.stereotype.Component;

//@Component
//public class PacienteModelAssembler implements RepresentationModelAssembler<Paciente, EntityModel<Paciente>> {
//@Override
//public EntityModel<Paciente> toModel(Paciente paciente) {
//return EntityModel.of(paciente,
//linkTo(methodOn(PacienteControllerV2.class).getFindById)

//);
        //}
//}
