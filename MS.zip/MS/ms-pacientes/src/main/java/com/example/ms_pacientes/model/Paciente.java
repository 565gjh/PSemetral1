package com.example.ms_pacientes.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.hateoas.RepresentationModel;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Paciente extends RepresentationModel<Paciente> {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idPaciente;
    private Long idUsuario;
    @Column(length = 20, unique = true)
    @NotBlank
    @Size(max = 20)
    private String rut;
    @Column(length = 100)
    @NotBlank
    @Size(max = 100)
    private String nombres;
    @Column(length = 100)
    @NotBlank
    @Size(max = 100)
    private String apellidos;
    private LocalDate fechaNacimiento;
    @Column(length = 20)
    @NotBlank
    @Size(max = 20)
    private String telefono;
    @NotBlank
    @Size(max = 255)
    private String direccion;
    private LocalDateTime fechaCreacion;
}
