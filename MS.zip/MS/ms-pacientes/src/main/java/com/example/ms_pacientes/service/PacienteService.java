package com.example.ms_pacientes.service;

import com.example.ms_pacientes.model.Paciente;
import com.example.ms_pacientes.repository.PacienteRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class PacienteService {

    private final PacienteRepository repository;

    public List<Paciente> findAll(){
        return repository.findAll();
    }

    public Optional<Paciente> findById(Long id){
        return repository.findById(id);
    }

    public Paciente save(Paciente paciente) {
        return repository.save(paciente);
    }

    public void delete(Paciente paciente){
        repository.delete(paciente);
    }

    public void deleteById(Long id) {
        findById(id).get();
        repository.deleteById(id);
    }
}
