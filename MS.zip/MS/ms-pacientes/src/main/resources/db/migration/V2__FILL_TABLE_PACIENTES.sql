INSERT INTO paciente (
    id_usuario,
    rut,
    nombres,
    apellidos,
    fecha_nacimiento,
    telefono,
    direccion,
    fecha_creacion
) VALUES
(
    1,
    '12.345.678-9',
    'Juan Carlos',
    'Pérez Soto',
    '1990-05-14',
    '+56912345678',
    'Av. Libertador Bernardo O Higgins 1234, Santiago',
    NOW()
),
(
    2,
    '15.987.654-3',
    'María José',
    'González Rojas',
    '1985-11-22',
    '+56987654321',
    'Calle Los Aromos 456, Melipilla',
    NOW()
),
(
    3,
    '18.456.789-K',
    'Pedro Antonio',
    'Ramírez Fuentes',
    '2001-02-10',
    '+56955554444',
    'Pasaje Las Flores 789, Maipú',
    NOW()
);