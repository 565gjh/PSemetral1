CREATE TABLE paciente (
    id_paciente BIGINT AUTO_INCREMENT PRIMARY KEY,
    id_usuario BIGINT NOT NULL,

    rut VARCHAR(20) NOT NULL UNIQUE,

    nombres VARCHAR(100) NOT NULL,

    apellidos VARCHAR(100) NOT NULL,

    fecha_nacimiento DATE,

    telefono VARCHAR(20) NOT NULL,

    direccion VARCHAR(255) NOT NULL,

    fecha_creacion DATETIME,

    INDEX idx_id_usuario (id_usuario)
);