package com.example.ms_reservas.client;

import com.example.ms_reservas.model.Paciente;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.server.ResponseStatusException;
import reactor.core.publisher.Mono;

@Service
@RequiredArgsConstructor
@Slf4j
public class PacienteClient {

    private final WebClient client;
    private final HttpServletRequest request;

    public Paciente obtenerPaciente(Long id) {
        String token = request.getHeader(HttpHeaders.AUTHORIZATION);
        log.debug("Token obtenido del header: {}", token);

        return client.get()
                .uri("/{id}", id)
                .header(HttpHeaders.AUTHORIZATION, token)
                .retrieve()
                .onStatus(
                        status -> status.value() == 404,
                        response -> Mono.error(
                                new ResponseStatusException(
                                HttpStatus.NOT_FOUND,
                                "Paciente no encontrado"
                                )
                        )
                ).bodyToMono(Paciente.class)
                .block();
    }

}
