package com.example.ms_reservas.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@NoArgsConstructor
@AllArgsConstructor
@Data
public class Reserva {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long idReserva;
    @NotNull
    private Long idPaciente;
    @NotNull
    private LocalDate fechaConsulta;
    @NotBlank
    private String motivoConsulta;
    @Column(length = 20)
    @NotBlank
    @Size(max = 20)
    private String estado;
    @NotBlank
    private String observaciones;
    private LocalDateTime fechaCreacion;


}
