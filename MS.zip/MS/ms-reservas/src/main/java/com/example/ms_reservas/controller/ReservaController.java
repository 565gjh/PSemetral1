package com.example.ms_reservas.controller;

import com.example.ms_reservas.client.PacienteClient;
import com.example.ms_reservas.model.Paciente;
import com.example.ms_reservas.model.Reserva;
import com.example.ms_reservas.service.ReservaService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.NoSuchElementException;

@RestController
@RequestMapping("/api/v1/reservas")
@RequiredArgsConstructor
public class ReservaController {

    private final ReservaService service;
    private final PacienteClient client;

    @GetMapping
    public ResponseEntity<List<Reserva>> findAll(){
        return ResponseEntity.ok(service.findAll());
    }

    @GetMapping("{id}")
    public ResponseEntity<Reserva> findById(@PathVariable Long id){
        return service.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<Reserva> save(@Valid @RequestBody Reserva reserva){
        Paciente paciente = client.obtenerPaciente(reserva.getIdPaciente());
        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body(service.save(reserva));
    }

    @PutMapping
    public ResponseEntity<Reserva> update(@Valid @RequestBody Reserva reserva){
        return ResponseEntity.status(HttpStatus.OK).body(service.save(reserva));
    }

    @DeleteMapping
    public ResponseEntity<Void> delete(@RequestBody Reserva reserva){
        service.delete(reserva);
        return ResponseEntity.noContent().build();
    }

    @DeleteMapping("{id}")
    public ResponseEntity<Void> deleteById(@PathVariable Long id){
        try{
            service.deleteById(id);
            return ResponseEntity.noContent().build();
        }catch (NoSuchElementException ex){
            return ResponseEntity.notFound().build();
        }
    }
}
