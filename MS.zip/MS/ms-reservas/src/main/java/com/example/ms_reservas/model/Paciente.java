package com.example.ms_reservas.model;

import lombok.Data;

import java.time.LocalDate;
import java.time.LocalDateTime;


@Data
public class Paciente {

    private Long idPaciente;
    private Long idUsuario;
    private String rut;
    private String nombres;
    private String apellidos;
    private LocalDate fechaNacimiento;
    private String telefono;
    private String direccion;
    private LocalDateTime fechaCreacion;

}
