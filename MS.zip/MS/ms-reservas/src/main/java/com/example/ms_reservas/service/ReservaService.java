package com.example.ms_reservas.service;

import com.example.ms_reservas.model.Reserva;
import com.example.ms_reservas.repository.ReservaRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class ReservaService {

    private final ReservaRepository repository;

    public List<Reserva> findAll(){
        return repository.findAll();
    }

    public Optional<Reserva> findById(Long id){
        return repository.findById(id);
    }

    public Reserva save(Reserva reserva){
        return repository.save(reserva);
    }

    public void delete(Reserva reserva){
        repository.delete(reserva);
    }

    public void deleteById(Long id){
        findById(id).get();
        repository.deleteById(id);
    }
}
