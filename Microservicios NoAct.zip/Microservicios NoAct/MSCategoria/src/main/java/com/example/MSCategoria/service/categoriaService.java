package com.example.MSCategoria.service;


import com.example.MSCategoria.model.Categoria;
import com.example.MSCategoria.repository.categoriaRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@Slf4j
public class categoriaService {

    @Autowired
    private categoriaRepository repository;

    public List<Categoria> findAll() {
        log.info("Obteniendo lista de todas las categorías.");
        return repository.findAll();
    }

    public Categoria findById(Long id) {
        log.info("buscando categoria por id.");
        return repository.findById(id).orElse(null);
    }

    public Categoria save(Categoria categoria) {
        log.info("Guardando nueva categoría temática.");
        return repository.save(categoria);
    }

    public void delete(Long id) {
        log.info("eliminando la categoría seleccionada.");
        repository.deleteById(id);
    }
}