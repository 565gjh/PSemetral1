package com.example.MSCategoria.repository;


import com.example.MSCategoria.model.Categoria;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;

public interface categoriaRepository extends JpaRepository<Categoria, Long> {
    // Para buscar una categoría específica por su nombre
    Optional<Categoria> findByNombre(String nombre);
}