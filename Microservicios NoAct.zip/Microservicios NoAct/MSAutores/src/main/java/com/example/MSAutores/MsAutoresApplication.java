package com.example.MSAutores;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MsAutoresApplication {

	public static void main(String[] args) {
		SpringApplication.run(MsAutoresApplication.class, args);
	}

}
