package com.example.MSPrestamo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MsPrestamoApplication {

	public static void main(String[] args) {
		SpringApplication.run(MsPrestamoApplication.class, args);
	}

}
