package com.example.MSusuario.controller;

import com.example.MSusuario.client.AuthClient;
import com.example.MSusuario.model.Usuario;
import com.example.MSusuario.service.usuarioService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PostFilter;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Mono;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/v1/usuarios")
@RequiredArgsConstructor
public class usuarioController {

    private final AuthClient authClient;
    @Autowired
    private usuarioService service;

    @GetMapping
    @PreAuthorize("hasAnyRole('ADMIN', 'TRABAJADOR')")
    @PostFilter("hasRole('ADMIN') or filterObject.rol == 'USUARIO'")
    public List<Usuario> findAll() {
        return service.findAll();
    }


    @GetMapping("/id/{id}")
    @PreAuthorize("hasAnyRole('ADMIN', 'TRABAJADOR')")
    @PostFilter("hasRole('ADMIN') or filterObject.rol == 'USUARIO'")
    public ResponseEntity<Usuario> findById(@PathVariable Long id) {
        return ResponseEntity.ok(service.findById(id));
    }

    @PostMapping
    @PreAuthorize("hasAnyRole('ADMIN', 'USUARIO', 'TRABAJADOR')")
    public Mono<ResponseEntity<Usuario>> save(@RequestBody Usuario usuario) {
        return authClient.obtenerUsuario(usuario.getIdAuth())
                .map(usuario1 -> {
                    Usuario guardado = service.save(usuario);
                    return ResponseEntity.status(HttpStatus.CREATED).body(guardado);
                });

    }

    public ResponseEntity<Optional<Usuario>> findByEmail(@PathVariable String email) {

        return ResponseEntity.ok(service.findByEmail(email));

    }
}