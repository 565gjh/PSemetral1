package com.example.MSusuario.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.util.List;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Table(name = "usuarios")

public class Usuario {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private Long idAuth;

    @NotBlank(message = "El primer nombre es obligatorio")
    private String nombre1;

    private String nombre2;
    @NotBlank(message = "El apellido paterno es obligatorio")
    private String apellido1;
    @NotBlank(message = "El apellido materno es obligatorio")
    private String apellido2;


    private int celular;


    @NotBlank(message = "El email es obligatorio")
    @Email(message = "Debe ser un correo válido")
    @Column(unique = true)
    private String email;

    @NotBlank(message = "El rol es obligatorio")
    private String rol;



}