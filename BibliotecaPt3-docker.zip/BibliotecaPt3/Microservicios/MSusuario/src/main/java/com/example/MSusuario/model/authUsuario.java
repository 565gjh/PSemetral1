package com.example.MSusuario.model;

import jakarta.persistence.Column;
import lombok.Data;

@Data
public class authUsuario {
    private Long id;

    private String email;

    private String username;

    private String password;

    private String rol;

    private Boolean activo;
}