package com.example.MSPrestamo.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.LocalDate;

@Entity
@Table(name = "prestamos")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Prestamo {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "usuario_id", nullable = false)
    private Long usuarioId; // ID que viene de MSAuth

    @Column(name = "inventario_id", nullable = false)
    private Long inventarioId; // ID del ejemplar físico que viene de MSInventario

    @Column(name = "fecha_prestamo", nullable = false)
    private LocalDate fechaPrestamo;

    @Column(name = "fecha_devolucion_maxima", nullable = false)
    private LocalDate fechaDevolucionMaxima;

    @Column(nullable = false, length = 50)
    private String estado; // "VIGENTE", "DEVUELTO", "ATRASADO"
}