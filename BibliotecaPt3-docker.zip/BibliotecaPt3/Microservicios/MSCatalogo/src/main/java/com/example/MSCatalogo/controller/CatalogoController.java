package com.example.MSCatalogo.controller;

import com.example.MSCatalogo.model.Autor;
import com.example.MSCatalogo.model.Categoria;
import com.example.MSCatalogo.model.Libro;
import com.example.MSCatalogo.service.CatalogoService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/v1/catalogo")
@Slf4j

public class CatalogoController {

    @Autowired
    private CatalogoService catalogoService;


    @GetMapping
    @PreAuthorize("hasAnyRole('ADMIN', 'USUARIO', 'TRABAJADOR')")
    public ResponseEntity<List<Libro>> obtenerTodos() {
        log.info("pasando1");
        return ResponseEntity.ok(catalogoService.obtenerCatalogoCompleto());
    }

    // GET: http://localhost:8085/api/v1/catalogo/libro/{id}
    @GetMapping("/libro/{id}")
    @PreAuthorize("hasAnyRole('ADMIN', 'USUARIO', 'TRABAJADOR')")
    public ResponseEntity<?> obtenerPorId(@PathVariable Long id) {
        try {
            return ResponseEntity.ok(catalogoService.obtenerPorId(id));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(Map.of("error", e.getMessage()));
        }
    }

    // POST: http://localhost:8085/api/v1/catalogo/libro
    @PostMapping("/libro")
    @PreAuthorize("hasAnyRole('ADMIN', 'USUARIO', 'TRABAJADOR')")
    public ResponseEntity<?> crearLibro(@RequestBody Libro libro) {
        try {
            Libro nuevoLibro = catalogoService.guardarLibroEnCatalogo(libro);
            return ResponseEntity.status(HttpStatus.CREATED).body(nuevoLibro);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(Map.of("error", e.getMessage()));
        }
    }

    // POST: http://localhost:8085/api/v1/catalogo/autor
    @PostMapping("/autor")
    @PreAuthorize("hasAnyRole('ADMIN', 'USUARIO', 'TRABAJADOR')")
    public ResponseEntity<Autor> crearAutor(@RequestBody Autor autor) {
        return ResponseEntity.status(HttpStatus.CREATED).body(catalogoService.guardarAutor(autor));
    }

    // POST: http://localhost:8085/api/v1/catalogo/categoria
    @PostMapping("/categoria")
    @PreAuthorize("hasAnyRole('ADMIN', 'USUARIO', 'TRABAJADOR')")
    public ResponseEntity<Categoria> crearCategoria(@RequestBody Categoria categoria) {
        return ResponseEntity.status(HttpStatus.CREATED).body(catalogoService.guardarCategoria(categoria));
    }
}