package com.example.MSAuth.service;

import com.example.MSAuth.model.Usuario;
import com.example.MSAuth.repository.UsuarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
public class UsuarioService {

    @Autowired
    private UsuarioRepository usuarioRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    // 1. CREATE (Guardar usuario con contraseña encriptada)
    public Usuario register(String username, String password, String email, String rol, boolean activo) {
        Usuario usuario = Usuario.builder()
                .username(username)
                .email(email)
                .password(passwordEncoder.encode(password))
                .rol(rol)
                .activo(activo)
                .build();

        return usuarioRepository.save(usuario);
    }

    // 2. READ (Obtener todos)
    public List<Usuario> obtenerTodos() {
        return usuarioRepository.findAll();
    }

    // 3. UPDATE
    public Usuario actualizarUsuario(Long id, Usuario datosActualizados) {
        return usuarioRepository.findById(id).map(usuario -> {
            usuario.setActivo(datosActualizados.getActivo());

            // Solo re-encriptar si el usuario envía una nueva contraseña
            if (datosActualizados.getPassword() != null && !datosActualizados.getPassword().isEmpty()) {
                usuario.setPassword(passwordEncoder.encode(datosActualizados.getPassword()));
            }
            return usuarioRepository.save(usuario);
        }).orElseThrow(() -> new RuntimeException("Usuario no encontrado con id: " + id));
    }
    public Usuario findById(Long id){
        return usuarioRepository.findById(id).get();
    }
    public Optional<Usuario> findByUsername(String username) {
        return usuarioRepository.findByUsername(username);
    }
    public Optional<Usuario> findByEmail(String email) {
        return usuarioRepository.findByEmail(email);
    }

}