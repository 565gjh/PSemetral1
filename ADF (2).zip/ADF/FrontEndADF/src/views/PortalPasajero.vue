<template>
  <div class="portal-wrapper">
    
    <div class="welcome-banner">
      <div class="welcome-text">
        <h2 class="welcome-title">Bienvenido/a, {{ userName }}</h2>
        <p class="welcome-subtitle">Gestione sus Declaraciones Juradas de ingreso a Chile de forma rápida y segura.</p>
      </div>
      <button class="btn-logout" @click="handleLogout">
        Cerrar Sesión
      </button>
    </div>

    <div class="alert-banner">
      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="alert-icon"><path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3Z"></path><line x1="12" y1="9" x2="12" y2="13"></line><line x1="12" y1="17" x2="12.01" y2="17"></line></svg>
      <div>
        <strong>Importante:</strong> Todo producto de origen vegetal o animal debe ser declarado. Evite multas y colabore con la protección fito y zoosanitaria de Chile.
      </div>
    </div>

    <div class="dashboard-grid">
      
      <div class="action-card primary-action">
        <div class="action-icon-wrapper">
          <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline><line x1="16" y1="13" x2="8" y2="13"></line><line x1="16" y1="17" x2="8" y2="17"></line><polyline points="10 9 9 9 8 9"></polyline></svg>
        </div>
        <div class="action-content">
          <h3>Nueva Declaración Jurada</h3>
          <p>Complete su formulario SAG y de Aduanas antes de llegar al control fronterizo para agilizar su ingreso.</p>
          <button class="btn-primary" @click="iniciarDeclaracion">
            Iniciar Declaración
          </button>
        </div>
      </div>

      <div class="action-card secondary-action">
        <h3>¿Qué debo declarar?</h3>
        <ul class="help-list">
          <li>Frutas, verduras, semillas y plantas.</li>
          <li>Carnes, fiambres, lácteos y quesos.</li>
          <li>Artesanías en madera sin tratar.</li>
          <li>Dinero en efectivo superior a 10.000 USD.</li>
        </ul>
        <a href="#" class="link-more">Ver listado completo →</a>
      </div>

    </div>

    <div class="history-section">
      <div class="history-header">
        <h3>Mis Declaraciones Recientes</h3>
      </div>
      
      <div class="table-container">
        <table class="data-table">
          <thead>
            <tr>
              <th>FECHA</th>
              <th>CÓDIGO DECLARACIÓN</th>
              <th>PASO FRONTERIZO</th>
              <th>ESTADO</th>
              <th>ACCIÓN</th>
            </tr>
          </thead>
          <tbody>
            <tr v-if="declaraciones.length === 0">
              <td colspan="5" class="empty-state">No tiene declaraciones recientes.</td>
            </tr>
            <tr v-for="decl in declaraciones" :key="decl.id">
              <td>{{ decl.fecha }}</td>
              <td class="font-mono">{{ decl.codigo }}</td>
              <td>{{ decl.paso }}</td>
              <td>
                <span :class="['status-badge', decl.estado.toLowerCase()]">
                  {{ decl.estado }}
                </span>
              </td>
              <td>
                <button class="btn-text">Ver detalle</button>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>

  </div>
</template>

<script setup>
import { ref } from 'vue';
import { useRouter } from 'vue-router';

const router = useRouter();

// Estos datos luego vendrán de un endpoint de tu backend (ej. /api/v1/pasajeros/perfil)
const userName = ref('Pasajero'); 

// Mock de datos para ver el diseño funcional de la tabla
const declaraciones = ref([
  { id: 1, fecha: '15-06-2026', codigo: 'DEC-8823-SAG', paso: 'Los Libertadores', estado: 'Aprobado' },
  { id: 2, fecha: '10-01-2026', codigo: 'DEC-1194-SAG', paso: 'Arturo Merino Benítez', estado: 'Inspeccionado' }
]);

const iniciarDeclaracion = () => {
  // Redirigir al flujo de declaración
  // router.push('/declaracion/nueva');
  alert('Iniciando flujo de Declaración Jurada...');
};

const handleLogout = () => {
  localStorage.clear();
  router.push('/');
};
</script>

<style scoped>
.portal-wrapper {
  max-width: 1000px;
  margin: 32px auto;
  padding: 0 20px;
  display: flex;
  flex-direction: column;
  gap: 24px;
}

/* Banner Superior */
.welcome-banner {
  display: flex;
  justify-content: space-between;
  align-items: center;
  background-color: #ffffff;
  padding: 24px;
  border-radius: 8px;
  box-shadow: 0 1px 3px rgba(0,0,0,0.1);
  border: 1px solid #E5E7EB;
}

.welcome-title {
  font-size: 20px;
  font-weight: 700;
  color: var(--brand-blue, #0F69B4);
  margin: 0 0 4px 0;
}

.welcome-subtitle {
  color: #6B7280;
  font-size: 14px;
  margin: 0;
}

.btn-logout {
  background: none;
  border: 1px solid #D1D5DB;
  padding: 8px 16px;
  border-radius: 6px;
  font-size: 13px;
  font-weight: 600;
  color: #4B5563;
  cursor: pointer;
  transition: all 0.2s;
}

.btn-logout:hover {
  background-color: #F3F4F6;
  color: #111827;
}

/* Alerta */
.alert-banner {
  display: flex;
  gap: 12px;
  background-color: #FFFBEB;
  border-left: 4px solid #F59E0B;
  padding: 16px;
  border-radius: 6px;
  color: #92400E;
  font-size: 14px;
  align-items: flex-start;
}

.alert-icon {
  flex-shrink: 0;
  color: #D97706;
}

/* Grilla de Acciones */
.dashboard-grid {
  display: grid;
  grid-template-columns: 2fr 1fr;
  gap: 20px;
}

@media (max-width: 768px) {
  .dashboard-grid {
    grid-template-columns: 1fr;
  }
}

.action-card {
  background-color: #ffffff;
  padding: 24px;
  border-radius: 8px;
  box-shadow: 0 1px 3px rgba(0,0,0,0.1);
  border: 1px solid #E5E7EB;
}

.primary-action {
  display: flex;
  gap: 20px;
  align-items: center;
}

.action-icon-wrapper {
  background-color: #EFF6FF;
  color: var(--brand-blue, #0F69B4);
  padding: 16px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
}

.action-content h3 {
  margin: 0 0 8px 0;
  font-size: 18px;
  color: #111827;
}

.action-content p {
  color: #6B7280;
  font-size: 14px;
  margin: 0 0 16px 0;
  line-height: 1.5;
}

.btn-primary {
  background-color: var(--brand-blue, #0F69B4);
  color: white;
  border: none;
  padding: 10px 20px;
  border-radius: 6px;
  font-size: 14px;
  font-weight: 600;
  cursor: pointer;
  transition: background-color 0.2s;
}

.btn-primary:hover {
  background-color: #001a5c;
}

.secondary-action h3 {
  margin: 0 0 12px 0;
  font-size: 16px;
  color: #111827;
}

.help-list {
  margin: 0 0 16px 0;
  padding-left: 20px;
  color: #4B5563;
  font-size: 13px;
  line-height: 1.6;
}

.link-more {
  font-size: 13px;
  color: var(--brand-blue, #0F69B4);
  text-decoration: none;
  font-weight: 600;
}

.link-more:hover {
  text-decoration: underline;
}

/* Sección de Historial */
.history-section {
  background-color: #ffffff;
  border-radius: 8px;
  box-shadow: 0 1px 3px rgba(0,0,0,0.1);
  border: 1px solid #E5E7EB;
  overflow: hidden;
}

.history-header {
  padding: 16px 20px;
  border-bottom: 1px solid #E5E7EB;
  background-color: #F9FAFB;
}

.history-header h3 {
  margin: 0;
  font-size: 15px;
  color: #111827;
}

/* Tabla */
.table-container {
  overflow-x: auto;
}

.data-table {
  width: 100%;
  border-collapse: collapse;
  text-align: left;
}

.data-table th {
  padding: 12px 20px;
  font-size: 11px;
  font-weight: 700;
  color: #6B7280;
  text-transform: uppercase;
  letter-spacing: 0.5px;
  border-bottom: 1px solid #E5E7EB;
}

.data-table td {
  padding: 14px 20px;
  font-size: 14px;
  color: #111827;
  border-bottom: 1px solid #E5E7EB;
}

.data-table tr:last-child td {
  border-bottom: none;
}

.font-mono {
  font-family: monospace;
  color: #4B5563;
}

.empty-state {
  text-align: center;
  color: #9CA3AF;
  padding: 32px !important;
}

/* Botón de texto en la tabla */
.btn-text {
  background: none;
  border: none;
  color: var(--brand-blue, #0F69B4);
  font-size: 13px;
  font-weight: 600;
  cursor: pointer;
  padding: 0;
}

.btn-text:hover {
  text-decoration: underline;
}

/* Badges de Estado */
.status-badge {
  padding: 4px 10px;
  border-radius: 20px;
  font-size: 12px;
  font-weight: 600;
}

.status-badge.aprobado {
  background-color: #DEF7EC;
  color: #03543F;
}

.status-badge.inspeccionado {
  background-color: #FEF3C7;
  color: #92400E;
}

.status-badge.pendiente {
  background-color: #E0E7FF;
  color: #3730A3;
}
</style>