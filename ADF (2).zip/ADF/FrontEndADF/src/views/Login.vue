<template>
  <div class="login-wrapper">
    <div class="brand-corner">
      <img src="../assets/logoAduana.png" alt="Aduanas de Chile" class="logo-aduana-top">
    </div>
    <div class="login-card">
      <div class="login-header">
        <h2 class="login-title">Acceso a Plataforma</h2>
        <p class="login-subtitle">Ingrese sus credenciales para continuar</p>
      </div>

      <form @submit.prevent="handleLogin" class="login-form">
        
        <div class="form-group">
          <label for="rut">Identificador (RUT / Pasaporte / DNI)</label>
          <input 
            type="text" 
            id="rut" 
            v-model="rut"
            placeholder="Ej: 12345678-9 o AB123456" 
            required
            :disabled="isLoading"
            autocomplete="username"
          >
        </div>

        <div class="form-group">
          <div class="label-row">
            <label for="password">Contraseña</label>
            <a href="#" class="forgot-password">¿Olvidó su contraseña?</a>
          </div>
          <div class="password-wrapper">
            <input 
              :type="showPassword ? 'text' : 'password'" 
              id="password" 
              v-model="password" 
              placeholder="••••••••" 
              required
              :disabled="isLoading"
              autocomplete="current-password"
            >
            <button type="button" class="btn-toggle-pass" @click="showPassword = !showPassword" tabindex="-1">
              <svg v-if="!showPassword" xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"></path><line x1="1" y1="1" x2="23" y2="23"></line></svg>
              <svg v-else xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path><circle cx="12" cy="12" r="3"></circle></svg>
            </button>
          </div>
        </div>

        <div v-if="errorMessage" class="error-banner">
          {{ errorMessage }}
        </div>

        <button type="submit" class="btn-primary" :disabled="isLoading">
          <span v-if="isLoading" class="spinner"></span>
          {{ isLoading ? 'Validando...' : 'Ingresar' }}
        </button>

        <div class="registration-area">
          <div class="divider">
            <span>¿Primera vez en el portal?</span>
          </div>
          
          <router-link to="/RegisterPassenger" class="btn-outline-register">
            Registrarse como Pasajero
          </router-link>
        </div>

      </form>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import { useRouter } from 'vue-router';

const router = useRouter();

const rut = ref('');
const password = ref('');
const showPassword = ref(false);
const isLoading = ref(false);
const errorMessage = ref('');

// Función para decodificar el JWT
const parseJwt = (token) => {
  try {
    const base64Url = token.split('.')[1];
    const base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
    const jsonPayload = decodeURIComponent(window.atob(base64).split('').map(function(c) {
        return '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2);
    }).join(''));
    return JSON.parse(jsonPayload);
  } catch (error) {
    console.error("Error al decodificar el token", error);
    return null;
  }
};

const handleLogin = async () => {
  errorMessage.value = '';
  isLoading.value = true;

  try {
    const cleanIdentifier = rut.value.trim();
    
    const response = await fetch('/api/v1/auth/login', {
      method: 'POST',
      headers: { 
        'Content-Type': 'application/json',
        'Accept': 'application/json'
      },
      body: JSON.stringify({ rut: cleanIdentifier, password: password.value })
    });
    
    const responseText = await response.text();
    let data = {};
    
    try {
      data = JSON.parse(responseText);
    } catch (e) {
      data = { message: responseText };
    }

    if (!response.ok) {
      throw new Error(data.message || 'Error de acceso. Credenciales incorrectas.');
    }

    if (data.token) {
      localStorage.setItem('user_token', data.token);

      const tokenData = parseJwt(data.token);
      // Buscamos el rol principal (Ej: ROLE_PASAJERO, ROLE_ADUANA, ROLE_SAG, ROLE_PDI)
      const userRole = tokenData.permisos.find(permiso => permiso.startsWith('ROLE_'));

      if (userRole) {
        // Guardamos el rol oficial en la memoria del navegador
        localStorage.setItem('user_role', userRole);

        // 🔀 ENRUTAMIENTO INTELIGENTE PARA LOS 4 PERFILES
        switch (userRole) {
          case 'ROLE_PASAJERO':
            router.push('/portal-pasajero');
            break;
            
          case 'ROLE_ADUANA': // o ROLE_ADUANERO, según como venga exactamente de tu Spring Boot
            router.push('/dashboard-aduana');
            break;
            
          case 'ROLE_SAG':
            router.push('/dashboard-sag');
            break;
            
          case 'ROLE_PDI':
            router.push('/dashboard-pdi');
            break;
            
          default:
            throw new Error('Rol institucional no reconocido en el sistema.');
        }
      } else {
        throw new Error('El token no contiene un rol de acceso válido.');
      }
    }

  } catch (error) {
    errorMessage.value = error.message;
  } finally {
    isLoading.value = false;
  }
};
</script>

<style scoped>
.login-wrapper {
  /* 🛡️ Cambiamos a 'fixed' y agregamos un z-index alto */
  position: fixed;
  top: 0;
  left: 0;
  width: 100vw;
  height: 100vh;
  z-index: 9999; /* Pasa por encima de cualquier layout o margen blanco */

  /* Fondo */
  background-image: 
    linear-gradient(rgba(11, 26, 41, 0.75), rgba(11, 26, 41, 0.75)), 
    url('../assets/PasoLosLibertadores.jpg');
  background-size: cover;
  background-position: center;
  background-repeat: no-repeat;
  background-color: #0b1a29;
}
/* 🏔️ POSICIONAMIENTO DEL LOGO EN LA ESQUINA */
.brand-corner {
  position: absolute;
  top: 20px;
  left: 20px;
  background-color: rgba(255, 255, 255, 0.95); /* Fondo blanco limpio para el logo */
  padding: 12px 20px;
  border-radius: 8px;
  box-shadow: 0 4px 15px rgba(0, 0, 0, 0.3);
  display: flex;
  align-items: center;
  justify-content: center;
}

.logo-aduana-top {
  height: 65px; /* Tamaño ideal para que se lean bien todos los textos del PNG */
  width: auto;
  display: block;
}

.login-card {
  /* 🚀 EL TRUCO DE CENTRADO ABSOLUTO IMMUNE A ERRORES */
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%); /* Se mueve exactamente a su propio centro */
  
  /* Diseño de la tarjeta */
  background-color: #ffffff;
  padding: 40px;
  border-radius: 12px;
  box-shadow: 0 10px 30px rgba(0, 0, 0, 0.6);
  width: 100%;
  max-width: 420px;
  box-sizing: border-box;
  
  /* Reseteamos márgenes heredados por si acaso */
  margin: 0; 
  text-align: left; /* Asegura que los textos internos no se vuelvan locos */
}
.login-header {
  text-align: center;
  margin-bottom: 32px;
}

.login-title {
  color: var(--brand-blue);
  font-size: 22px;
  font-weight: 700;
  margin: 0 0 6px 0;
}

.login-subtitle {
  color: var(--text-secondary);
  font-size: 14px;
  margin: 0;
}

.login-form {
  display: flex;
  flex-direction: column;
  gap: 18px;
}

.form-group {
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.label-row {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.form-group label {
  font-size: 13px;
  font-weight: 600;
  color: var(--text-primary);
}

.forgot-password {
  font-size: 12px;
  color: var(--brand-blue);
  text-decoration: none;
  font-weight: 500;
}

.forgot-password:hover {
  text-decoration: underline;
}

.form-group input {
  width: 100%;
  padding: 12px 14px;
  border: 1px solid #D1D5DB;
  border-radius: 6px;
  font-size: 14px;
  outline: none;
  transition: border-color 0.2s ease;
  box-sizing: border-box;
}

.form-group input:focus {
  border-color: var(--brand-blue);
  box-shadow: 0 0 0 3px rgba(0, 40, 132, 0.1);
}

.password-wrapper {
  position: relative;
  display: flex;
  align-items: center;
}

.btn-toggle-pass {
  position: absolute;
  right: 12px;
  background: none; border: none; color: #9CA3AF; cursor: pointer;
}

.btn-primary {
  background-color: var(--brand-blue);
  color: var(--text-white);
  border: none;
  padding: 12px;
  border-radius: 6px;
  font-size: 15px;
  font-weight: 600;
  cursor: pointer;
  transition: background-color 0.2s;
  display: flex; justify-content: center; align-items: center; gap: 8px;
}

.btn-primary:hover:not(:disabled) { background-color: #001a5c; }

/* Estilos de la Nueva Sección de Registro */
.registration-area {
  margin-top: 10px;
  display: flex;
  flex-direction: column;
  gap: 16px;
}

.divider {
  display: flex;
  align-items: center;
  text-align: center;
  color: var(--text-secondary);
  font-size: 13px;
}

.divider::before, .divider::after {
  content: '';
  flex: 1;
  border-bottom: 1px solid #E5E7EB;
}

.divider span {
  padding: 0 10px;
}

.btn-outline-register {
  background-color: transparent;
  color: var(--brand-blue);
  border: 1px solid var(--brand-blue);
  padding: 12px;
  border-radius: 6px;
  font-size: 14px;
  font-weight: 600;
  text-align: center;
  text-decoration: none;
  transition: all 0.2s;
}

.btn-outline-register:hover {
  background-color: rgba(0, 40, 132, 0.05);
  border-color: #001a5c;
  color: #001a5c;
}

.error-banner {
  background-color: #FDE8E8; color: #9B1C1C; border-left: 4px solid #D52B1E;
  padding: 12px; border-radius: 6px; font-size: 13px;
}

.spinner {
  width: 16px; height: 16px; border: 2px solid rgba(255,255,255,0.3);
  border-radius: 50%; border-top-color: #fff; animation: spin 0.8s linear infinite;
}
@keyframes spin { to { transform: rotate(360deg); } }
</style>