<template>
  <MainLayout>
    <router-view />
  </MainLayout>
</template>

<script setup>
import MainLayout from './components/MainLayout.vue';
// Eliminamos la importación de Login desde aquí, ya que ahora lo maneja el router
</script>

<style>
/* Reseteo global de márgenes */
body {
  margin: 0;
  padding: 0;
  background-color: #F4F6F8;
  font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
}
</style>