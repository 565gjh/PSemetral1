<template>
  <div class="app-container">
    <header class="main-header">
      <div class="header-left">
        <img src="../assets/Flag_of_Chile.png" alt="Bandera de Chile" class="chile-flag" />
        
        <div class="header-titles">
          <span class="gov-subtitle">GOBIERNO DE CHILE</span>
          <h1 class="gov-title">Servicio Nacional de Aduanas</h1>
        </div>
      </div>
      
      <div class="header-right">
        <slot name="user-actions"></slot>
      </div>
    </header>
    <div class="sub-header sag-theme">
      <div class="sub-header-wrapper">
        <span class="institution-name">Servicio Agrícola y Ganadero — Control Fitosanitario Paso Los Libertadores</span>
        <span class="current-date">01-07-2026</span>
      </div>
    </div>

    <main class="main-content">
      <slot></slot>
    </main>
  </div>
</template>

<script setup>
// Vite requiere al menos un template o un script. 
// Dejamos este script setup listo para cuando necesitemos agregar lógica al layout.
</script>

<style>
/* VARIABLES GLOBALES */
:root {
  --brand-blue: #002884;
  --brand-red: #D52B1E;
  --bg-app: #F4F6F8;
  --bg-card: #FFFFFF;
  --theme-sag-green: #1E7B44;
  
  --text-primary: #1F2937;
  --text-secondary: #6B7280;
  --text-white: #FFFFFF;
  
  --font-family: system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
}

/* ESTILOS DEL LAYOUT */
.app-container {
  min-height: 100vh;
  background-color: var(--bg-app);
  font-family: var(--font-family);
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}

/* Barra Superior */
.main-header {
  background-color: var(--brand-blue);
  border-top: 3px solid var(--brand-red);
  color: var(--text-white);
  padding: 12px 24px;
  display: flex;
  justify-content: space-between;
  align-items: center;
}

/* Cambiamos esto para que la bandera y los textos estén uno al lado del otro */
.header-left {
  display: flex;
  align-items: center; /* Centra verticalmente la bandera y los textos */
  gap: 16px; /* Da un espacio agradable entre la bandera y las letras */
}

/* Estilos específicos para la bandera */
.chile-flag {
  height: 38px; /* Ajusta este valor si la quieres más grande o pequeña */
  width: auto;
  border-radius: 2px; /* Un pequeñísimo borde redondeado para que se vea moderna */
  box-shadow: 0 1px 3px rgba(0,0,0,0.2); /* Una sombra sutil para darle profundidad */
}

/* Los textos vuelven a estar en columna */
.header-titles {
  display: flex;
  flex-direction: column;
}

.gov-subtitle {
  font-size: 11px;
  font-weight: 600;
  letter-spacing: 1px;
  opacity: 0.8;
  margin-bottom: 2px;
}

.gov-title {
  font-size: 18px;
  font-weight: 700;
  margin: 0;
}

/* Sub-barra Institucional */
.sub-header {
  color: var(--text-white);
  padding: 8px 24px;
  font-size: 13px;
  font-weight: 500;
}

.sag-theme {
  background-color: var(--theme-sag-green);
}

.sub-header-wrapper {
  max-width: 1440px;
  margin: 0 auto;
  display: flex;
  justify-content: space-between;
  align-items: center;
}

/* Contenedor Principal (Donde va el contenido) */
.main-content {
  max-width: 1440px;
  margin: 0 auto;
  padding: 24px;
}
</style>