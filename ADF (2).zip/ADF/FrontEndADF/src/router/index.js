import { createRouter, createWebHistory } from 'vue-router'
import Login from '../views/Login.vue'
import RegisterPassenger from '../views/RegisterPassenger.vue'
import PortalPasajero from '../views/PortalPasajero.vue'
import DashboardAduana from '../views/DashboardFuncionario.vue' // El que creamos recién
 import DashboardSag from '../views/DashboardSag.vue'  
 import DashboardPdi from '../views/DashboardPdi.vue'

const routes = [
  {
    path: '/',
    name: 'Login',
    component: Login
  },
  {
    path: '/RegisterPassenger',
    name: 'RegisterPassenger',
    component: RegisterPassenger
  },
  {
    path: '/portal-pasajero',
    name: 'PortalPasajero',
    component: PortalPasajero
  },
  {
    path: '/dashboard-aduana',
    name: 'DashboardAduana',
    component: DashboardAduana
  },
  {
    path: '/dashboard-sag',
    name: 'DashboardSag',
    component: DashboardSag // Temporalmente al login hasta que crees la vista
  },
  {
    path: '/dashboard-pdi',
    name: 'DashboardPdi',
    component: DashboardPdi
  }
]

const router = createRouter({
  history: createWebHistory(),
  routes
})

export default router