package com.example.MsMigracion.controller;

import com.example.MsMigracion.model.RegistroMigratorio;
import com.example.MsMigracion.repository.MigracionRepository;
import com.example.MsMigracion.service.MigracionService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;
@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/api/v1/migracion")
public class MigracionController {

    // Ahora inyectamos correctamente el Service, cumpliendo con la arquitectura en capas
    private final MigracionService service;

    public MigracionController(MigracionService service) {
        this.service = service;
    }

    // Endpoint 1: El funcionario PDI registra a un pasajero
    @PostMapping("/pasajero")
    @PreAuthorize("hasRole('PDI')") // Solo la PDI puede hacer esto (si ya tienes MS_Auth activo)
    public ResponseEntity<RegistroMigratorio> registrarControl(@RequestBody RegistroMigratorio registro) {
        // La validación del menor de edad y el guardado ocurren en el Service
        RegistroMigratorio guardado = service.registrarPasajero(registro);
        return ResponseEntity.ok(guardado);
    }

    // Endpoint 2: Para que la PDI vea quiénes van en un auto específico
    @GetMapping("/vehiculo/{patente}")
    @PreAuthorize("hasRole('PDI')")
    public ResponseEntity<List<RegistroMigratorio>> listarPasajerosPorVehiculo(@PathVariable String patente) {
        // Delegamos la búsqueda al Service
        return ResponseEntity.ok(service.obtenerPasajerosPorVehiculo(patente));
    }

    // Endpoint 3: Comunicación INTERNA entre Microservicios (Llamado por el MS_Vehiculo / PdiClient)
    @GetMapping("/vehiculo/{patente}/autorizacion-cruce")
    public ResponseEntity<Boolean> verificarAutorizacionCruce(@PathVariable String patente) {
        // El Service hace toda la lógica para verificar si TODOS están aprobados
        boolean autorizados = service.verificarAutorizacionCruce(patente);
        return ResponseEntity.ok(autorizados);
    }
    @GetMapping
    @PreAuthorize("hasRole('PDI')")
    public ResponseEntity<List<RegistroMigratorio>> listarTodos() {
        return ResponseEntity.ok(service.obtenerTodos());
    }
}