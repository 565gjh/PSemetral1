package com.example.MsMigracion.repository;

import com.example.MsMigracion.model.RegistroMigratorio;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface MigracionRepository extends JpaRepository<RegistroMigratorio, Long> {

    // Spring deduce la consulta automáticamente basándose en el nombre de la variable "patenteVehiculoAsociado"
    List<RegistroMigratorio> findByPatenteVehiculoAsociado(String patente);

    // Opcional: Si en el futuro necesitas buscar a una persona específica por su RUT/Pasaporte
    boolean existsByDocumentoIdentidad(String documentoIdentidad);
}
