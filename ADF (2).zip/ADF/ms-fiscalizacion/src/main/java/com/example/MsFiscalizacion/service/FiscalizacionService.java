package com.example.MsFiscalizacion.service;

import com.example.MsFiscalizacion.model.DeclaracionSag;
import com.example.MsFiscalizacion.repository.FiscalizacionRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class FiscalizacionService {

    private final FiscalizacionRepository repository;

    public FiscalizacionService(FiscalizacionRepository repository) {
        this.repository = repository;
    }

    /**
     * Procesa la declaración inicial enviada desde el Frontend (React).
     */
    public DeclaracionSag procesarNuevaDeclaracion(DeclaracionSag declaracion) {

        // Usamos la regla de negocio que creamos en la Entidad
        if (declaracion.requiereInspeccionFisica()) {
            declaracion.setEstadoFiscalizacion("RETENIDO_PARA_INSPECCION");
            System.out.println("ALERTA SAG: Vehículo requiere inspección física en maletero.");
        } else {
            declaracion.setEstadoFiscalizacion("APROBADO");
            System.out.println("SAG: Declaración sin riesgos. Aprobación automática.");
        }

        return repository.save(declaracion);
    }

    /**
     * Método para que el inspector SAG actualice el estado manualmente
     * después de abrir el maletero o revisar a la mascota.
     */
    public DeclaracionSag resolverInspeccionManual(String patente, boolean apruebaInspector, String observaciones) {
        Optional<DeclaracionSag> optDeclaracion = repository.findTopByPatenteVehiculoAsociadoOrderByFechaDeclaracionDesc(patente);

        if (optDeclaracion.isEmpty()) {
            throw new RuntimeException("No existe declaración para la patente: " + patente);
        }

        DeclaracionSag declaracion = optDeclaracion.get();

        if (apruebaInspector) {
            declaracion.setEstadoFiscalizacion("APROBADO");
        } else {
            declaracion.setEstadoFiscalizacion("RECHAZADO_PRODUCTO_PROHIBIDO");
        }

        return repository.save(declaracion);
    }

    /**
     * Método INTERNO que responde a la consulta del MS_Vehiculo (Aduanas).
     */
    public String obtenerEstadoParaAduanas(String patente) {
        Optional<DeclaracionSag> declaracion = repository.findTopByPatenteVehiculoAsociadoOrderByFechaDeclaracionDesc(patente);

        // Si no hay declaración, el SAG aún no los procesa
        if (declaracion.isEmpty()) {
            return "PENDIENTE_DE_DECLARACION";
        }

        // Devolvemos el estado actual ("APROBADO", "RETENIDO_PARA_INSPECCION", etc.)
        return declaracion.get().getEstadoFiscalizacion();
    }
    public List<DeclaracionSag> obtenerTodos() {
        return repository.findAll();
    }
}





