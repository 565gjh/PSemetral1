package com.example.MsFiscalizacion.repository;

import com.example.MsFiscalizacion.model.DeclaracionSag;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface FiscalizacionRepository extends JpaRepository<DeclaracionSag, Long> {

    // Usamos Optional porque un auto puede o no haber llenado el formulario aún
    Optional<DeclaracionSag> findTopByPatenteVehiculoAsociadoOrderByFechaDeclaracionDesc(String patente);
}
