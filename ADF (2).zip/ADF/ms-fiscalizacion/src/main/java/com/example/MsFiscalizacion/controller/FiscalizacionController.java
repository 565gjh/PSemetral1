package com.example.MsFiscalizacion.controller;

import com.example.MsFiscalizacion.model.DeclaracionSag;
import com.example.MsFiscalizacion.service.FiscalizacionService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/api/v1/fiscalizacion")
public class FiscalizacionController {

    private final FiscalizacionService service;

    public FiscalizacionController(FiscalizacionService service) {
        this.service = service;
    }

    // --- ENDPOINTS PARA EL FRONTEND (Funcionarios SAG / Pasajeros) ---

    @PostMapping("/declaracion")
    public ResponseEntity<DeclaracionSag> crearDeclaracion(@RequestBody DeclaracionSag declaracion) {
        return ResponseEntity.ok(service.procesarNuevaDeclaracion(declaracion));
    }

    @PutMapping("/vehiculo/{patente}/inspeccion")
    @PreAuthorize("hasRole('SAG')") // Solo un funcionario real del SAG puede hacer esto
    public ResponseEntity<DeclaracionSag> registrarResultadoInspeccionFisica(
            @PathVariable String patente,
            @RequestParam boolean aprobado,
            @RequestParam(required = false) String observaciones) {

        return ResponseEntity.ok(service.resolverInspeccionManual(patente, aprobado, observaciones));
    }

    // --- ENDPOINT INTERNO (Para tu MS_Vehiculo) ---

    @GetMapping("/vehiculo/{patente}/estado")
    public ResponseEntity<String> consultarEstadoParaAduanas(@PathVariable String patente) {
        return ResponseEntity.ok(service.obtenerEstadoParaAduanas(patente));
    }
    @GetMapping
    @PreAuthorize("hasRole('SAG')")
    public ResponseEntity<List<DeclaracionSag>> listarTodos() {
        return ResponseEntity.ok(service.obtenerTodos());
    }
}