package com.example.MsFiscalizacion.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import java.time.LocalDateTime;


@Entity
@Data
@AllArgsConstructor
@Builder
@Table(name = "declaraciones_sag")
public class DeclaracionSag {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // --- Clave de Correlación ---
    @Column(nullable = false, length = 10)
    private String patenteVehiculoAsociado;

    // --- Datos del Conductor / Declarante ---
    @Column(nullable = false)
    private String documentoDeclarante; // RUT o Pasaporte del que maneja

    // --- Formulario de Declaración Jurada ---
    @Column(nullable = false)
    private Boolean traeProductosOrganicos; // Frutas, carnes, maderas

    @Column(nullable = false)
    private Boolean traeMascotas;

    // --- Si trae mascotas, se requiere folio del certificado zoosanitario ---
    private String folioCertificadoMascota;

    // --- Estado de la Inspección SAG ---
    // Ej: "APROBADO", "RETENIDO_PARA_INSPECCION", "RECHAZADO_PRODUCTO_PROHIBIDO"
    @Column(nullable = false)
    private String estadoFiscalizacion;

    private LocalDateTime fechaDeclaracion;

    public DeclaracionSag() {
        this.fechaDeclaracion = LocalDateTime.now();
    }

    // --- REGLAS DE NEGOCIO ENCAPSULADAS ---

    /**
     * Verifica si la declaración está lista para ser aprobada automáticamente,
     * o si requiere que el inspector SAG vaya físicamente a revisar el maletero.
     */
    @Transient
    public boolean requiereInspeccionFisica() {
        // Si declaran traer frutas/carne, el SAG DEBE ir a revisar qué es
        if (Boolean.TRUE.equals(this.traeProductosOrganicos)) {
            return true;
        }

        // Si traen mascota pero no subieron el folio del certificado, el SAG debe revisar
        if (Boolean.TRUE.equals(this.traeMascotas) &&
                (this.folioCertificadoMascota == null || this.folioCertificadoMascota.isEmpty())) {
            return true;
        }

        return false;
    }

    // Getters y Setters...
}