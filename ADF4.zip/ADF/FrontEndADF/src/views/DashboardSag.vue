<template>
  <div class="dashboard-container">
    <aside class="sidebar">
      <div class="brand">
        <img src="../assets/SAG_logocolor_granderRGB.jpg" alt="Logo SAG Chile" class="logo-sag">
      </div>
      
      <nav class="menu">
        <button class="menu-item active">
          <i>🌱</i> Inspección de Ingreso
        </button>
        <button class="menu-item">
          <i>📄</i> Declaraciones Juradas (DJ)
        </button>
        <button class="menu-item">
          <i>🐕</i> Brigada Canina
        </button>
      </nav>

      <div class="sidebar-footer">
        <div class="user-info">
          <p class="user-name">Inspector SAG</p>
          <p class="user-rut">RUT: {{ officerRut }}</p>
        </div>
        <button @click="handleLogout" class="btn-logout">Cerrar Sesión</button>
      </div>
    </aside>

    <main class="main-content">
  <div class="dashboard-white-card">
    
    <header class="content-header">
      <div class="welcome">
        <h1>Portal de Protección Agrícola y Forestal</h1>
        <p>Supervisión de barreras sanitarias y control de riesgos biológicos en frontera.</p>
      </div>
      <div class="date-badge">
        📅 {{ currentDate }}
      </div>
    </header>

    <section class="stats-grid">
      <div class="stat-card">
        <div class="stat-icon green-light">📄</div>
        <div>
          <h3>Declaraciones Revisadas</h3>
          <p class="stat-number">1,420</p>
        </div>
      </div>
      <div class="stat-card alert">
        <div class="stat-icon red">🚫</div>
        <div>
          <h3>Productos Interceptados</h3>
          <p class="stat-number">12</p>
        </div>
      </div>
      <div class="stat-card">
        <div class="stat-icon green-dark">🔬</div>
        <div>
          <h3>Muestras a Laboratorio</h3>
          <p class="stat-number">2</p>
        </div>
      </div>
    </section>

    <section class="work-panel">
      <div class="panel-header">
        <div>
          <h2>Fila de Fiscalización Sanitaria</h2>
          <p class="panel-subtitle">Sincronizado con endpoint: GET /api/v1/fiscalizacion</p>
        </div>
        <button @click="obtenerFiscalizaciones" class="btn-primary" :disabled="isLoading">
          <span v-if="isLoading">🔄 Consultando...</span>
          <span v-else>🔄 Sincronizar Fila</span>
        </button>
      </div>

      <div v-if="isLoading" class="loading-state">
        <div class="spinner"></div>
        <p>Consultando registros al microservicio del SAG...</p>
      </div>
      
      <div v-else-if="errorApi" class="error-state">
        <div class="error-icon">⚠️</div>
        <p>{{ errorApi }}</p>
        <button @click="obtenerFiscalizaciones" class="btn-retry">Reintentar Conexión</button>
      </div>

      <div v-else class="table-responsive">
        <table class="data-table">
          <thead>
            <tr>
              <th>Vehículo Asociado</th>
              <th>RUN/Doc Declarante</th>
              <th>¿Trae Orgánicos?</th>
              <th>¿Trae Mascotas? (Certificado)</th>
              <th>Fecha Declaración</th>
              <th>Estado Control</th>
              <th class="text-center">Acción</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="item in listaFiscalizaciones" :key="item.id" class="table-row">
              
              <td>
                <div class="ppu-container">
                  <span class="ppu-chile">CHILE</span>
                  <span class="ppu-text">{{ item.patenteVehiculoAsociado }}</span>
                </div>
              </td>
              
              <td class="font-mono font-bold text-dark">
                {{ item.documentoDeclarante }}
              </td>
              
              <td>
                <span :class="['organic-badge', item.traeProductosOrganicos ? 'yes' : 'no']">
                  {{ item.traeProductosOrganicos ? '📦 SÍ TRAE' : '✔ NADA' }}
                </span>
              </td>
              
              <td>
                <div class="mascota-info">
                  <span :class="['mascota-status', item.traeMascotas ? 'yes' : 'no']">
                    {{ item.traeMascotas ? '🐾 Con Mascota' : 'No' }}
                  </span>
                  <span v-if="item.traeMascotas" class="folio-text">
                    Folio: {{ item.folioCertificadoMascota || 'Sin Certificado' }}
                  </span>
                </div>
              </td>
              
              <td class="text-muted">
                {{ item.fechaDeclaracion ? formatFecha(item.fechaDeclaracion) : 'Pendiente (Presencial)' }}
              </td>
              
              <td>
                <span :class="['status-pill', item.estadoFiscalizacion.toLowerCase()]">
                  <span class="led-dot"></span>
                  {{ item.estadoFiscalizacion }}
                </span>
              </td>
              
              <td class="text-center">
                <button class="btn-action-inspect">
                  <span>Fiscalizar</span>
                </button>
              </td>
            </tr>
            
            <tr v-if="listaFiscalizaciones.length === 0">
              <td colspan="7" class="empty-state">
                📭 No hay solicitudes de fiscalización en la cola del SAG.
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </section>

  </div>
</main>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue';
import { useRouter } from 'vue-router';

const router = useRouter();
const officerRut = ref('Cargando...');
const currentDate = ref(new Date().toLocaleDateString('es-CL', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' }));

const listaFiscalizaciones = ref([]);
const isLoading = ref(true);
const errorApi = ref(null);

// Formateador de fecha simple
const formatFecha = (fechaStr) => {
  return new Date(fechaStr).toLocaleString('es-CL', { hour12: false });
};

const parseJwt = (token) => {
  try {
    const base64Url = token.split('.')[1];
    const base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
    return JSON.parse(window.atob(base64));
  } catch (e) {
    return null;
  }
};

const obtenerFiscalizaciones = async () => {
  isLoading.value = true;
  errorApi.value = null;
  try {
    const token = localStorage.getItem('user_token');
    
    // 🚀 Cambia el puerto si tu servicio SAG corre en otro distinto al 9094
    const response = await fetch('http://localhost:9094/api/v1/fiscalizacion', {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}` 
      }
    });

    if (!response.ok) {
      throw new Error(`Error en el servidor: ${response.status}`);
    }

    const data = await response.json();
    listaFiscalizaciones.value = data;
  } catch (err) {
    console.error("Error al conectar con el microservicio del SAG:", err);
    errorApi.value = "No se pudo sincronizar la cola de fiscalización. Compruebe el microservicio en el puerto 9093.";
  } finally {
    isLoading.value = false;
  }
};

onMounted(() => {
  const token = localStorage.getItem('user_token');
  if (!token) {
    router.push('/');
    return;
  }

  const tokenData = parseJwt(token);
  if (tokenData && tokenData.sub) {
    officerRut.value = tokenData.sub;
  }

  obtenerFiscalizaciones();
});

const handleLogout = () => {
  localStorage.clear();
  router.push('/');
};
</script>

<style scoped>

/* El fondo general que estará detrás de la tarjeta blanca */


/* La tarjeta blanca donde va todo tu contenido */
.dashboard-white-card {
  background-color: #f0fff4;
  border-radius: 12px;
  border: 1px solid #E5E7EB; /* Borde sutil gris claro */
  padding: 32px; /* Espacio interior para que nada toque los bordes blancos */
  max-width: 1400px;
  margin: 0 auto; /* Centra la tarjeta si la pantalla es inmensa */
  box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.05), 0 2px 4px -1px rgba(0, 0, 0, 0.03); /* Sombra elegante */
  min-height: 100%; /* Para que ocupe todo el alto disponible */
  box-sizing: border-box;
}

/* 🌍 Layout General */
.dashboard-container {
  display: flex;
  height: 100vh;
  width: 100vw;
  background-color: #f4f8f5;
  font-family: 'Segoe UI', system-ui, -apple-system, sans-serif;
  position: fixed;
  top: 0;
  left: 0;
}

/* 🗄 Well-Tailored Sidebar (SAG Verde Bosque) */
.sidebar {
  width: 260px;
  background-color: #114224;
  color: #ecf0f1;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  padding: 24px;
  box-shadow: 4px 0 10px rgba(0,0,0,0.05);
}

.brand .logo-sag {
    max-width: 100%; /* Ajusta el logo al ancho máximo de su contenedor */
    height: auto;    /* Mantiene las proporciones de la imagen */
    margin-bottom: 10px; /* Añade un pequeño espacio entre el logo y el badge */
    border-radius: 4px; /* Opcional: redondea ligeramente los bordes si lo deseas */
}

.badge-oficial { background-color: #16a34a; font-size: 0.7rem; padding: 3px 8px; border-radius: 50px; font-weight: 600; text-transform: uppercase; }
.menu { display: flex; flex-direction: column; gap: 8px; margin-top: 40px; flex-grow: 1; }
.menu-item {
  background: none; border: none; color: #a7cfb6; text-align: left; padding: 12px 16px; border-radius: 8px;
  cursor: pointer; font-size: 0.95rem; font-weight: 500; transition: all 0.2s ease; display: flex; align-items: center; gap: 10px;
}
.menu-item:hover, .menu-item.active { background-color: #1b5932; color: #fff; }
.menu-item.active { border-left: 4px solid #16a34a; }
.sidebar-footer { border-top: 1px solid #1b5932; padding-top: 20px; }
.user-name { font-weight: 600; margin: 0; font-size: 0.95rem;}
.user-rut { font-size: 0.8rem; color: #82b596; margin: 2px 0 15px 0; font-family: monospace; }
.btn-logout { width: 100%; background-color: #e74c3c; color: white; border: none; padding: 10px; border-radius: 6px; cursor: pointer; font-weight: 600; }
.btn-logout:hover { background-color: #c0392b; }

/* 🖥️ Main Content */
.main-content { flex-grow: 1; padding: 40px; overflow-y: auto; }
.content-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 30px; }
.content-header h1 { margin: 0 0 5px 0; color: #114224; font-size: 1.8rem; font-weight: 700; }
.content-header p { margin: 0; color: #526b5a; font-size: 0.95rem; }
.date-badge { background-color: #ffffff; padding: 10px 18px; border-radius: 30px; box-shadow: 0 2px 6px rgba(0,0,0,0.03); font-size: 0.85rem; font-weight: 600; color: #2b3a30; }

/* 📊 Grid de Estadísticas */
.stats-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 24px; margin-bottom: 35px; }
.stat-card { background: white; padding: 24px; border-radius: 16px; box-shadow: 0 4px 12px rgba(0,0,0,0.02); display: flex; align-items: center; gap: 20px; }
.stat-icon { width: 48px; height: 48px; border-radius: 12px; display: flex; align-items: center; justify-content: center; font-size: 1.4rem; }
.stat-icon.green-light { background-color: #dcfce7; }
.stat-icon.red { background-color: #fee2e2; }
.stat-icon.green-dark { background-color: #c6f6d5; }
.stat-number { font-size: 1.8rem; font-weight: 700; margin: 4px 0 0 0; color: #114224; }
.stat-card h3 { margin: 0; font-size: 0.8rem; color: #526b5a; text-transform: uppercase; }

/* 🌱 Panel Principal */
.work-panel { background: white; padding: 30px; border-radius: 16px; box-shadow: 0 4px 20px rgba(0,0,0,0.02); }
.panel-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 25px; }
.panel-header h2 { margin: 0; font-size: 1.3rem; color: #114224; font-weight: 700; }
.panel-subtitle { margin: 2px 0 0 0; font-size: 0.85rem; color: #738a7c; }

.btn-primary { background: linear-gradient(135deg, #114224 0%, #176335 100%); color: white; border: none; padding: 12px 20px; border-radius: 8px; cursor: pointer; font-weight: 600; }
.btn-primary:active { transform: scale(0.98); }

/* 📋 Tabla Premium */
.table-responsive { overflow-x: auto; }
.data-table { width: 100%; border-collapse: separate; border-spacing: 0 10px; text-align: left; }
.data-table th { padding: 12px 16px; color: #526b5a; font-size: 0.78rem; font-weight: 700; text-transform: uppercase; border-bottom: 1px solid #e2e8f0; }
.table-row { background-color: #ffffff; transition: all 0.2s ease; }
.table-row:hover { background-color: #f8faf9; transform: translateY(-2px); box-shadow: 0 4px 12px rgba(0,0,0,0.03); }
.table-row td { padding: 16px; border-top: 1px solid #edf2f0; border-bottom: 1px solid #edf2f0; font-size: 0.92rem; vertical-align: middle; }
.table-row td:first-child { border-left: 1px solid #edf2f0; border-top-left-radius: 10px; border-bottom-left-radius: 10px; }
.table-row td:last-child { border-right: 1px solid #edf2f0; border-top-right-radius: 10px; border-bottom-right-radius: 10px; }

/* 🇨🇱 Réplica Patente Vehículo */
.ppu-container {
  display: inline-flex; flex-direction: column; align-items: center; justify-content: center;
  background-color: #ffffff; border: 2px solid #1e293b; border-radius: 6px; padding: 2px 10px; width: 105px;
}
.ppu-chile { font-size: 0.55rem; font-weight: 900; color: #2563eb; letter-spacing: 1px; line-height: 1; }
.ppu-text { font-family: 'Consolas', monospace; font-weight: 800; font-size: 1.05rem; color: #1e293b; }

/* Datos de Celdas */
.font-mono { font-family: monospace; font-size: 0.95rem; }
.font-bold { font-weight: 700; }
.text-dark { color: #1e293b; }
.text-muted { color: #7f8c8d; }
.text-center { text-align: center; }

/* Badges de Productos Orgánicos */
.organic-badge { padding: 6px 12px; border-radius: 6px; font-size: 0.78rem; font-weight: 700; }
.organic-badge.yes { background-color: #fee2e2; color: #b91c1c; }
.organic-badge.no { background-color: #f1f5f9; color: #475569; }

/* Sección Mascotas */
.mascota-info { display: flex; flex-direction: column; gap: 2px; }
.mascota-status.yes { color: #16a34a; font-weight: 700; }
.mascota-status.no { color: #64748b; }
.folio-text { font-size: 0.75rem; color: #475569; font-family: monospace; background: #f1f5f9; padding: 1px 4px; border-radius: 4px; display: inline-block; width: max-content; }

/* 🟢 Pill de Estados con Pulsación LED */
.status-pill { display: inline-flex; align-items: center; gap: 6px; padding: 6px 14px; border-radius: 50px; font-size: 0.78rem; font-weight: 700; text-transform: uppercase; }
.status-pill .led-dot { width: 7px; height: 7px; border-radius: 50%; display: inline-block; }

/* Estado APROBADO (Tu JSON) */
.status-pill.aprobado { background-color: #dcfce7; color: #15803d; }
.status-pill.aprobado .led-dot { background-color: #22c55e; box-shadow: 0 0 8px #22c55e; }

/* Estado RETENIDO */
.status-pill.retenido { background-color: #fee2e2; color: #b91c1c; }
.status-pill.retenido .led-dot { background-color: #ef4444; box-shadow: 0 0 8px #ef4444; }

/* Estado PENDIENTE */
.status-pill.pendiente { background-color: #fef9c3; color: #854d0e; }
.status-pill.pendiente .led-dot { background-color: #eab308; box-shadow: 0 0 8px #eab308; }

/* Botones */
.btn-action-inspect { background-color: #f0fdf4; border: 1px solid #bbf7d0; color: #16a34a; padding: 8px 16px; border-radius: 8px; font-weight: 600; cursor: pointer; transition: all 0.2s; }
.btn-action-inspect:hover { background-color: #16a34a; color: #ffffff; }
.btn-retry { background-color: #e74c3c; color: white; border: none; padding: 8px 15px; border-radius: 4px; cursor: pointer; margin-top: 10px; }

/* Spinner & States */
.loading-state, .error-state, .empty-state { text-align: center; padding: 50px; color: #64748b; }
.spinner { border: 3px solid #f3f3f3; border-top: 3px solid #114224; border-radius: 50%; width: 30px; height: 30px; animation: spin 1s linear infinite; margin: 0 auto 15px auto; }
@keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }
</style>