package com.example.MsMigracion.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.time.Period;


@Entity
@Data
@AllArgsConstructor
@Builder
@Table(name = "registros_migratorios")
public class RegistroMigratorio {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // --- Datos de Identificación ---
    @Column(nullable = false, length = 20)
    private String documentoIdentidad; // RUT o Pasaporte

    @Column(nullable = false)
    private String nombresCompletos;

    @Column(nullable = false)
    private String nacionalidad;

    @Column(nullable = false)
    private LocalDate fechaNacimiento;

    // --- Clave de Correlación con MS_Vehiculo ---
    // Nos dice en qué auto viaja esta persona
    @Column(nullable = false, length = 10)
    private String patenteVehiculoAsociado;


    // --- Estado del Control PDI ---
    // APROBADO, RECHAZADO_POR_ARRAIGO, RECHAZADO_FALTA_PERMISO
    @Column(nullable = false)
    private String estado;

    // --- Campos Exclusivos para Menores de Edad ---
    // Si es adulto, estos campos quedan en null o false
    private Boolean viajaConAmbosPadres;
    private String folioPermisoNotarial;
    private String folioJuzgadoFamilia;

    // Constructor vacío exigido por JPA
    public RegistroMigratorio() {}

    // --- REGLAS DE NEGOCIO ENCAPSULADAS ---

    /**
     * Calcula dinámicamente si el pasajero es menor de edad al momento del cruce.
     */
    @Transient // No se guarda en la BD, se calcula al vuelo
    public boolean isMenorDeEdad() {
        if (this.fechaNacimiento == null) return false;
        int edad = Period.between(this.fechaNacimiento, LocalDate.now()).getYears();
        return edad < 18;
    }

    /**
     * Valida si un menor de edad cumple con los requisitos legales para salir del país.
     */
    public boolean cumpleRequisitosMenor() {
        if (!isMenorDeEdad()) {
            return true; // Si es adulto, no necesita permisos de menor
        }

        // Si viaja con ambos padres, pasa.
        if (Boolean.TRUE.equals(this.viajaConAmbosPadres)) {
            return true;
        }

        // Si no viaja con ambos padres, DEBE tener un permiso notarial o del juzgado
        return (this.folioPermisoNotarial != null && !this.folioPermisoNotarial.isEmpty()) ||
                (this.folioJuzgadoFamilia != null && !this.folioJuzgadoFamilia.isEmpty());
    }

    // Getters y Setters...
    // (Omitidos para brevedad, puedes usar @Data de Lombok)
}