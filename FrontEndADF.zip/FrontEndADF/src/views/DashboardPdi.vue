<template>
  <div class="dashboard-container">
    <aside class="sidebar">
      <div class="brand">
        <h2>PDI CHILE</h2>
        <span class="badge-oficial">Policía Internacional</span>
      </div>
      
      <nav class="menu">
        <button class="menu-item active">
          <i>🛂</i> Control Migratorio
        </button>
        <button class="menu-item">
          <i>🚨</i> Alertas Interpol / Arraigo
        </button>
        <button class="menu-item">
          <i>📋</i> Histórico de Movimientos
        </button>
      </nav>

      <div class="sidebar-footer">
        <div class="user-info">
          <p class="user-name">Oficial Investigador</p>
          <p class="user-rut">RUT: {{ officerRut }}</p>
        </div>
        <button @click="handleLogout" class="btn-logout">Cerrar Sesión</button>
      </div>
    </aside>

    <main class="main-content">
      <header class="content-header">
        <div class="welcome">
          <h1>Jefatura Nacional de Migraciones y Policía Internacional</h1>
          <p>Sistema de control fronterizo, validación de identidad y permisos de menores.</p>
        </div>
        <div class="date-badge">
          📅 {{ currentDate }}
        </div>
      </header>

      <section class="stats-grid">
        <div class="stat-card">
          <div class="stat-icon blue">🛂</div>
          <div>
            <h3>Pasajeros Controlados</h3>
            <p class="stat-number">2,845</p>
          </div>
        </div>
        <div class="stat-card alert">
          <div class="stat-icon red">🚨</div>
          <div>
            <h3>Órdenes de Arraigo / Rechazos</h3>
            <p class="stat-number">7</p>
          </div>
        </div>
        <div class="stat-card warning">
          <div class="stat-icon orange">👶</div>
          <div>
            <h3>Menores de Edad Fiscalizados</h3>
            <p class="stat-number">312</p>
          </div>
        </div>
      </section>

      <section class="work-panel">
        <div class="panel-header">
          <div>
            <h2>Control de Identidad y Frontera</h2>
            <p class="panel-subtitle">Microservicio de Migración (GET /api/v1/migracion)</p>
          </div>
          <button @click="obtenerMigracion" class="btn-primary" :disabled="isLoading">
            <span v-if="isLoading">🔄 Verificando...</span>
            <span v-else>🔄 Sincronizar Pasajeros</span>
          </button>
        </div>

        <div v-if="isLoading" class="loading-state">
          <div class="spinner"></div>
          <p>Consultando bases de datos de Policía Internacional...</p>
        </div>
        
        <div v-else-if="errorApi" class="error-state">
          <div class="error-icon">⚠️</div>
          <p>{{ errorApi }}</p>
          <button @click="obtenerMigracion" class="btn-retry">Reintentar Conexión</button>
        </div>

        <div v-else class="table-responsive">
          <table class="data-table">
            <thead>
              <tr>
                <th>Documento / Nombre</th>
                <th>Nacionalidad</th>
                <th>Fecha Nacimiento</th>
                <th>Vehículo Asociado</th>
                <th>Control Menores (Ley 21.325)</th>
                <th>Resolución</th>
                <th class="text-center">Acción</th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="item in listaPasajeros" :key="item.id" class="table-row">
                
                <td>
                  <div class="person-info">
                    <span class="person-name">{{ item.nombresCompletos }}</span>
                    <span class="person-doc">ID: {{ item.documentoIdentidad }}</span>
                  </div>
                </td>

                <td>
                  <span class="country-badge">{{ item.nacionalidad }}</span>
                </td>
                
                <td>
                  <div class="dob-info">
                    <span class="dob-date">{{ item.fechaNacimiento }}</span>
                    <span v-if="item.menorDeEdad" class="minor-alert">MENOR DE EDAD</span>
                  </div>
                </td>
                
                <td>
                  <span class="plate-text">{{ item.patenteVehiculoAsociado }}</span>
                </td>
                
                <td>
                  <span v-if="!item.menorDeEdad" class="minor-badge adult">
                    Adulto (No aplica)
                  </span>
                  
                  <span v-else-if="item.viajaConAmbosPadres" class="minor-badge ok">
                    👨‍👩‍👧 Viaja con ambos padres
                  </span>

                  <div v-else-if="item.folioPermisoNotarial" class="folio-box notarial">
                    <span class="folio-title">📜 Notarial</span>
                    <span class="folio-number">{{ item.folioPermisoNotarial }}</span>
                  </div>

                  <div v-else-if="item.folioJuzgadoFamilia" class="folio-box juzgado">
                    <span class="folio-title">⚖️ Juzgado Flia.</span>
                    <span class="folio-number">{{ item.folioJuzgadoFamilia }}</span>
                  </div>

                  <span v-else class="minor-badge danger">
                    🚫 FALTAN PERMISOS
                  </span>
                </td>
                
                <td>
                  <span :class="['status-pill', item.estado.toLowerCase()]">
                    <span class="led-dot"></span>
                    {{ item.estado }}
                  </span>
                </td>
                
                <td class="text-center">
                  <button class="btn-action-inspect">
                    <span>Control</span>
                  </button>
                </td>
              </tr>
              
              <tr v-if="listaPasajeros.length === 0">
                <td colspan="7" class="empty-state">
                  📭 No hay pasajeros en espera de control migratorio.
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </section>
    </main>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue';
import { useRouter } from 'vue-router';

const router = useRouter();
const officerRut = ref('Cargando...');
const currentDate = ref(new Date().toLocaleDateString('es-CL', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' }));

const listaPasajeros = ref([]);
const isLoading = ref(true);
const errorApi = ref(null);

const parseJwt = (token) => {
  try {
    const base64Url = token.split('.')[1];
    const base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
    return JSON.parse(window.atob(base64));
  } catch (e) {
    return null;
  }
};

const obtenerMigracion = async () => {
  isLoading.value = true;
  errorApi.value = null;
  try {
    const token = localStorage.getItem('user_token');
    
    // 🚧 CAMBIA ESTE PUERTO AL QUE USE TU MICROSERVICIO PDI (ej: 9094)
    const response = await fetch('http://localhost:9093/api/v1/migracion', {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}` 
      }
    });

    if (!response.ok) {
      throw new Error(`Error en el servidor: ${response.status}`);
    }

    const data = await response.json();
    listaPasajeros.value = data;
  } catch (err) {
    console.error("Error al conectar con PDI:", err);
    errorApi.value = "No se pudo enlazar con la base de datos de Policía Internacional.";
  } finally {
    isLoading.value = false;
  }
};

onMounted(() => {
  const token = localStorage.getItem('user_token');
  if (!token) {
    router.push('/');
    return;
  }

  const tokenData = parseJwt(token);
  if (tokenData && tokenData.sub) {
    officerRut.value = tokenData.sub;
  }

  obtenerMigracion();
});

const handleLogout = () => {
  localStorage.removeItem('user_token');
  localStorage.removeItem('user_role');
  router.push('/');
}
</script>

<style scoped>
/* 🌍 Layout General */
.dashboard-container {
  display: flex; height: 100vh; width: 100vw; background-color: #f0f4f8;
  font-family: 'Segoe UI', system-ui, -apple-system, sans-serif; position: fixed; top: 0; left: 0;
}

/* 🛂 Sidebar PDI (Azul PDI muy oscuro) */
.sidebar {
  width: 260px; background-color: #001f3f; color: #ecf0f1; display: flex; flex-direction: column;
  justify-content: space-between; padding: 24px; box-shadow: 4px 0 15px rgba(0,0,0,0.1);
}
.brand h2 { font-size: 1.3rem; margin: 0 0 4px 0; font-weight: 800; letter-spacing: 1.5px; color: #ffffff; }
.badge-oficial { background-color: #c0392b; font-size: 0.7rem; padding: 3px 8px; border-radius: 50px; font-weight: 600; text-transform: uppercase; color: white;}
.menu { display: flex; flex-direction: column; gap: 8px; margin-top: 40px; flex-grow: 1; }
.menu-item {
  background: none; border: none; color: #8fa0b3; text-align: left; padding: 12px 16px; border-radius: 8px;
  cursor: pointer; font-size: 0.95rem; font-weight: 500; transition: all 0.2s ease; display: flex; align-items: center; gap: 10px;
}
.menu-item:hover, .menu-item.active { background-color: #003366; color: #fff; }
.menu-item.active { border-left: 4px solid #3498db; }
.sidebar-footer { border-top: 1px solid #003366; padding-top: 20px; }
.user-name { font-weight: 600; margin: 0; font-size: 0.95rem;}
.user-rut { font-size: 0.8rem; color: #6a7f94; margin: 2px 0 15px 0; font-family: monospace; }
.btn-logout { width: 100%; background-color: #34495e; color: white; border: 1px solid #455a64; padding: 10px; border-radius: 6px; cursor: pointer; font-weight: 600; transition: background 0.2s; }
.btn-logout:hover { background-color: #c0392b; border-color: #c0392b; }

/* 🖥️ Main Content */
.main-content { flex-grow: 1; padding: 40px; overflow-y: auto; }
.content-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 30px; }
.content-header h1 { margin: 0 0 5px 0; color: #001f3f; font-size: 1.7rem; font-weight: 800; }
.content-header p { margin: 0; color: #576574; font-size: 0.95rem; }
.date-badge { background-color: #ffffff; padding: 10px 18px; border-radius: 30px; box-shadow: 0 2px 6px rgba(0,0,0,0.03); font-size: 0.85rem; font-weight: 600; color: #2c3e50; }

/* 📊 Stats Grid */
.stats-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 24px; margin-bottom: 35px; }
.stat-card { background: white; padding: 24px; border-radius: 16px; box-shadow: 0 4px 12px rgba(0,0,0,0.03); display: flex; align-items: center; gap: 20px; }
.stat-icon { width: 48px; height: 48px; border-radius: 12px; display: flex; align-items: center; justify-content: center; font-size: 1.4rem; }
.stat-icon.blue { background-color: #e0f2fe; }
.stat-icon.red { background-color: #fee2e2; }
.stat-icon.orange { background-color: #ffedd5; }
.stat-number { font-size: 1.8rem; font-weight: 700; margin: 4px 0 0 0; color: #001f3f; }
.stat-card h3 { margin: 0; font-size: 0.8rem; color: #576574; text-transform: uppercase; font-weight: 700;}

/* 🛂 Panel Principal */
.work-panel { background: white; padding: 30px; border-radius: 16px; box-shadow: 0 4px 20px rgba(0,0,0,0.03); }
.panel-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 25px; }
.panel-header h2 { margin: 0; font-size: 1.3rem; color: #001f3f; font-weight: 800; }
.panel-subtitle { margin: 2px 0 0 0; font-size: 0.85rem; color: #8395a7; }

.btn-primary { background: linear-gradient(135deg, #001f3f 0%, #003366 100%); color: white; border: none; padding: 12px 20px; border-radius: 8px; cursor: pointer; font-weight: 600; }
.btn-primary:active { transform: scale(0.98); }

/* 📋 Tabla PDI */
.table-responsive { overflow-x: auto; }
.data-table { width: 100%; border-collapse: separate; border-spacing: 0 10px; text-align: left; }
.data-table th { padding: 12px 16px; color: #576574; font-size: 0.75rem; font-weight: 800; text-transform: uppercase; border-bottom: 1px solid #e2e8f0; }
.table-row { background-color: #ffffff; transition: all 0.2s ease; border: 1px solid transparent;}
.table-row:hover { background-color: #f8fafc; transform: translateY(-2px); box-shadow: 0 4px 12px rgba(0,0,0,0.04); }
.table-row td { padding: 14px 16px; border-top: 1px solid #e2e8f0; border-bottom: 1px solid #e2e8f0; font-size: 0.9rem; vertical-align: middle; }
.table-row td:first-child { border-left: 1px solid #e2e8f0; border-top-left-radius: 8px; border-bottom-left-radius: 8px; }
.table-row td:last-child { border-right: 1px solid #e2e8f0; border-top-right-radius: 8px; border-bottom-right-radius: 8px; }

/* Persona */
.person-info { display: flex; flex-direction: column; }
.person-name { font-weight: 700; color: #001f3f; font-size: 0.95rem;}
.person-doc { font-size: 0.8rem; color: #576574; font-family: monospace; background: #f1f2f6; padding: 2px 6px; border-radius: 4px; width: max-content; margin-top: 4px;}

/* Nacionalidad y Patente */
.country-badge { font-weight: 600; color: #34495e; }
.plate-text { font-family: 'Consolas', monospace; font-weight: 700; border: 1px solid #bdc3c7; padding: 2px 6px; border-radius: 4px; background: #fff;}

/* Nacimiento y Alerta Menor */
.dob-info { display: flex; flex-direction: column; gap: 4px; }
.dob-date { color: #2c3e50; font-weight: 500;}
.minor-alert { background-color: #ffebd2; color: #d35400; font-size: 0.65rem; font-weight: 800; padding: 2px 6px; border-radius: 4px; width: max-content; }

/* 👶 Control de Menores Badges */
.minor-badge { font-size: 0.75rem; font-weight: 700; padding: 4px 8px; border-radius: 6px; display: inline-block;}
.minor-badge.adult { background-color: #f1f2f6; color: #7f8c8d; }
.minor-badge.ok { background-color: #dcfce7; color: #16a34a; }
.minor-badge.danger { background-color: #fee2e2; color: #c0392b; font-weight: 800;}

/* Folios Notariales / Juzgado */
.folio-box { display: inline-flex; flex-direction: column; border: 1px solid #e2e8f0; border-radius: 6px; overflow: hidden; }
.folio-title { font-size: 0.65rem; font-weight: 800; padding: 2px 6px; color: white; }
.folio-number { font-size: 0.75rem; font-family: monospace; padding: 2px 6px; background: white; font-weight: 600; color: #2c3e50;}
.folio-box.notarial { border-color: #3498db; }
.folio-box.notarial .folio-title { background-color: #3498db; }
.folio-box.juzgado { border-color: #9b59b6; }
.folio-box.juzgado .folio-title { background-color: #9b59b6; }

/* 🟢 Pill de Estados */
.status-pill { display: inline-flex; align-items: center; gap: 6px; padding: 6px 14px; border-radius: 50px; font-size: 0.75rem; font-weight: 800; text-transform: uppercase; }
.status-pill .led-dot { width: 8px; height: 8px; border-radius: 50%; display: inline-block; }

.status-pill.aprobado { background-color: #dcfce7; color: #15803d; }
.status-pill.aprobado .led-dot { background-color: #22c55e; box-shadow: 0 0 8px #22c55e; }
.status-pill.retenido { background-color: #fee2e2; color: #b91c1c; }
.status-pill.retenido .led-dot { background-color: #ef4444; box-shadow: 0 0 8px #ef4444; }

/* Botones */
.btn-action-inspect { background-color: #f1f5f9; border: 1px solid #cbd5e1; color: #001f3f; padding: 6px 16px; border-radius: 6px; font-weight: 700; cursor: pointer; transition: all 0.2s; }
.btn-action-inspect:hover { background-color: #001f3f; color: #ffffff; border-color: #001f3f;}
.btn-retry { background-color: #e74c3c; color: white; border: none; padding: 8px 15px; border-radius: 4px; cursor: pointer; margin-top: 10px; }

/* Spinner */
.loading-state, .error-state, .empty-state { text-align: center; padding: 50px; color: #64748b; }
.spinner { border: 3px solid #f3f3f3; border-top: 3px solid #001f3f; border-radius: 50%; width: 30px; height: 30px; animation: spin 1s linear infinite; margin: 0 auto 15px auto; }
@keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }
</style>