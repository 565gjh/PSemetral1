import { createRouter, createWebHistory } from 'vue-router'
import Login from '../views/Login.vue'
import RegisterPassenger from '../views/RegisterPassenger.vue'
import PortalPasajero from '../views/PortalPasajero.vue'
import DashboardAduana from '../views/DashboardFuncionario.vue' // El que creamos recién
 import DashboardSag from '../views/DashboardSag.vue'  
 import DashboardPdi from '../views/DashboardPdi.vue'

const routes = [
  {
    path: '/',
    name: 'Login',
    component: Login,
  },
  
  {
    path: '/RegisterPassenger',
    name: 'RegisterPassenger',
    component: RegisterPassenger
  },
  {
    path: '/portal-pasajero',
    name: 'PortalPasajero',
    component: PortalPasajero,
    meta: { requiereAutenticacion: true, rolRequerido: 'ROLE_PASAJERO' }
  },
  {
    path: '/dashboard-aduana',
    name: 'DashboardAduana',
    component: DashboardAduana,
    meta: { requiereAutenticacion: true, rolRequerido: 'ROLE_ADUANA' }
  },
  {
    path: '/dashboard-sag',
    name: 'DashboardSag',
    component: DashboardSag,
    meta: { requiereAutenticacion: true, rolRequerido: 'ROLE_SAG' } // Temporalmente al login hasta que crees la vista
  },
  {
    path: '/dashboard-pdi',
    name: 'DashboardPdi',
    component: DashboardPdi,
    meta: { 
      requiereAutenticacion: true,
      rolRequerido: 'ROLE_PDI' // ⬅️ Definimos qué rol específico puede entrar aquí
      }
    
  }
]

const router = createRouter({
  history: createWebHistory(),
  routes
})
router.beforeEach((to, from, next) => {
  // 1. ¿La ruta actual requiere estar autenticado?
  if (to.meta.requiereAutenticacion) {
    
    // Leemos las dos variables que genera tu script de login
    const token = localStorage.getItem('user_token');
    const userRole = localStorage.getItem('user_role');

    // Si no existe el token o no hay un rol registrado, significa que no está logueado
    if (!token || !userRole) {
      alert("🔒 Sesión inválida o expirada. Por favor, inicie sesión.");
      return next('/');
    }

    // 2. ¿La ruta exige un rol institucional específico?
    if (to.meta.rolRequerido) {
      
      // Comparamos el rol de la ruta con el del localStorage
      if (to.meta.rolRequerido === userRole) {
        next(); // ✅ Coinciden. Permitir acceso libre.
      } else {
        // ⛔ NO coinciden. Intento de intrusión o error de navegación.
        alert(`🚫 Acceso denegado. Esta sección es exclusiva para: ${to.meta.rolRequerido}`);
        
        // 🔀 Redirección de seguridad inteligente según SU rol real
        switch (userRole) {
          case 'ROLE_PASAJERO':
            next('/portal-pasajero');
            break;
          case 'ROLE_ADUANA':
            next('/dashboard-aduana');
            break;
          case 'ROLE_SAG':
            next('/dashboard-sag');
            break;
          case 'ROLE_PDI':
            next('/dashboard-pdi');
            break;
          default:
            next('/'); // Si tiene un rol extraño, al login.
        }
      }
    } else {
      // Si la ruta pide autenticación pero no un rol en específico, cualquier usuario logueado entra
      next();
    }

  } else {
    // Si es una ruta pública (como Login o Registro), el guardia no interviene
    next();
  }
});

export default router