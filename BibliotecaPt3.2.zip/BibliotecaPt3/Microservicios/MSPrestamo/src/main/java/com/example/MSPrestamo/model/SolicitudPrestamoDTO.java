package com.example.MSPrestamo.model;

import lombok.Data;

@Data
public class SolicitudPrestamoDTO {

    // El ID del usuario que está pidiendo el libro (suele ser el authId)
    private Long Id;

    // El ID del libro que quiere pedir prestado
    private Long idLibro;

    // (Opcional) Si en tu biblioteca el usuario elige por cuántos días lo quiere
    // private int diasPrestamo;
}