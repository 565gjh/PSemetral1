package com.example.MSPrestamo.controller;

import com.example.MSPrestamo.model.SolicitudPrestamoDTO;
import com.example.MSPrestamo.service.PrestamoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/prestamos")
public class PrestamoController {

    @Autowired
    private PrestamoService prestamoService;

    @PostMapping("/crear")
    public ResponseEntity<?> crearPrestamo(
            @RequestBody SolicitudPrestamoDTO solicitud,
            @RequestHeader("Authorization") String token) { // 👈 Atrapamos el token de Postman

        try {
            prestamoService.procesarPrestamo(solicitud, token);
            return ResponseEntity.ok("Préstamo realizado con éxito");
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }
}