package com.example.MSPrestamo.model;

import lombok.Data;

@Data
public class UsuarioDTO {
    private Long id;
    private String email;
    private String nombre1;
    private String apellido1;


}