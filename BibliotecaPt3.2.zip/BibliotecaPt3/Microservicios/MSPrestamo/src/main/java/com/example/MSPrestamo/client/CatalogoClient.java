package com.example.MSPrestamo.client;

import com.example.MSPrestamo.model.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

@Component
public class CatalogoClient {

    @Autowired
    private WebClient.Builder webClientBuilder;

    // Fíjate que ahora pedimos el token como parámetro
    public LibroDTO obtenerLibro(Long idLibro, String token) {
        return webClientBuilder.build()
                .get()
                .uri("http://MSCatalogo/api/v1/catalogo/" + idLibro)
                .header("Authorization", token) // 👈 ¡Enviamos el token al catálogo!
                .retrieve()
                .bodyToMono(LibroDTO.class)
                .block(); // Usamos block para esperar la respuesta
    }
}