package com.example.MSPrestamo.service;


import com.example.MSPrestamo.client.CatalogoClient;
import com.example.MSPrestamo.client.UsuarioClient;
import com.example.MSPrestamo.model.*;
import com.example.MSPrestamo.repository.PrestamoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;

@Service
public class PrestamoService {

    @Autowired
    private CatalogoClient catalogoClient;

    @Autowired
    private UsuarioClient usuarioClient;

    @Autowired
    private PrestamoRepository prestamoRepository;

    public void procesarPrestamo(SolicitudPrestamoDTO solicitud, String token) {
        

        // 2. Preguntamos a ms-catalogo si el libro existe y tiene stock
        LibroDTO libro = catalogoClient.obtenerLibro(solicitud.getIdLibro(), token);
        if (libro == null || libro.getStockDisponible() <= 0) {
            throw new RuntimeException("El libro no existe o no hay stock disponible.");
        }

        // 3. Si ambos respondieron bien, creamos el préstamo en la BD local de ms-prestamos
        Prestamo nuevoPrestamo = new Prestamo();
        nuevoPrestamo.setId(usuario.getId());
        nuevoPrestamo.setLibroId(libro.getId());
        nuevoPrestamo.setFechaPrestamo(LocalDate.now());
        // ... setear fechas de devolución, etc.

        prestamoRepository.save(nuevoPrestamo);

        // Opcional: Podrías hacer un WebClient.put() a ms-catalogo para restarle 1 al stock del libro
    }
}