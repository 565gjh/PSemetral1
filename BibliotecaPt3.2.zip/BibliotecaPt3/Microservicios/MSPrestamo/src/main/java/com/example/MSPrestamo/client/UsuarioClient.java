package com.example.MSPrestamo.client;

import com.example.MSPrestamo.model.UsuarioDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.reactive.function.client.WebClient;

public class UsuarioClient {
    @Autowired
    private WebClient.Builder webClientBuilder;

    public UsuarioDTO obtenerUsuario(String authId, String token) {
        return webClientBuilder.build()
                .get()
                .uri("http://MSusuarios/api/v1/usuarios/" + authId)
                .header("Authorization", token) // 👈 ¡Enviamos el token a usuarios!
                .retrieve()
                .bodyToMono(UsuarioDTO.class)
                .block();
    }
}

