package com.example.MSCatalogo.model;

import lombok.Data;

@Data
public class LibroDTO {
    private Long id;
    private String titulo;
    private int StockDisponible;
}
