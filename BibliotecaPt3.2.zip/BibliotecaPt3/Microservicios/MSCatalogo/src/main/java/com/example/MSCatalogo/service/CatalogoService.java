package com.example.MSCatalogo.service;

import com.example.MSCatalogo.model.Autor;
import com.example.MSCatalogo.model.Categoria;
import com.example.MSCatalogo.model.Libro;
import com.example.MSCatalogo.repository.AutorRepository;
import com.example.MSCatalogo.repository.CategoriaRepository;
import com.example.MSCatalogo.repository.LibroRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Slf4j
@Service
public class CatalogoService {

    @Autowired
    private LibroRepository libroRepository;

    @Autowired
    private AutorRepository autorRepository;

    @Autowired
    private CategoriaRepository categoriaRepository;

    // Listar
    public List<Libro> obtenerCatalogoCompleto() {
        log.info("pasando");
        return libroRepository.findAll();
    }

    // Buscar un libro por ID
    public Libro obtenerPorId(Long id) {
        return libroRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Libro no encontrado en el catálogo con ID: " + id));
    }

    // Guardar libro verificando que existan sus relaciones JPA
    public Libro guardarLibroEnCatalogo(Libro libro) {
        if (libro.getAutor() == null || libro.getAutor().getId() == null) {
            throw new RuntimeException("El libro debe incluir un objeto autor con un ID válido.");
        }
        if (libro.getCategoria() == null || libro.getCategoria().getId() == null) {
            throw new RuntimeException("El libro debe incluir un objeto categoría con un ID válido.");
        }

        // Buscar el autor real en la base de datos
        Autor autorExistente = autorRepository.findById(libro.getAutor().getId())
                .orElseThrow(() -> new RuntimeException("Error: El Autor con ID " + libro.getAutor().getId() + " no existe en la base de datos."));

        // Buscar la categoría real en la base de datos
        Categoria categoriaExistente = categoriaRepository.findById(libro.getCategoria().getId())
                .orElseThrow(() -> new RuntimeException("Error: La Categoría con ID " + libro.getCategoria().getId() + " no existe en la base de datos."));

        // Establecer las relaciones JPA en el objeto Libro
        libro.setAutor(autorExistente);
        libro.setCategoria(categoriaExistente);

        return libroRepository.save(libro);
    }

    // Métodos para guardar autores y categorías independientes
    public Autor guardarAutor(Autor autor) {
        return autorRepository.save(autor);
    }

    public Categoria guardarCategoria(Categoria categoria) {
        return categoriaRepository.save(categoria);
    }
}