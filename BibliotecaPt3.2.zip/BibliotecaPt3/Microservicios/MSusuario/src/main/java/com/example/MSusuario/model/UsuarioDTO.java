package com.example.MSusuario.model;

import lombok.Data;

@Data
public class UsuarioDTO {
    private Long id;
    private String nombre1;
    private String apellido1;
    private String email;
}
