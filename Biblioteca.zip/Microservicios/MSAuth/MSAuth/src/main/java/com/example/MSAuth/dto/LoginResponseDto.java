package com.example.MSAuth.dto;

public class LoginResponseDto {
    private String token;
    private String username;
    private String tipoToken = "Bearer";

    public LoginResponseDto() {}
    public LoginResponseDto(String token, String username) {
        this.token = token;
        this.username = username;
    }

    public String getToken() { return token; }
    public void setToken(String token) { this.token = token; }

    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }

    public String getTipoToken() { return tipoToken; }
    public void setTipoToken(String tipoToken) { this.tipoToken = tipoToken; }
}