package com.example.MSusuario.service;

import com.example.MSusuario.model.Usuario;
import com.example.MSusuario.repository.usuarioRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import java.util.List;
import java.util.Optional;
@Service
@Slf4j
public class usuarioService {
    @Autowired
    private usuarioRepository repository;

    @PreAuthorize("hasRole('ADMIN')")
    public List<Usuario> findAll() {
        log.info("Obteniendo lista de todos los usuarios.");
        return repository.findAll();
    }
    @PreAuthorize("hasRole('ADMIN')")
    public Usuario findById(Long id) {
        log.info("buscando usuario por id.");
        return repository.findById(id).get();
    }
    @PreAuthorize("hasRole('ADMIN', 'USUARIO', 'TRABAJADOR')")

    public Usuario save(Usuario usuario) {
        log.info("Guardando el usuario.");
        return repository.save(usuario);
    }
    @PreAuthorize("hasRole('ADMIN', 'TRABAJADOR')")
    public Optional<Usuario> findByEmail(String email) {
        log.info("buscando usuario por email.");
        return repository.findByEmail(email);
    }
}



