package com.example.MSReservas.controller;

import com.example.MSReservas.dto.ReservaResponseDto;
import com.example.MSReservas.service.reservaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/reservas")
public class reservaController {

    @Autowired
    private reservaService reservaService;

    @GetMapping("/{id}")
    public ResponseEntity<ReservaResponseDto> buscarReservaPorId(@PathVariable Long id) {
        ReservaResponseDto reserva = reservaService.obtenerPorId(id);
        return ResponseEntity.ok(reserva);
    }
}