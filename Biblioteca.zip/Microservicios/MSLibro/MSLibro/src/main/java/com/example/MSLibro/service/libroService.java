package com.example.MSLibro.service;

import com.example.MSLibro.dto.AutorDto;
import com.example.MSLibro.dto.CategoriaDto;
import com.example.MSLibro.dto.LibroResponseDto;
import com.example.MSLibro.model.Libro;
import com.example.MSLibro.repository.libroRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class libroService {

    @Autowired
    private libroRepository libroRepository;

    @Autowired
    private RestTemplate restTemplate;

    public LibroResponseDto obtenerPorId(Long id) {
        Libro libro = libroRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Libro no encontrado con el ID: " + id));

        AutorDto autor = null;
        try {
            String urlAutores = "http://localhost:8090/api/v1/autores/" + libro.getAutorId();
            autor = restTemplate.getForObject(urlAutores, AutorDto.class);
        } catch (Exception e) {
            autor = new AutorDto();
            autor.setId(libro.getAutorId());
            autor.setNombre("No disponible");
            autor.setApellido("(Error de comunicación)");
        }

        CategoriaDto categoria = null;
        try {
            String urlCategorias = "http://localhost:8082/api/v1/categorias/" + libro.getCategoriaId();
            categoria = restTemplate.getForObject(urlCategorias, CategoriaDto.class);
        } catch (Exception e) {
            categoria = new CategoriaDto();
            categoria.setId(libro.getCategoriaId());
            categoria.setNombre("No disponible (Error de comunicación)");
        }

        LibroResponseDto response = new LibroResponseDto();
        response.setId(libro.getId());
        response.setTitulo(libro.getTitulo());
        response.setIsbn(libro.getIsbn());
        response.setAutor(autor);
        response.setCategoria(categoria);

        return response;
    }
}