package com.example.MSLibro.dto;

public class LibroResponseDto {
    private Long id;
    private String titulo;
    private String isbn;
    private AutorDto autor;
    private CategoriaDto categoria;

    public LibroResponseDto() {}

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getTitulo() { return titulo; }
    public void setTitulo(String titulo) { this.titulo = titulo; }

    public String getIsbn() { return isbn; }
    public void setIsbn(String isbn) { this.isbn = isbn; }

    public AutorDto getAutor() { return autor; }
    public void setAutor(AutorDto autor) { this.autor = autor; }

    public CategoriaDto getCategoria() { return categoria; }
    public void setCategoria(CategoriaDto categoria) { this.categoria = categoria; }
}