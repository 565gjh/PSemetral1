package com.example.MSLibro.model;

import jakarta.persistence.*;

@Entity
@Table(name = "libros")
public class Libro {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String titulo;

    @Column(nullable = false, unique = true)
    private String isbn;

    @Column(name = "autor_id", nullable = false)
    private Long autorId;

    @Column(name = "categoria_id", nullable = false) // <--- ESTO LE FALTABA
    private Long categoriaId;

    public Libro() {}

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getTitulo() { return titulo; }
    public void setTitulo(String titulo) { this.titulo = titulo; }

    public String getIsbn() { return isbn; }
    public void setIsbn(String isbn) { this.isbn = isbn; }

    public Long getAutorId() { return autorId; }
    public void setAutorId(Long autorId) { this.autorId = autorId; }

    public Long getCategoriaId() { return categoriaId; } // <--- GETTER NUEVO
    public void setCategoriaId(Long categoriaId) { this.categoriaId = categoriaId; } // <--- SETTER NUEVO
}