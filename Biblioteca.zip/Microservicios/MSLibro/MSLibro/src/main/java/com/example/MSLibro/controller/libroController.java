package com.example.MSLibro.controller;

import com.example.MSLibro.dto.LibroResponseDto;
import com.example.MSLibro.service.libroService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/libros")
public class libroController {

    @Autowired
    private libroService libroService;

    @GetMapping("/{id}")
    public ResponseEntity<LibroResponseDto> buscarLibroPorId(@PathVariable Long id) {
        LibroResponseDto libro = libroService.obtenerPorId(id);
        return ResponseEntity.ok(libro);
    }
}