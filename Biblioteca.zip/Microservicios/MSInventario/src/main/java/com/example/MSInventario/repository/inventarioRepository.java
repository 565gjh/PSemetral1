package com.example.MSInventario.repository;


import com.example.MSInventario.model.Inventario;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface inventarioRepository extends JpaRepository<Inventario, Long> {
    List<Inventario> findByLibroId(Long libroId);
    Inventario findByCodigoSerie(String codigoSerie);
}