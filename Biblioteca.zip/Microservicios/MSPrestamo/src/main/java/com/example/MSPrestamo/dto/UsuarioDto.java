package com.example.MSPrestamo.dto;

public class UsuarioDto {
    private Long id;
    private String nombre;
    private String email;

    public UsuarioDto() {}

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
}