package com.example.MSPrestamo.controller;

import com.example.MSPrestamo.dto.PrestamoResponseDto;
import com.example.MSPrestamo.service.prestamoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/prestamos")
public class prestamoController {

    @Autowired
    private prestamoService prestamoService;

    @GetMapping("/{id}")
    public ResponseEntity<PrestamoResponseDto> buscarPrestamoPorId(@PathVariable Long id) {
        PrestamoResponseDto prestamo = prestamoService.obtenerPorId(id);
        return ResponseEntity.ok(prestamo);
    }
}