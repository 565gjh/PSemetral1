package com.example.MSPrestamo.service;


import com.example.MSPrestamo.dto.LibroDto;
import com.example.MSPrestamo.dto.PrestamoResponseDto;
import com.example.MSPrestamo.dto.UsuarioDto;
import com.example.MSPrestamo.model.Prestamo;
import com.example.MSPrestamo.repository.prestamoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class prestamoService {

    @Autowired
    private prestamoRepository prestamoRepository;

    @Autowired
    private RestTemplate restTemplate;

    public PrestamoResponseDto obtenerPorId(Long id) {
        Prestamo prestamo = prestamoRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Préstamo no encontrado con el ID: " + id));

        UsuarioDto usuario = null;
        try {
            String urlUsuarios = "http://localhost:8080/api/v1/usuarios/" + prestamo.getUsuarioId();
            usuario = restTemplate.getForObject(urlUsuarios, UsuarioDto.class);
        } catch (Exception e) {
            usuario = new UsuarioDto();
            usuario.setId(prestamo.getUsuarioId());
            usuario.setNombre("Usuario No disponible");
            usuario.setEmail("(Error de comunicación)");
        }

        LibroDto libro = null;
        try {
            String urlLibros = "http://localhost:8081/api/v1/libros/" + prestamo.getLibroId();
            libro = restTemplate.getForObject(urlLibros, LibroDto.class);
        } catch (Exception e) {
            libro = new LibroDto();
            libro.setId(prestamo.getLibroId());
            libro.setTitulo("Libro No disponible");
            libro.setIsbn("(Error de comunicación)");
        }

        PrestamoResponseDto response = new PrestamoResponseDto();
        response.setId(prestamo.getId());
        response.setFechaPrestamo(prestamo.getFechaSalida());
        response.setFechaDevolucion(prestamo.getFechaDevolucion());
        response.setUsuario(usuario);
        response.setLibro(libro);

        return response;
    }
}