package com.example.MsIdentidad.model;

import jakarta.persistence.Column;
import jakarta.persistence.DiscriminatorValue;
import jakarta.persistence.Entity;
import java.util.List;

@Entity
@DiscriminatorValue("ADMIN_TI")
public class AdministradorTI extends Usuario {

    @Column(name = "departamento")
    private String departamento; // ej: "Infraestructura", "Soporte"

    public String getDepartamento() { return departamento; }
    public void setDepartamento(String departamento) { this.departamento = departamento; }

    @Override
    public List<String> obtenerPermisos() {
        return List.of(
                "ROLE_ADMIN",
                "leer:logs_auditoria",
                "leer:estadisticas_flujo",
                "escribir:gestion_usuarios"
        );
    }
}