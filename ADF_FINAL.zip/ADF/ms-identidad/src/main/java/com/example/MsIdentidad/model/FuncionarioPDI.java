package com.example.MsIdentidad.model;

import jakarta.persistence.Column;
import jakarta.persistence.DiscriminatorValue;
import jakarta.persistence.Entity;
import java.util.List;

@Entity
@DiscriminatorValue("PDI_OPE")
public class FuncionarioPDI extends Usuario {

    @Column(name = "rango_institucional")
    private String rangoInstitucional;

    public String getRangoInstitucional() { return rangoInstitucional; }
    public void setRangoInstitucional(String rangoInstitucional) { this.rangoInstitucional = rangoInstitucional; }

    @Override
    public List<String> obtenerPermisos() {
        return List.of(
                "ROLE_PDI",
                "leer:antecedentes",
                "leer:permisos_menores",
                "escribir:aprobacion_migratoria"
        );
    }
}