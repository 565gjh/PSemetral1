package com.example.MsIdentidad.service;



import com.example.MsIdentidad.model.*;
import com.example.MsIdentidad.repository.UsuarioRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;
import java.util.Optional;
@Slf4j
@Service
public class UsuarioService {

    @Autowired
    private UsuarioRepository usuarioRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    public void register(Map<String, String> body, String tipoUsuario) {
        Usuario nuevoUsuario;

        switch (tipoUsuario.toUpperCase()) {
            case "PASAJERO":
                Pasajero pasajero = new Pasajero();
                pasajero.setNacionalidad(body.get("nacionalidad"));
                nuevoUsuario = pasajero;
                break;
            case "ADUANA":
                FuncionarioAduana aduana = new FuncionarioAduana();
                aduana.setNumeroPlacaFuncionario(body.get("numeroPlaca"));
                nuevoUsuario = aduana;
                break;
            case "SAG":
                FuncionarioSAG sag = new FuncionarioSAG();
                sag.setZonaInspeccion(body.get("ZonaInspeccion"));
                nuevoUsuario = sag;
                break;
            case "PDI":
                FuncionarioPDI pdi = new FuncionarioPDI();
                pdi.setRangoInstitucional(body.get("rango"));
                nuevoUsuario = pdi;
                break;
            case "ADMIN":
                AdministradorTI admin = new AdministradorTI();
                admin.setDepartamento(body.get("departamento"));
                nuevoUsuario = admin;
                break;
            default:
                throw new IllegalArgumentException("Tipo de usuario no válido: " + tipoUsuario);
        }
        log.info(nuevoUsuario.getCorreo());
        nuevoUsuario.setRut(body.get("rut"));
        nuevoUsuario.setCorreo(body.get("correo"));
        nuevoUsuario.setNombreCompleto(body.get("nombreCompleto"));
        nuevoUsuario.setCelular(body.get("celular"));
        nuevoUsuario.setPasswordCifrada(passwordEncoder.encode(body.get("password")));

        usuarioRepository.save(nuevoUsuario);
    }

    public List<Usuario> obtenerTodos() {
        return usuarioRepository.findAll();
    }

    public Optional<Usuario> findByRut(String rut) {
        return usuarioRepository.findByRut(rut);
    }
}