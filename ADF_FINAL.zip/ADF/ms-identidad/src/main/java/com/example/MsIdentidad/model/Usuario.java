package com.example.MsIdentidad.model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "usuarios_sna")
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
@DiscriminatorColumn(name = "tipo_usuario", discriminatorType = DiscriminatorType.STRING)
public abstract class Usuario {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(unique = true, nullable = false, length = 12)
    protected String rut;

    @Column(name = "correo", nullable = false)
    protected String correo;

    @Column(name = "nombre_completo", nullable = false)
    protected String nombreCompleto;

    @Column(name = "celular", nullable = false)
    protected String celular;

    @Column(name = "password_cifrada", nullable = false)
    protected String passwordCifrada;

    // MÉTODO ABSTRACTO: Obliga a cada hijo a definir sus propios permisos
    public abstract List<String> obtenerPermisos();
}