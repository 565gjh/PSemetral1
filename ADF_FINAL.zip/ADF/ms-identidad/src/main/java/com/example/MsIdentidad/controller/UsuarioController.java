package com.example.MsIdentidad.controller;

import com.example.MsIdentidad.model.Usuario;
import com.example.MsIdentidad.service.UsuarioService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@CrossOrigin(origins = "*")
@Slf4j
@RestController
@RequestMapping("/api/v1/usuarios")
public class UsuarioController {

    @Autowired
    private UsuarioService usuarioService;

    @PostMapping("/funcionario")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<?> registrarFuncionario(@RequestBody Map<String, String> body) {

        try {
            String tipoUsuario = body.get("tipoUsuario");
            usuarioService.register(body, tipoUsuario);
            return ResponseEntity.status(HttpStatus.CREATED).body("Usuario registrado exitosamente");
        } catch (Exception ex) {
            return ResponseEntity.badRequest().body("Error al registrar: " + ex.getMessage());
        }
    }
    // Libre acceso para que la gente se registre
    @PostMapping("/registro")
    public ResponseEntity<?> registrarUsuario(@RequestBody Map<String, String> body) {
        try {
            String tipoUsuario = "PASAJERO";
            usuarioService.register(body, tipoUsuario);
            return ResponseEntity.status(HttpStatus.CREATED).body("Usuario registrado exitosamente");
        } catch (Exception ex) {
            return ResponseEntity.badRequest().body("Error al registrar: " + ex.getMessage());
        }
    }

    // Protegido: Solo Administradores TI
    @GetMapping
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<List<Usuario>> listarTodos() {
        return ResponseEntity.ok(usuarioService.obtenerTodos());
    }

    // Protegido: Administradores TI y Funcionarios PDI
    @GetMapping("/buscar/{rut}")
    @PreAuthorize("hasAnyRole('ADMIN', 'PDI')")
    public ResponseEntity<?> obtenerPorRut(@PathVariable String rut) {
        return usuarioService.findByRut(rut)
                .map(usuario -> ResponseEntity.ok((Object) usuario))
                .orElse(ResponseEntity.status(HttpStatus.NOT_FOUND).body("Usuario no encontrado"));
    }
}