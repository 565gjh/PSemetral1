package com.example.MsIdentidad.model;

import jakarta.persistence.Column;
import jakarta.persistence.DiscriminatorValue;
import jakarta.persistence.Entity;
import java.util.List;

@Entity
@DiscriminatorValue("ADUANA_OPE")
public class FuncionarioAduana extends Usuario {

    @Column(name = "numero_placa")
    private String numeroPlacaFuncionario;

    public String getNumeroPlacaFuncionario() { return numeroPlacaFuncionario; }
    public void setNumeroPlacaFuncionario(String numeroPlacaFuncionario) { this.numeroPlacaFuncionario = numeroPlacaFuncionario; }

    @Override
    public List<String> obtenerPermisos() {
        return List.of(
                "ROLE_ADUANA",
                "leer:datos_vehiculo",
                "escribir:aprobacion_aduanera"
        );
    }
}
