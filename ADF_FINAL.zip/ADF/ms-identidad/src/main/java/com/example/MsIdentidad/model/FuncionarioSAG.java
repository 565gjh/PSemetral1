package com.example.MsIdentidad.model;

import jakarta.persistence.Column;
import jakarta.persistence.DiscriminatorValue;
import jakarta.persistence.Entity;
import java.util.List;

@Entity
@DiscriminatorValue("SAG_OPE")
public class FuncionarioSAG extends Usuario {

    @Column(name = "zona_inspeccion")
    private String zonaInspeccion;

    public String getZonaInspeccion() { return zonaInspeccion; }
    public void setZonaInspeccion(String zonaInspeccion) { this.zonaInspeccion = zonaInspeccion; }

    @Override
    public List<String> obtenerPermisos() {
        return List.of(
                "ROLE_SAG",
                "leer:declaracion_sag",
                "escribir:aprobacion_fitozoosanitaria"
        );
    }
}
