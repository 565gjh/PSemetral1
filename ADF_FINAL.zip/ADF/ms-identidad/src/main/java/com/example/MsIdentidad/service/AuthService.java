package com.example.MsIdentidad.service;

import com.example.MsIdentidad.model.Usuario;
import com.example.MsIdentidad.repository.UsuarioRepository;
import com.example.MsIdentidad.security.jwt.JwtService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class AuthService {

    @Autowired
    private UsuarioRepository usuarioRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private JwtService jwtService;

    public String autenticarYGenerarToken(String rut, String passwordPlana) {
        Optional<Usuario> usuarioOpt = usuarioRepository.findByRut(rut);

        if (usuarioOpt.isEmpty()) {
            throw new RuntimeException("Error de acceso. Usuario o contraseña incorrectos");
        }

        Usuario usuario = usuarioOpt.get();

        if (!passwordEncoder.matches(passwordPlana, usuario.getPasswordCifrada())) {
            throw new RuntimeException("Error de acceso. Usuario o contraseña incorrectos");
        }

        // Se invoca el método que trae los roles gracias a la herencia
        return jwtService.generateToken(usuario.getRut(), usuario.obtenerPermisos());
    }
    public Optional<Usuario> findByRut(String rut) {
        return usuarioRepository.findByRut(rut);
    }
}