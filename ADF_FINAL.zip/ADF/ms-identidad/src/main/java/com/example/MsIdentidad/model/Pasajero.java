package com.example.MsIdentidad.model;

import jakarta.persistence.Column;
import jakarta.persistence.DiscriminatorValue;
import jakarta.persistence.Entity;
import java.util.List;

@Entity
@DiscriminatorValue("PASAJERO")
public class Pasajero extends Usuario {

    @Column(name = "nacionalidad")
    private String nacionalidad;

    public String getNacionalidad() { return nacionalidad; }
    public void setNacionalidad(String nacionalidad) { this.nacionalidad = nacionalidad; }

    @Override
    public List<String> obtenerPermisos() {
        return List.of(
                "ROLE_PASAJERO",
                "escribir:declaracion_sag",
                "escribir:registro_vehiculo",
                "leer:mis_tramites"
        );
    }
}