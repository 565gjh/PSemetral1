package com.example.MsIdentidad.controller;

import com.example.MsIdentidad.service.AuthService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/api/v1/auth")
public class AuthController {

    @Autowired
    private AuthService authService;

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody Map<String, String> credenciales) {
        String rut = credenciales.get("rut");
        String password = credenciales.get("password");

        if (rut == null || password == null) {
            return ResponseEntity.badRequest().body("Debe ingresar RUT y contraseña");
        }

        try {
            String token = authService.autenticarYGenerarToken(rut, password);

            Map<String, Object> response = new HashMap<>();
            response.put("status", "success");
            response.put("token", token);

            return ResponseEntity.ok(response);
        } catch (RuntimeException ex) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(ex.getMessage());
        }
    }
}