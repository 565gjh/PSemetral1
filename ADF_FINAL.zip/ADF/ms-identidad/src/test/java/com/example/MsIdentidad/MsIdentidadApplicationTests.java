package com.example.MsIdentidad;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsIdentidadApplicationTests {

	@Test
	void contextLoads() {
	}

}
