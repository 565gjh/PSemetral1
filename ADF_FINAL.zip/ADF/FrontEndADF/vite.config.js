import { defineConfig } from 'vite'
import vue from '@vitejs/plugin-vue'

export default defineConfig({
  plugins: [vue()],
  server: {
    proxy: {
      '/api': {
        target: 'http://localhost:9091', // Pon aquí el puerto real de tu backend
        changeOrigin: true
      }
    }
  }
})