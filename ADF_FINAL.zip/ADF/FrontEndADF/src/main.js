import { createApp } from 'vue'
import App from './App.vue'
import router from './router' // El archivo de rutas que revisamos antes
import './style.css' // Tus estilos globales

const app = createApp(App)

app.use(router) // <-- ¡ESTA LÍNEA ES OBLIGATORIA! Si no está, <router-link> no funciona.

app.mount('#app')