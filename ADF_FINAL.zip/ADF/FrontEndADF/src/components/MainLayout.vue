<template>
  <div class="app-container">
    <header class="main-header">
      <div class="header-left">
        <img src="../assets/LogoGob.png" alt="Logo del Gobierno de Chile" class="gov-logo" />
        
        <h1 class="gov-title"><strong>ADF</strong> | Aduana Fronteriza</h1>
      </div>
      
      <div class="header-right">
        <slot name="user-actions"></slot>
        
        <button class="menu-button" aria-label="Menú">
          <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M3 6H21M3 12H21M3 18H21" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
          </svg>
        </button>
      </div>
    </header>

    <main class="main-content">
      <slot></slot>
    </main>
  </div>
</template>

<script setup>
// Tu lógica aquí
</script>

<style>
/* RESET DE MÁRGENES (Importante para que no haya espacios en blanco fuera de la app) */
body, html {
  margin: 0;
  padding: 0;
}

/* VARIABLES GLOBALES */
:root {
  --bg-app: #F4F6F8;
  --bg-card: #FFFFFF;
  --border-color: #E5E7EB;
  --text-primary: #000000;
  --font-family: system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
}

/* ESTILOS DEL LAYOUT */
.app-container {
  min-height: 100vh;
  background-color: var(--bg-app);
  font-family: var(--font-family);
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}

/* Barra Superior */
.main-header {
  background-color: var(--bg-card);
  color: var(--text-primary);
  /* CLAVE 1: Padding superior en 0 */
  padding: 0 24px 16px 24px; 
  display: flex;
  justify-content: space-between;
  /* CLAVE 2: Alineación hacia abajo para que el botón menú se mantenga a nivel del texto */
  align-items: flex-end; 
  border-bottom: 1px solid var(--border-color);
  
  /* CLAVE 3: Asegurar que no hay bordes redondeados ni márgenes heredados */
  margin: 0;
  border-radius: 0;
}

/* Contenedor Izquierdo */
.header-left {
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  gap: 12px; /* Separación exacta entre logo y título */
  margin: 0; 
  padding: 0;
}

/* Logo del Gobierno */
.gov-logo {
  height: 30px; /* Ajusta este tamaño si lo ves muy grande/pequeño */
  width: auto;
  display: block;
  /* IMPORTANTE: Si el SVG por sí solo trae un espacio en blanco oculto arriba, descomenta esta línea: */
  /* margin-top: -8px; */
}

/* Título principal */
.gov-title {
  font-size: 24px;
  font-weight: 300; 
  margin: 0; /* Quita márgenes automáticos del h1 */
  color: var(--text-primary);
  line-height: 1; /* Para que la caja del texto no agregue espacio extra */
}

.gov-title strong {
  font-weight: 700; 
}

.header-right {
  display: flex;
  align-items: center;
  gap: 16px;
  /* Empujamos el menú un poco hacia arriba para que quede centrado con el texto */
  margin-bottom: 4px;
}

/* Botón de Menú Hamburguesa */
.menu-button {
  background: transparent;
  border: none;
  cursor: pointer;
  padding: 0; /* Sin padding para no descuadrar */
  display: flex;
  align-items: center;
  justify-content: center;
  color: var(--text-primary);
}

.menu-button svg {
  width: 32px;
  height: 32px;
}

/* Contenedor Principal */
.main-content {
  max-width: 1440px;
  margin: 0 auto;
  padding: 24px;
}
</style>