<template>
  <MainLayout>
    <router-view />
  </MainLayout>
</template>

<script setup>
import MainLayout from './components/MainLayout.vue';
// Eliminamos la importación de Login desde aquí, ya que ahora lo maneja el router
</script>

<style>
/* Reemplaza "el-nombre-del-contenedor" por la clase o ID que viste en el inspector */
.el-nombre-del-contenedor {
  padding: 0 !important;
}

/* Si la etiqueta era simplemente un <main>, sería así: */
main {
  padding: 0 !important;
}
</style>