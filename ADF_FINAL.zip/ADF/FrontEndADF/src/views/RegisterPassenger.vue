<template>
  <div class="register-container">
    
    <div class="brand-logo-card">
      <img src="../assets/logoAduana.png" alt="Aduanas Chile" class="logo-img" />
      <div class="logo-divider"></div>
      <p class="logo-subtitle">Servicio Nacional de Aduanas - Control Digital de Pasajeros</p>
    </div>

    <div class="form-wrapper">
      <a href="#" @click.prevent="goBack" class="back-link">
        &larr; Volver al inicio de sesión
      </a>

      <div class="register-card">
        
        <div class="card-header">
          <div class="header-icon">📝</div>
          <div class="header-text">
            <h2>Registro de Pasajero</h2>
            <p>Complete todos los campos para crear su cuenta en el portal</p>
          </div>
        </div>

        <form @submit.prevent="handleRegister" class="register-form">
          
          <h3 class="section-title">DATOS PERSONALES</h3>
          
          <div class="form-group full-width">
            <label>Nombre Completo *</label>
            <input type="text" v-model="form.nombreCompleto" placeholder="Ej: María José González Pérez" required />
          </div>

          <div class="form-row">
            <div class="form-group">
              <label>Identificador (RUT / Pasaporte / DNI) *</label>
              <input type="text" v-model="form.rut" placeholder="Ej: 12345678-9 o AB123456" required />
            </div>
            <div class="form-group">
              <label>Nacionalidad *</label>
              <select v-model="form.nacionalidad" required>
                <option value="" disabled selected>Seleccione su nacionalidad</option>
                <option value="chilena">Chilena</option>
                <option value="argentina">Argentina</option>
                <option value="boliviana">Boliviana</option>
                <option value="peruana">Peruana</option>
                <option value="otra">Otra</option>
              </select>
            </div>
          </div>

          <h3 class="section-title">DATOS DE CONTACTO</h3>
          
          <div class="form-row">
            <div class="form-group">
              <label>Correo Electrónico *</label>
              <input type="email" v-model="form.correo" placeholder="correo@ejemplo.com" required />
            </div>
            <div class="form-group">
              <label>Teléfono Celular *</label>
              <input type="tel" v-model="form.celular" placeholder="Ej: +56912345678" required />
            </div>
          </div>

          <h3 class="section-title">DATOS DE ACCESO</h3>
          
          <div class="form-row">
            <div class="form-group">
              <label>Contraseña *</label>
              <div class="input-with-icon">
                <input :type="showPassword ? 'text' : 'password'" v-model="form.contrasena" placeholder="Mínimo 8 caracteres" required />
                <span class="toggle-password" @click="showPassword = !showPassword">
                  {{ showPassword ? '👁️' : '👁️‍🗨️' }}
                </span>
              </div>
            </div>
            <div class="form-group">
              <label>Confirmar Contraseña *</label>
              <div class="input-with-icon">
                <input :type="showConfirm ? 'text' : 'password'" v-model="form.confirmPassword" placeholder="Repita su contraseña" required />
                <span class="toggle-password" @click="showConfirm = !showConfirm">
                  {{ showConfirm ? '👁️' : '👁️‍🗨️' }}
                </span>
              </div>
            </div>
          </div>

          <div class="legal-notice">
            <span class="shield-icon">🛡️</span>
            <p>Sus datos serán tratados con estricta confidencialidad conforme a la Ley N° 19.628 sobre protección de datos personales.</p>
          </div>

          <div class="actions-footer">
            <button type="button" @click="goBack" class="btn-cancel">Cancelar</button>
            <button type="submit" class="btn-submit" :disabled="isSubmitting">
              {{ isSubmitting ? 'Procesando...' : 'Crear Cuenta' }}
            </button>
          </div>

        </form>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue';
import { useRouter } from 'vue-router';

const router = useRouter();
const isSubmitting = ref(false);

const showPassword = ref(false);
const showConfirm = ref(false);

// Estado reactivo alineado a los nombres del formulario adaptado
const form = ref({
  nombreCompleto: '',
  rut: '',
  nacionalidad: '',
  correo: '',
  celular: '',
  contrasena: '',
  confirmPassword: ''
});

const handleRegister = async () => {
  // 1. Validar que las contraseñas coincidan localmente antes de enviar
  if (form.value.contrasena !== form.value.confirmPassword) {
    alert("❌ Las contraseñas ingresadas no coinciden. Por favor, verifique.");
    return;
  }

  isSubmitting.value = true;

  // 2. Construir exactamente el JSON requerido por tu endpoint
  const payload = {
     // Campo fijo solicitado
    nombreCompleto: form.value.nombreCompleto,
    rut: form.value.rut,
    correo: form.value.correo,
    celular: form.value.celular,
    password: form.value.contrasena, // Mapeado con la 'ñ' según tu especificación
    nacionalidad: form.value.nacionalidad
  };

  try {
    // 3. Realizar la petición POST al puerto 9091
    const response = await fetch('http://localhost:9091/api/v1/usuarios/registro', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(payload)
    });

    // 4. Procesar la respuesta del servidor
    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}));
      throw new Error(errorData.message || `Error en el servidor: ${response.status}`);
    }

    alert("🎉 ¡Registro exitoso! Su cuenta de PASAJERO ha sido creada correctamente.");
    
    // Redireccionar al inicio de sesión tras el éxito
    router.push('/'); 

  } catch (error) {
    console.error("Error durante el registro:", error);
    alert(`⚠️ No se pudo completar el registro: ${error.message}`);
  } finally {
    isSubmitting.value = false;
  }
};

const goBack = () => {
  router.push('/');
};
</script>
<style scoped>
/* 🏔️ Fondo de Paso Los Libertadores */
.register-container {
  min-height: 100vh;
  width: 100vw;
  display: flex;
  justify-content: center;
  align-items: flex-start;
  position: absolute;
  top: 0;
  left: 0;
  /* Fondo oscuro semitransparente sobre tu imagen para que resalte la tarjeta */
  background-image:  linear-gradient(rgba(51, 102, 153, 0.75), rgba(11, 26, 41, 0.75)), 
                    url('../assets/PasoLosLibertadores.jpg'); 
  background-size: cover;
  background-position: center;
  background-repeat: no-repeat;
  background-attachment: fixed; /* ⬅️ CAMBIO 3 (NUEVO): Evita que el fondo se mueva o se corte al hacer scroll hacia abajo */
  font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
  padding: 40px 20px;
  box-sizing: border-box;
  overflow-y: auto;
}


/* 🇨🇱 Tarjeta Flotante Logo (Igual que antes) */
.brand-logo-card {
  position: fixed;
  top: 0px;
  left: 30px;
 
  padding: 4px;
  border-radius: 12px;
  
  display: flex;
  flex-direction: column;
  align-items: center;
  max-width: 220px;
  
}

.logo-img { width: 100%; max-height: 70px; object-fit: contain; }
.logo-divider { width: 100%; height: 1px; background-color: #e2e8f0; margin: 12px 0; }
.logo-subtitle { font-size: 0.65rem; font-weight: 700; color: #ffffff; text-align: center; text-transform: uppercase; margin: 0; }

/* 📦 Contenedor del Formulario */
.form-wrapper {
  width: 100%;
  max-width: 650px;
  display: flex;
  flex-direction: column;
  gap: 10px;
  z-index: 5;
  margin-top: 20px;
  
}

/* Enlace Volver */
.back-link {
  color: #ffffff;
  text-decoration: none;
  font-weight: 600;
  font-size: 0.9rem;
  align-self: flex-start;
  text-shadow: 1px 1px 4px rgba(0,0,0,0.5);
  transition: opacity 0.2s;
}
.back-link:hover { opacity: 0.8; }

/* Tarjeta Estilo Imagen 6e1618 */
.register-card {
  background-color: #ffffff;
  border-radius: 8px;
  box-shadow: 0 20px 40px rgba(0, 0, 0, 0.3);
  overflow: hidden; /* Para que el header azul respete los bordes curvos */
}

/* Encabezado Azul Oscuro */
.card-header {
  background-color: #002b5c;
  color: #ffffff;
  padding: 24px 30px;
  display: flex;
  align-items: center;
  gap: 15px;
}
.header-icon {
  background-color: rgba(255,255,255,0.1);
  padding: 10px;
  border-radius: 8px;
  font-size: 1.2rem;
}
.header-text h2 { margin: 0 0 5px 0; font-size: 1.4rem; font-weight: 700; }
.header-text p { margin: 0; font-size: 0.85rem; color: #b4c6dc; }

/* Cuerpo del Formulario */
.register-form {
  padding: 30px;
  display: flex;
  flex-direction: column;
  gap: 20px;
}

/* Títulos de Sección */
.section-title {
  color: #004b93;
  font-size: 0.8rem;
  font-weight: 700;
  margin: 10px 0 0 0;
  padding-bottom: 8px;
  border-bottom: 1px solid #e2e8f0;
  text-transform: uppercase;
  letter-spacing: 0.5px;
}

/* Grillas de Inputs */
.form-row {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 20px;
}
.form-group {
  display: flex;
  flex-direction: column;
  gap: 6px;
}
.form-group label {
  font-size: 0.85rem;
  font-weight: 600;
  color: #334155;
}
.form-group input, .form-group select {
  width: 100%;
  padding: 10px 14px;
  border: 1px solid #cbd5e1;
  border-radius: 6px;
  font-size: 0.9rem;
  color: #1e293b;
  background-color: #ffffff;
  transition: border-color 0.2s;
  box-sizing: border-box;
}
.form-group input:focus, .form-group select:focus {
  outline: none;
  border-color: #004b93;
}
.form-group select { appearance: auto; cursor: pointer; }

/* Input con ojito para contraseñas */
.input-with-icon {
  position: relative;
  display: flex;
  align-items: center;
}
.toggle-password {
  position: absolute;
  right: 12px;
  cursor: pointer;
  color: #94a3b8;
  font-size: 1.1rem;
}

/* Caja Legal Azul Clara */
.legal-notice {
  background-color: #f0f7ff;
  border: 1px solid #cce4ff;
  border-radius: 6px;
  padding: 15px;
  display: flex;
  align-items: flex-start;
  gap: 12px;
  margin-top: 10px;
}
.shield-icon { font-size: 1.2rem; }
.legal-notice p {
  margin: 0;
  font-size: 0.8rem;
  color: #00366b;
  line-height: 1.4;
}

/* Footer de Botones */
.actions-footer {
  display: flex;
  justify-content: space-between;
  margin-top: 20px;
  padding-top: 20px;
  border-top: 1px solid #e2e8f0;
}
.btn-cancel {
  background-color: #ffffff;
  color: #64748b;
  border: 1px solid #cbd5e1;
  padding: 10px 24px;
  border-radius: 6px;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.2s;
}
.btn-cancel:hover { background-color: #f8fafc; color: #334155; }

.btn-submit {
  background-color: #002b5c;
  color: white;
  border: none;
  padding: 10px 30px;
  border-radius: 6px;
  font-weight: 600;
  cursor: pointer;
  transition: background-color 0.2s;
}
.btn-submit:hover:not(:disabled) { background-color: #001f3f; }
.btn-submit:disabled { background-color: #94a3b8; cursor: not-allowed; }

/* Adaptación a Móviles */
@media (max-width: 768px) {
  .form-row { grid-template-columns: 1fr; gap: 15px; }
  .register-container { align-items: flex-start; padding-top: 130px; }
  .brand-logo-card {
    top: 15px; left: 50%; transform: translateX(-50%);
    width: calc(100% - 40px); max-width: none;
    flex-direction: row; gap: 15px; padding: 10px;
  }
  .logo-img { max-height: 40px; width: auto; }
  .logo-divider { width: 1px; height: 30px; margin: 0; }
  .actions-footer { flex-direction: column-reverse; gap: 10px; }
  .btn-submit, .btn-cancel { width: 100%; }
}
</style>