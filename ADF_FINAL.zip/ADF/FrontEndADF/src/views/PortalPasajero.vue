<template>
  <main class="page-background">
    <div class="portal-wrapper">
      
      <div class="welcome-banner">
        <div class="welcome-text">
          <h2 class="welcome-title">Bienvenido/a, Pasajero</h2>
          <p class="welcome-subtitle">Gestione sus Declaraciones Juradas de ingreso a Chile de forma rápida y segura.</p>
        </div>
        <button class="btn-logout" @click="handleLogout">
          Cerrar Sesión
        </button>
      </div>

      <div class="alert-banner">
        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="alert-icon"><path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3Z"></path><line x1="12" y1="9" x2="12" y2="13"></line><line x1="12" y1="17" x2="12.01" y2="17"></line></svg>
        <div>
          <strong>Importante:</strong> Todo producto de origen vegetal o animal debe ser declarado. Evite multas y colabore con la protección fito y zoosanitaria de Chile.
        </div>
      </div>

      <div class="dashboard-grid">
        
        <div class="action-card primary-action">
          <div class="action-icon-wrapper">
            <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline><line x1="16" y1="13" x2="8" y2="13"></line><line x1="16" y1="17" x2="8" y2="17"></line><polyline points="10 9 9 9 8 9"></polyline></svg>
          </div>
          <div class="action-content">
            <h3>Nueva Declaración Jurada</h3>
            <p>Complete su formulario SAG y de Aduanas antes de llegar al control fronterizo para agilizar su ingreso.</p>
            <button class="btn-primary" @click="iniciarDeclaracion">
              Iniciar Declaración
            </button>
          </div>
        </div>

        <div class="action-card secondary-action">
          <h3>¿Qué debo declarar?</h3>
          <ul class="help-list">
            <li>Frutas, verduras, semillas y plantas.</li>
            <li>Carnes, fiambres, lácteos y quesos.</li>
            <li>Artesanías en madera sin tratar.</li>
            <li>Dinero en efectivo superior a 10.000 USD.</li>
          </ul>
          <a href="#" class="link-more">Ver listado completo →</a>
        </div>

      </div>

      <div class="history-section">
        <div class="history-header">
          <h3>Mis Declaraciones Recientes</h3>
        </div>
        
        <div class="table-container">
          <table class="data-table">
            <thead>
              <tr>
                <th>FECHA</th>
                <th>CÓDIGO DECLARACIÓN</th>
                <th>PASO FRONTERIZO</th>
                <th>ESTADO</th>
                <th>ACCIÓN</th>
              </tr>
            </thead>
            <tbody>
              <tr v-if="declaraciones.length === 0">
                <td colspan="5" class="empty-state">No tiene declaraciones recientes.</td>
              </tr>
              <tr v-for="decl in declaraciones" :key="decl.id">
                <td>{{ decl.fecha }}</td>
                <td class="font-mono">{{ decl.codigo }}</td>
                <td>{{ decl.paso }}</td>
                <td>
                  <span :class="['status-badge', decl.estado.toLowerCase()]">
                    {{ decl.estado }}
                  </span>
                </td>
                <td>
                  <button class="btn-text">Ver detalle</button>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

    </div>
  </main>
</template>

<script setup>
import { ref, onMounted, computed } from 'vue';
import { useRouter } from 'vue-router';

const userName = ref('Pasajero'); 
const router = useRouter();

const declaraciones = ref([]);

// Reutilizamos tu decodificador de JWT
const parseJwt = (token) => {
  try {
    const base64Url = token.split('.')[1];
    const base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
    return JSON.parse(window.atob(base64));
  } catch (e) {
    return null;
  }
};

const obtenerMisDeclaraciones = async () => {
  try {
    const token = localStorage.getItem('user_token');
    if (!token) return; // Si no hay token, no hacemos nada

    // Obtenemos el documento del usuario desde el token (asumiendo que está en 'sub')
    const tokenData = parseJwt(token);
    const numeroDocumento = tokenData.sub; 

    const response = await fetch(`http://localhost:9094/api/v1/fiscalizacion/historial/${numeroDocumento}`, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}` 
      }
    });

    if (!response.ok) {
      throw new Error(`Error HTTP: ${response.status}`);
    }

    const data = await response.json();

    // Mapeamos los datos de Java a los de tu tabla HTML
    declaraciones.value = data.map(decl => ({
      id: decl.id,
      // Formateamos la fecha a formato chileno (DD/MM/YYYY)
      fecha: new Date(decl.fechaDeclaracion).toLocaleDateString('es-CL'),
      // Rellenamos el ID con ceros para que parezca un código oficial (Ej: 00001423)
      codigo: decl.id.toString().padStart(8, '0'),
      paso: decl.nombreControl,
      estado: decl.estadoFiscalizacion
    }));

  } catch (error) {
    console.error("Error al obtener las declaraciones:", error);
  }
};

onMounted(() => {
  obtenerMisDeclaraciones();
});

const handleLogout = () => {
  localStorage.clear();
  router.push('/');
};

const iniciarDeclaracion = () => {
  router.push('/declaracion-sag');
};
</script>

<style>
/* Forzar pantalla completa globalmente */
html, body, #app {
  margin: 0 !important;
  padding: 0 !important;
  width: 100% !important;
  min-height: 100vh !important;
  box-sizing: border-box;
  overscroll-behavior: none;
}
</style>

<style scoped>
/* 1. EL FONDO QUE OCUPA TODO EL ANCHO */
.page-background {
  width: 100%;
  min-height: 100vh; /* Ajusta hasta abajo */
  
  /* Tu imagen de fondo */
  background-image: 
    linear-gradient(rgba(51, 102, 153, 0.75), rgba(11, 26, 41, 0.75)), 
    url('../assets/PasoLosLibertadores.jpg');
  background-size: cover;
  background-position: center;
  background-attachment: fixed;
  background-repeat: no-repeat;
  
  padding: 40px 0;
  box-sizing: border-box;
  overscroll-behavior: none;
}

/* 2. CONTENEDOR CENTRAL DE LAS TARJETAS */
.portal-wrapper {
  max-width: 1000px;
  margin: 0 auto; 
  padding: 0 20px; /* Padding base lateral */
  
  /* CAMBIAMOS MARGIN POR PADDING: */
  padding-top: 48px; /* <-- Esto empujará las tarjetas hacia abajo revelando el fondo */
  
  display: flex;
  flex-direction: column;
  gap: 24px;
}

/* 3. ESTILOS DE LOS COMPONENTES (Banners, botones, tablas) */
.welcome-banner {
  display: flex;
  justify-content: space-between;
  align-items: center;
  background-color: rgba(255, 255, 255, 0.95);
  padding: 24px;
  border-radius: 8px;
  box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
  border: 1px solid #E5E7EB;
}

.welcome-title {
  font-size: 20px;
  font-weight: 700;
  color: var(--brand-blue, #0F69B4);
  margin: 0 0 4px 0;
}

.welcome-subtitle {
  color: #6B7280;
  font-size: 14px;
  margin: 0;
}

.btn-logout {
  background: none;
  border: 1px solid #D1D5DB;
  padding: 8px 16px;
  border-radius: 6px;
  font-size: 13px;
  font-weight: 600;
  color: #4B5563;
  cursor: pointer;
  transition: all 0.2s;
}

.alert-banner {
  display: flex;
  gap: 12px;
  background-color: #FFFBEB;
  border-left: 4px solid #F59E0B;
  padding: 16px;
  border-radius: 6px;
  color: #92400E;
  font-size: 14px;
  align-items: flex-start;
  box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
}

.alert-icon {
  flex-shrink: 0;
  color: #D97706;
}

.dashboard-grid {
  display: grid;
  grid-template-columns: 2fr 1fr;
  gap: 20px;
}

@media (max-width: 768px) {
  .dashboard-grid {
    grid-template-columns: 1fr;
  }
}

.action-card {
  background-color: rgba(255, 255, 255, 0.95);
  padding: 24px;
  border-radius: 8px;
  box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
  border: 1px solid #E5E7EB;
}

.primary-action {
  display: flex;
  gap: 20px;
  align-items: center;
}

.action-icon-wrapper {
  background-color: #EFF6FF;
  color: var(--brand-blue, #0F69B4);
  padding: 16px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
}

.action-content h3 {
  margin: 0 0 8px 0;
  font-size: 18px;
  color: #111827;
}

.action-content p {
  color: #6B7280;
  font-size: 14px;
  margin: 0 0 16px 0;
  line-height: 1.5;
}

.btn-primary {
  background-color: var(--brand-blue, #0F69B4);
  color: white;
  border: none;
  padding: 10px 20px;
  border-radius: 6px;
  font-size: 14px;
  font-weight: 600;
  cursor: pointer;
}

.secondary-action h3 {
  margin: 0 0 12px 0;
  font-size: 16px;
  color: #111827;
}

.help-list {
  margin: 0 0 16px 0;
  padding-left: 20px;
  color: #4B5563;
  font-size: 13px;
  line-height: 1.6;
}

.link-more {
  font-size: 13px;
  color: var(--brand-blue, #0F69B4);
  text-decoration: none;
  font-weight: 600;
}

.history-section {
  background-color: rgba(255, 255, 255, 0.95);
  border-radius: 8px;
  box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
  border: 1px solid #E5E7EB;
  overflow: hidden;
}

.history-header {
  padding: 16px 20px;
  border-bottom: 1px solid #E5E7EB;
  background-color: rgba(249, 250, 251, 0.95);
}

.history-header h3 {
  margin: 0;
  font-size: 15px;
  color: #111827;
}

.table-container {
  overflow-x: auto;
}

.data-table {
  width: 100%;
  border-collapse: collapse;
  text-align: left;
}

.data-table th {
  padding: 12px 20px;
  font-size: 11px;
  font-weight: 700;
  color: #6B7280;
  text-transform: uppercase;
  border-bottom: 1px solid #E5E7EB;
}

.data-table td {
  padding: 14px 20px;
  font-size: 14px;
  color: #111827;
  border-bottom: 1px solid #E5E7EB;
}

.font-mono {
  font-family: monospace;
  color: #4B5563;
}

.empty-state {
  text-align: center;
  color: #9CA3AF;
  padding: 32px !important;
}

.btn-text {
  background: none;
  border: none;
  color: var(--brand-blue, #0F69B4);
  font-size: 13px;
  font-weight: 600;
  cursor: pointer;
  padding: 0;
}

.status-badge {
  padding: 4px 8px;
  border-radius: 12px;
  font-size: 0.75rem;
  font-weight: bold;
}
.pendiente { background-color: #fff3cd; color: #856404; }
.aprobado { background-color: #d4edda; color: #155724; }
.rechazado_producto_prohibido { background-color: #f8d7da; color: #721c24; }
</style>