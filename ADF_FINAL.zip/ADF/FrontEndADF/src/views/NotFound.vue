<template>
  <div class="not-found-container">
    <div class="error-card">
      <h1 class="error-code">404</h1>
      <h2 class="error-title">Página no encontrada</h2>
      <p class="error-message">
        Lo sentimos, la dirección que intentas buscar no existe o ha sido movida.
      </p>
      
      <router-link to="/" class="btn-primary back-btn">
        Volver al Inicio
      </router-link>
    </div>
  </div>
</template>

<script setup>
// No requiere lógica extra, solo es visual
</script>

<style scoped>
.not-found-container {
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 100vh;
  background-color: #F4F6F8; /* Mismo fondo de tu app */
  padding: 20px;
}

.error-card {
  background-color: #ffffff;
  padding: 40px 30px;
  border-radius: 12px;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.05);
  text-align: center;
  max-width: 400px;
  width: 100%;
}

.error-code {
  font-size: 80px;
  font-weight: 800;
  color: #002884; /* Tu azul principal */
  margin: 0;
  line-height: 1;
}

.error-title {
  font-size: 20px;
  font-weight: 700;
  color: #1F2937;
  margin: 16px 0 8px 0;
}

.error-message {
  font-size: 14px;
  color: #6B7280;
  margin-bottom: 32px;
  line-height: 1.5;
}

.back-btn {
  display: inline-block;
  text-decoration: none;
  background-color: #002884;
  color: #ffffff;
  padding: 12px 24px;
  border-radius: 6px;
  font-weight: 600;
  transition: background-color 0.2s;
}

.back-btn:hover {
  background-color: #001a5c;
}
</style>