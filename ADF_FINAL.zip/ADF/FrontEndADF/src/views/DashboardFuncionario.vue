<template>
  <div class="dashboard-container">
    <aside class="sidebar">
      <div class="brand">
        <h2>ADUANAS CHILE</h2>
        <span class="badge-oficial">Control Fronterizo</span>
      </div>
      
      <nav class="menu">
        <button class="menu-item active">
          <i>🚗</i> Control de Vehículos
        </button>
        <button class="menu-item">
          <i>📦</i> Declaraciones de Carga
        </button>
        <button class="menu-item">
          <i>🔍</i> Perfilamiento de Riesgo
        </button>
      </nav>

      <div class="sidebar-footer">
        <div class="user-info">
          <p class="user-name">Funcionario Aduanero</p>
          <p class="user-rut">RUT: {{ officerRut }}</p>
        </div>
        <button @click="handleLogout" class="btn-logout">Cerrar Sesión</button>
      </div>
    </aside>

    <main class="main-content">
      <header class="content-header">
        <div class="welcome">
          <h1>Portal de Fiscalización Aduanera</h1>
          <p>Supervisión de ingreso de vehículos y mercancías al territorio nacional.</p>
        </div>
        <div class="date-badge">
          📅 {{ currentDate }}
        </div>
      </header>

      <section class="stats-grid">
        <div class="stat-card">
          <div class="stat-icon gray">🚗</div>
          <div>
            <h3>Vehículos Controlados</h3>
            <p class="stat-number">124</p>
          </div>
        </div>
        <div class="stat-card alert">
          <div class="stat-icon red">🚨</div>
          <div>
            <h3>Vehículos Retenidos</h3>
            <p class="stat-number">3</p>
          </div>
        </div>
        <div class="stat-card">
          <div class="stat-icon green">💵</div>
          <div>
            <h3>Recaudación Tasas</h3>
            <p class="stat-number">$1.2M</p>
          </div>
        </div>
      </section>

      <section class="work-panel">
        <div class="panel-header">
          <div>
            <h2>Fila de Vehículos en Tiempo Real</h2>
            <p class="panel-subtitle">Microservicio en puerto 9092 activo</p>
          </div>
          <button @click="obtenerVehiculosEnCola" class="btn-primary" :disabled="isLoading">
            <span v-if="isLoading">🔄 Cargando...</span>
            <span v-else>🔄 Sincronizar Cola</span>
          </button>
        </div>

        <div v-if="isLoading" class="loading-state">
          <div class="spinner"></div>
          <p>Consultando base de datos de aduanas...</p>
        </div>
        
        <div v-else-if="errorApi" class="error-state">
          <div class="error-icon">⚠️</div>
          <p>{{ errorApi }}</p>
          <button @click="obtenerVehiculosEnCola" class="btn-retry">Reintentar Conexión</button>
        </div>

        <div v-else class="table-responsive">
          <table class="data-table">
            <thead>
              <tr>
                <th>Placa Única (PPU)</th>
                <th>Marca y Modelo</th>
                <th>Conductor (RUT/Doc)</th>
                <th>País Origen</th>
                <th>Vencimiento Admisión</th>
                <th>Estado Fiscal</th>
                <th class="text-center">Acción</th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="item in listaVehiculos" :key="item.id" class="table-row">
                <td>
                  <div class="ppu-container">
                    <span class="ppu-chile">CHILE</span>
                    <span class="ppu-text">{{ item.patente }}</span>
                  </div>
                </td>
                
                <td>
                  <div class="vehicle-info">
                    <span class="vehicle-brand">{{ item.marca }}</span>
                    <span class="vehicle-model">{{ item.modelo }}</span>
                  </div>
                </td>
                
                <td class="text-muted font-mono">{{ item.documentoConductor }}</td>
                
                <td>
                  <span class="country-badge">📍 {{ item.paisOrigen }}</span>
                </td>
                
                <td>
                  <span :class="['date-text', !item.fechaVencimientoTemporal ? 'permanent' : '']">
                    {{ item.fechaVencimientoTemporal ? item.fechaVencimientoTemporal : 'Permanente' }}
                  </span>
                </td>
                
                <td>
                  <span :class="['status-pill', item.estado.toLowerCase()]">
                    <span class="led-dot"></span>
                    {{ item.estado }}
                  </span>
                </td>
                
                <td class="text-center">
                  <button class="btn-action-inspect">
                    <span>Inspeccionar</span>
                  </button>
                </td>
              </tr>
              
              <tr v-if="listaVehiculos.length === 0">
                <td colspan="7" class="empty-state">
                  📭 No hay vehículos registrados en la cola de inspección.
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </section>
    </main>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue';
import { useRouter } from 'vue-router';

const router = useRouter();
const officerRut = ref('Cargando...');
const currentDate = ref(new Date().toLocaleDateString('es-CL', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' }));

const listaVehiculos = ref([]);
const isLoading = ref(true);
const errorApi = ref(null);

const parseJwt = (token) => {
  try {
    const base64Url = token.split('.')[1];
    const base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
    return JSON.parse(window.atob(base64));
  } catch (e) {
    return null;
  }
};

const obtenerVehiculosEnCola = async () => {
  isLoading.value = true;
  errorApi.value = null;
  try {
    const token = localStorage.getItem('user_token');
    const response = await fetch('http://localhost:9092/api/v1/vehiculos', {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}` 
      }
    });

    if (!response.ok) {
      throw new Error(`Error en el servidor: ${response.status}`);
    }

    const data = await response.json();
    listaVehiculos.value = data;
  } catch (err) {
    console.error("Error al conectar con el microservicio de vehículos:", err);
    errorApi.value = "Error de enlace. Verifique que el microservicio en el puerto 9092 esté encendido.";
  } finally {
    isLoading.value = false;
  }
};

onMounted(() => {
  const token = localStorage.getItem('user_token');
  if (!token) {
    router.push('/');
    return;
  }

  const tokenData = parseJwt(token);
  if (tokenData && tokenData.sub) {
    officerRut.value = tokenData.sub;
  }

  obtenerVehiculosEnCola();
});

const handleLogout = () => {
  localStorage.clear();
  router.push('/');
};
</script>

<style scoped>
/* 🌍 Layout General */
.dashboard-container {
  display: flex;
  height: 100vh;
  width: 100vw;
  background-color: #f4f7fc;
  font-family: 'Segoe UI', system-ui, -apple-system, sans-serif;
  position: fixed;
  top: 0;
  left: 0;
}

/* 🗄️ Sidebar Premium */
.sidebar {
  width: 260px;
  background-color: #0b1e36;
  color: #ecf0f1;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  padding: 24px;
  box-shadow: 4px 0 10px rgba(0,0,0,0.05);
}
.brand h2 {
  font-size: 1.15rem;
  margin: 0 0 4px 0;
  font-weight: 800;
  letter-spacing: 1.5px;
}
.badge-oficial {
  background-color: #2575fc;
  font-size: 0.7rem;
  padding: 3px 8px;
  border-radius: 50px;
  font-weight: 600;
  text-transform: uppercase;
}
.menu {
  display: flex;
  flex-direction: column;
  gap: 8px;
  margin-top: 40px;
  flex-grow: 1;
}
.menu-item {
  background: none;
  border: none;
  color: #8a99ad;
  text-align: left;
  padding: 12px 16px;
  border-radius: 8px;
  cursor: pointer;
  font-size: 0.95rem;
  font-weight: 500;
  transition: all 0.2s ease;
  display: flex;
  align-items: center;
  gap: 10px;
}
.menu-item:hover, .menu-item.active {
  background-color: #162e4e;
  color: #fff;
}
.menu-item.active {
  border-left: 4px solid #2575fc;
}
.sidebar-footer {
  border-top: 1px solid #162e4e;
  padding-top: 20px;
}
.user-name { font-weight: 600; margin: 0; font-size: 0.95rem;}
.user-rut { font-size: 0.8rem; color: #637b99; margin: 2px 0 15px 0; font-family: monospace; }
.btn-logout {
  width: 100%;
  background-color: #e74c3c;
  color: white;
  border: none;
  padding: 10px;
  border-radius: 6px;
  cursor: pointer;
  font-weight: 600;
  transition: background 0.2s;
}
.btn-logout:hover { background-color: #c0392b; }

/* 🖥️ Main Content */
.main-content {
  flex-grow: 1;
  padding: 40px;
  overflow-y: auto;
}
.content-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 30px;
}
.content-header h1 { margin: 0 0 5px 0; color: #0b1e36; font-size: 1.8rem; font-weight: 700; }
.content-header p { margin: 0; color: #64748b; font-size: 0.95rem; }
.date-badge {
  background-color: #ffffff;
  padding: 10px 18px;
  border-radius: 30px;
  box-shadow: 0 2px 6px rgba(0,0,0,0.03);
  font-size: 0.85rem;
  font-weight: 600;
  color: #334155;
}

/* 📊 Grid de Estadísticas Modernas */
.stats-grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 24px;
  margin-bottom: 35px;
}
.stat-card {
  background: white;
  padding: 24px;
  border-radius: 16px;
  box-shadow: 0 4px 12px rgba(0,0,0,0.015);
  display: flex;
  align-items: center;
  gap: 20px;
}
.stat-icon {
  width: 48px;
  height: 48px;
  border-radius: 12px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 1.4rem;
}
.stat-icon.gray { background-color: #f1f5f9; }
.stat-icon.red { background-color: #fee2e2; }
.stat-icon.green { background-color: #dcfce7; }

.stat-card h3 { margin: 0; font-size: 0.8rem; color: #64748b; text-transform: uppercase; letter-spacing: 0.5px; }
.stat-number { font-size: 1.8rem; font-weight: 700; margin: 4px 0 0 0; color: #0b1e36; }

/* 🚗 Panel de Trabajo Principal */
.work-panel {
  background: white;
  padding: 30px;
  border-radius: 16px;
  box-shadow: 0 4px 20px rgba(0,0,0,0.02);
}
.panel-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 25px;
}
.panel-header h2 { margin: 0; font-size: 1.3rem; color: #0b1e36; font-weight: 700; }
.panel-subtitle { margin: 2px 0 0 0; font-size: 0.85rem; color: #94a3b8; }

.btn-primary {
  background: linear-gradient(135deg, #0b1e36 0%, #1e3a61 100%);
  color: white;
  border: none;
  padding: 12px 20px;
  border-radius: 8px;
  cursor: pointer;
  font-weight: 600;
  font-size: 0.9rem;
  transition: transform 0.1s;
}
.btn-primary:active { transform: scale(0.98); }

/* 📋 Estilizado de la Tabla Espectacular */
.table-responsive { overflow-x: auto; }
.data-table { width: 100%; border-collapse: separate; border-spacing: 0 10px; text-align: left; }
.data-table th {
  padding: 12px 16px;
  color: #64748b;
  font-size: 0.78rem;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 0.8px;
  border-bottom: 1px solid #edf2f7;
}
.table-row {
  background-color: #ffffff;
  transition: all 0.2s ease;
}
.table-row:hover {
  background-color: #f8fafc;
  transform: translateY(-2px);
  box-shadow: 0 4px 12px rgba(0,0,0,0.03);
}
.table-row td {
  padding: 16px;
  border-top: 1px solid #f1f5f9;
  border-bottom: 1px solid #f1f5f9;
  font-size: 0.92rem;
  vertical-align: middle;
}
.table-row td:first-child { border-left: 1px solid #f1f5f9; border-top-left-radius: 10px; border-bottom-left-radius: 10px; }
.table-row td:last-child { border-right: 1px solid #f1f5f9; border-top-right-radius: 10px; border-bottom-right-radius: 10px; }

/* 🇨🇱 Patente Chilena Réplica */
.ppu-container {
  display: inline-flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  background-color: #ffffff;
  border: 2px solid #1e293b;
  border-radius: 6px;
  padding: 2px 10px;
  width: 105px;
  box-shadow: 0 2px 4px rgba(0,0,0,0.05);
}
.ppu-chile {
  font-size: 0.55rem;
  font-weight: 900;
  color: #2563eb;
  letter-spacing: 1px;
  line-height: 1;
  margin-bottom: 1px;
}
.ppu-text {
  font-family: 'Consolas', 'Courier New', monospace;
  font-weight: 800;
  font-size: 1.05rem;
  color: #1e293b;
  letter-spacing: 0.5px;
  line-height: 1.1;
}

/* Info del Auto */
.vehicle-info { display: flex; flex-direction: column; }
.vehicle-brand { font-weight: 600; color: #1e293b; }
.vehicle-model { font-size: 0.85rem; color: #64748b; }

/* Otros componentes menores */
.text-muted { color: #64748b; }
.font-mono { font-family: monospace; font-size: 0.9rem; }
.text-center { text-align: center; }
.country-badge { background-color: #f1f5f9; padding: 4px 10px; border-radius: 30px; font-size: 0.85rem; font-weight: 500; }

.date-text { font-weight: 500; color: #334155; }
.date-text.permanent { color: #2563eb; font-weight: 600; font-style: italic; }

/* 🟢 Pill de Estados Moderno con LED */
.status-pill {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  padding: 6px 14px;
  border-radius: 50px;
  font-size: 0.78rem;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 0.5px;
}
.status-pill .led-dot {
  width: 7px;
  height: 7px;
  border-radius: 50%;
  display: inline-block;
}

/* Estado Activo */
.status-pill.activo { background-color: #dcfce7; color: #15803d; }
.status-pill.activo .led-dot { background-color: #22c55e; box-shadow: 0 0 8px #22c55e; }

/* Estado Retenido */
.status-pill.retenido { background-color: #fee2e2; color: #b91c1c; }
.status-pill.retenido .led-dot { background-color: #ef4444; box-shadow: 0 0 8px #ef4444; }

/* 🔘 Botón de Inspección Fluido */
.btn-action-inspect {
  background-color: #f1f5f9;
  border: none;
  color: #334155;
  padding: 8px 16px;
  border-radius: 8px;
  font-weight: 600;
  font-size: 0.85rem;
  cursor: pointer;
  transition: all 0.2s;
}
.btn-action-inspect:hover {
  background-color: #0b1e36;
  color: #ffffff;
}

/* loading / empty */
.loading-state, .error-state, .empty-state { text-align: center; padding: 50px; color: #64748b; }
.spinner {
  border: 3px solid #f3f3f3;
  border-top: 3px solid #0b1e36;
  border-radius: 50%;
  width: 30px;
  height: 30px;
  animation: spin 1s linear infinite;
  margin: 0 auto 15px auto;
}
@keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }
</style>