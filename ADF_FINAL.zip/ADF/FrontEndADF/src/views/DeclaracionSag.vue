<template>
  <div class="declaracion-container">
    <div v-if="pasoActual === 0" class="step-card initial-card">
      <h3>Declaración Jurada Digital para el ingreso a Chile</h3>
      <hr />
      <p>Si usted posee "Clave Única", puede realizar su declaración seleccionando la opción "Clave Única", con lo que algunos campos se autocompletarán.</p>
      <p>Si no posee "Clave Única" o no desea utilizarla, puede realizar su declaración seleccionando la opción "Sin Clave Única".</p>
      
      <div class="button-group-initial">
        <button class="btn-volver" @click="$router.push('/portal-pasajero')">VOLVER</button>
        <button class="btn-claveunique"><i class="fas fa-key"></i> ClaveÚnica</button>
        <button class="btn-primary" @click="pasoActual = 1">SIN CLAVE ÚNICA</button>
      </div>
    </div>

    <div v-else class="form-wrapper">
      <div class="stepper">
        <div v-for="n in 4" :key="n" :class="['step-circle', { active: pasoActual >= n }]">
          {{ n }}
        </div>
      </div>

      <div v-if="pasoActual === 1" class="step-card">
        <h4>Identificación</h4>
        <div class="form-grid">
          <div class="input-group full-width">
            <label>Nombre Completo</label>
            <input v-model="form.nombreCompleto" placeholder="Ej: Juan Carlos Pérez" />
          </div>
          <div class="input-group">
            <label>Correo electrónico</label>
            <input v-model="form.correo" type="email" placeholder="ejemplo@correo.com" />
          </div>
          <div class="input-group">
            <label>Género</label>
            <select v-model="form.genero">
              <option value="" disabled>Seleccione género</option>
              <option value="M">Masculino</option>
              <option value="F">Femenino</option>
              <option value="O">Otro</option>
            </select>
          </div>
        </div>
        <div class="sub-section">
          <h5>¿Esta declaración incluye el equipaje de menores de 18 años?</h5>
          <div class="radio-group">
            <label><input type="radio" :value="true" v-model="form.incluyeMenores" /> Sí</label>
            <label><input type="radio" :value="false" v-model="form.incluyeMenores" /> No</label>
          </div>
        </div>
      </div>

      <div v-if="pasoActual === 2" class="step-card">
        <h4>Información de viaje</h4>
        <div class="form-grid">
          <div class="input-group">
            <label>Tipo de Documento</label>
            <select v-model="form.tipoDocumento">
               <option value="" disabled>Seleccione documento</option>
               <option value="DNI">Documento de Identidad Chileno (RUT)</option>
               <option value="PASAPORTE">Pasaporte</option>
            </select>
          </div>
          <div class="input-group">
            <label>Número de Documento</label>
            <input v-model="form.numeroDocumento" placeholder="Número de documento" />
          </div>
          <div class="input-group">
            <label>País de procedencia</label>
            <input v-model="form.paisProcedencia" placeholder="¿De qué país viene?" />
          </div>
          <div class="input-group">
            <label>Nombre del Control Fronterizo</label>
            <input v-model="form.nombreControl" placeholder="Ej: Complejo Los Libertadores" />
          </div>
          <div class="input-group">
            <label>Medio de Transporte</label>
            <input v-model="form.medioTransporte" placeholder="Ej: Bus / Auto Particular / Avión" />
          </div>
          <div class="input-group">
            <label>Fecha de Llegada</label>
            <input v-model="form.fechaLlegada" type="date" />
          </div>
          
          <div class="input-group full-width">
            <label>Tipo de Control</label>
            <div class="control-type-selector">
              <button type="button" :class="{active: form.tipoControl === 'AEREO'}" @click="form.tipoControl = 'AEREO'">✈️ Aéreo</button>
              <button type="button" :class="{active: form.tipoControl === 'MARITIMO'}" @click="form.tipoControl = 'MARITIMO'">🚢 Marítimo</button>
              <button type="button" :class="{active: form.tipoControl === 'TERRESTRE'}" @click="form.tipoControl = 'TERRESTRE'">🚚 Terrestre</button>
            </div>
          </div>
        </div>
      </div>

      <div v-if="pasoActual === 3" class="step-card">
        <div class="declaration-item">
          <h4>Declaración Jurada Digital - SAG</h4>
          <p>Declaro traer conmigo uno o más productos de origen vegetal o animal</p>
          <div class="radio-group">
            <label><input type="radio" :value="true" v-model="form.traeProductosOrigenAnimalVegetal" /> Sí</label>
            <label><input type="radio" :value="false" v-model="form.traeProductosOrigenAnimalVegetal" /> No</label>
          </div>
          <button type="button" class="btn-info">MÁS INFORMACIÓN</button>
        </div>
        <hr />
        <div class="declaration-item">
          <h4>Declaración Jurada Digital - Aduana</h4>
          <p>Traigo mercancías no comprendidas en el concepto de equipaje</p>
          <div class="radio-group">
            <label><input type="radio" :value="true" v-model="form.traeMercanciasNoEquipaje" /> Sí</label>
            <label><input type="radio" :value="false" v-model="form.traeMercanciasNoEquipaje" /> No</label>
          </div>
        </div>
        <hr />
        <div class="declaration-item">
          <h4>Declaración de Moneda / Valores</h4>
          <p>Traigo conmigo portando una suma igual o superior a 10.000 dólares de EE.UU o su equivalente en otras monedas</p>
          <div class="radio-group">
            <label><input type="radio" :value="true" v-model="form.traeMas10000Dolares" /> Sí</label>
            <label><input type="radio" :value="false" v-model="form.traeMas10000Dolares" /> No</label>
          </div>
        </div>
      </div>

      <div v-if="pasoActual === 4" class="step-card">
        <h4>Resumen de su Declaración Jurada</h4>
        <p>Por favor, confirme que todos sus datos sean correctos antes de proceder legalmente con la declaración.</p>
        <div class="resumen-datos">
          <p><strong>Pasajero:</strong> {{ form.nombreCompleto }} ({{ form.correo }})</p>
          <p><strong>Documento:</strong> {{ form.tipoDocumento }} - {{ form.numeroDocumento }}</p>
          <p><strong>Control de Ingreso:</strong> {{ form.nombreControl }} ({{ form.tipoControl }})</p>
        </div>
      </div>

      <div class="navigation-buttons">
        <button type="button" class="btn-volver" @click="pasoActual--">VOLVER</button>
        <button type="button" v-if="pasoActual < 4" class="btn-primary" @click="pasoActual++">SIGUIENTE</button>
        <button type="button" v-else class="btn-declarar" @click="enviarDeclaracion">DECLARO</button>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, reactive } from 'vue';
import { useRouter } from 'vue-router';

const router = useRouter();
const pasoActual = ref(0);
const folioSimulado = ref('33063355');

// Tu estructura plana lista para la base de datos
const form = reactive({
  nombreCompleto: '',
  correo: '',
  genero: '',
  incluyeMenores: false,
  tipoDocumento: '',
  numeroDocumento: '',
  paisProcedencia: '',
  tipoControl: '',
  nombreControl: '',
  medioTransporte: '',
  fechaLlegada: '',
  traeProductosOrigenAnimalVegetal: false,
  traeMercanciasNoEquipaje: false,
  traeMas10000Dolares: false
});

const enviarDeclaracion = async () => {
  try {
    const token = localStorage.getItem('user_token'); 
    
    const response = await fetch('http://localhost:9094/api/v1/fiscalizacion/declaracion', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}` 
      },
      body: JSON.stringify(form)
    });

    if (!response.ok) {
      throw new Error(`Error en el servidor: ${response.status}`);
    }

    const data = await response.json();
    alert("Declaración enviada con éxito.");
    router.push('/portal-pasajero');
    
    
  } catch (error) {
    console.error("Error al despachar la declaración:", error);
    alert("Hubo un problema al procesar la declaración. Intente nuevamente.");
  }
};
</script>

<style scoped>
.declaracion-container {
  padding: 20px;
  background-color: #f0f2f5;
  min-height: 80vh;
  display: flex;
  justify-content: center;
  align-items: center;
}

.step-card {
  background: white;
  border: 1px solid #dcdcdc;
  border-radius: 8px;
  padding: 30px;
  width: 100%;
  max-width: 800px;
  box-shadow: 0 4px 6px rgba(0,0,0,0.05);
  margin-bottom: 20px;
}

.stepper {
  display: flex;
  justify-content: center;
  gap: 25px;
  margin-bottom: 25px;
}

.step-circle {
  width: 35px;
  height: 35px;
  border-radius: 50%;
  border: 2px solid #ccc;
  display: flex;
  align-items: center;
  justify-content: center;
  font-weight: bold;
  color: #666;
}

.step-circle.active {
  background-color: #00a650;
  color: white;
  border-color: #00a650;
}

.form-grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 20px;
  margin-top: 15px;
}

.input-group {
  display: flex;
  flex-direction: column;
  gap: 5px;
}

.input-group.full-width {
  grid-column: span 2;
}

label {
  font-weight: 600;
  font-size: 0.9rem;
  color: #444;
}

input, select {
  padding: 11px;
  border: 1px solid #ccc;
  border-radius: 4px;
  font-size: 1rem;
}

.radio-group {
  display: flex;
  gap: 20px;
  margin-top: 10px;
}

.control-type-selector {
  display: flex;
  gap: 10px;
  margin-top: 5px;
}

.control-type-selector button {
  flex: 1;
  padding: 12px;
  border: 1px solid #ccc;
  background: white;
  cursor: pointer;
  border-radius: 4px;
  font-weight: bold;
}

.control-type-selector button.active {
  background-color: #0056b3;
  color: white;
  border-color: #0056b3;
}

.declaration-item {
  margin-bottom: 20px;
}

.btn-info {
  background: none;
  border: none;
  color: #0056b3;
  text-decoration: underline;
  cursor: pointer;
  margin-top: 10px;
  font-size: 0.85rem;
}

.resumen-datos {
  background-color: #f8f9fa;
  padding: 15px;
  border-radius: 6px;
  border-left: 4px solid #00a650;
}

.navigation-buttons {
  display: flex;
  justify-content: space-between;
  margin-top: 25px;
}

.btn-primary, .btn-declarar {
  background-color: #0056b3;
  color: white;
  border: none;
  padding: 12px 30px;
  border-radius: 24px;
  cursor: pointer;
  font-weight: bold;
}

.btn-declarar {
  background-color: #00a650;
}

.btn-volver {
  background: white;
  color: #333;
  border: 1px solid #999;
  padding: 12px 30px;
  border-radius: 24px;
  cursor: pointer;
}

.btn-claveunique {
  background-color: #1e63af;
  color: white;
  border: none;
  padding: 12px 30px;
  border-radius: 24px;
  font-weight: bold;
}
</style>