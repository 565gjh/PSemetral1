package com.example.MsMigracion.service;

import com.example.MsMigracion.model.RegistroMigratorio;
import com.example.MsMigracion.repository.MigracionRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class MigracionService {

    private final MigracionRepository repository;

    public MigracionService(MigracionRepository repository) {
        this.repository = repository;
    }

    /**
     * Procesa el registro de un pasajero nuevo (Adulto o Menor).
     */
    public RegistroMigratorio registrarPasajero(RegistroMigratorio registro) {

        // Regla de Negocio: Validar permisos de menores de edad
        if (!registro.cumpleRequisitosMenor()) {
            registro.setEstado("RECHAZADO_FALTA_PERMISO");
            System.out.println("ALERTA PDI: Menor de edad rechazado por falta de autorización notarial.");
        } else {
            registro.setEstado("PENDIENTE");
        }

        // Se guarda en la base de datos
        return repository.save(registro);
    }

    /**
     * Devuelve la lista completa de pasajeros asociados a un vehículo.
     * Útil para que el frontend le muestre al funcionario PDI quiénes van en el auto.
     */
    public List<RegistroMigratorio> obtenerPasajerosPorVehiculo(String patente) {
        return repository.findByPatenteVehiculoAsociado(patente);
    }

    /**
     * Método interno usado para responderle al MS_Vehiculo si el auto puede cruzar.
     */
    public boolean verificarAutorizacionCruce(String patente) {
        List<RegistroMigratorio> pasajeros = repository.findByPatenteVehiculoAsociado(patente);

        // Si no hay pasajeros registrados, la PDI aún no hace su trabajo. El auto no pasa.
        if (pasajeros.isEmpty()) {
            return false;
        }

        // Verificamos que absolutamente TODOS los pasajeros tengan estado "APROBADO"
        return pasajeros.stream()
                .allMatch(pasajero -> "APROBADO".equals(pasajero.getEstado()));
    }
    public List<RegistroMigratorio> obtenerTodos() {
        return repository.findAll();
    }
    public List<RegistroMigratorio> findByEstado(String estado) {
        return repository.findByEstado(estado);
    }
    public List<RegistroMigratorio> findByNombresCompletos(String nombresCompletos) {
        return repository.findByNombresCompletos(nombresCompletos);
    }

}





