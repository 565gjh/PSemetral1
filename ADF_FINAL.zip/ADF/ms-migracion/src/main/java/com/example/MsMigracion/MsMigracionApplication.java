package com.example.MsMigracion;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MsMigracionApplication {

	public static void main(String[] args) {
		SpringApplication.run(MsMigracionApplication.class, args);
	}

}
