package com.example.MsVehiculo.security.jwt;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.JwtException;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Service;

import javax.crypto.SecretKey;
import java.util.Collections;
import java.util.Date;
import java.util.List;

@Service
public class JwtService {

    @Value("${jwt.secret}")
    private String secretKey;

    private SecretKey getSigningKey() {
        return Keys.hmacShaKeyFor(secretKey.getBytes());
    }

    /**
     * MÉTODO CENTRALIZADO: Abre el token una sola vez y devuelve el Payload (Claims).
     * Así no repetimos este código en cada método.
     */
    private Claims extractAllClaims(String token) throws JwtException {
        return Jwts.parser()
                .verifyWith(getSigningKey())
                .build()
                .parseSignedClaims(token)
                .getPayload();
    }

    public String extractUsername(String token) {
        try {
            return extractAllClaims(token).getSubject();
        } catch (JwtException e) {
            return null;
        }
    }

    public String extractRole(String token) {
        try {
            return extractAllClaims(token).get("rol", String.class);
        } catch (JwtException e) {
            return null;
        }
    }

    public List<String> extractPermisos(String token) {
        try {
            // Ahora sí usamos los Claims para extraer la lista
            List<String> permisos = extractAllClaims(token).get("permisos", List.class);
            return permisos != null ? permisos : Collections.emptyList();
        } catch (JwtException e) {
            return Collections.emptyList(); // Devolvemos lista vacía en vez de null para evitar NullPointerException
        }
    }

    public boolean isTokenValid(String token) {
        try {
            Claims claims = extractAllClaims(token);
            return claims.getExpiration() != null &&
                    claims.getExpiration().after(new Date());
        } catch (JwtException e) {
            return false;
        }
    }
}