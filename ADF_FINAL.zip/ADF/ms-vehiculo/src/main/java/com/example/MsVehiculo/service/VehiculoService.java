package com.example.MsVehiculo.service;


import com.example.MsVehiculo.client.AfipClient;
import com.example.MsVehiculo.client.CarabinerosClient;
import com.example.MsVehiculo.client.PdiClient;
import com.example.MsVehiculo.client.SagClient;
import com.example.MsVehiculo.model.Vehiculo;
import com.example.MsVehiculo.repository.VehiculoRepository;
import lombok.AllArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.List;

@AllArgsConstructor
@Service
public class VehiculoService {

    private final VehiculoRepository vehiculoRepository;
    private final CarabinerosClient carabinerosClient;
    private final AfipClient afipClient; // 1. Inyectamos el cliente de la AFIP
    private final PdiClient pdiClient;
    private final SagClient sagClient;
    // Inyección de dependencias por constructor (Modificada para incluir AFIP)

    public List<Vehiculo> obtenerTodos() {
        return vehiculoRepository.findAll();
    }

    public Vehiculo procesarLlegada(Vehiculo vehiculo) {

        // 1. Consultas a las APIs Externas (Ambas apuntan a tu MS_Simulador en el puerto 8099)
        boolean tieneEncargo = carabinerosClient.verificarEncargoRobo(vehiculo.getPatente());

        boolean folioAfipValido = true;
        if (vehiculo.getPaisOrigen() != null && vehiculo.getPaisOrigen().equalsIgnoreCase("ARGENTINA")) {
            // Solo si es argentino, consumimos el microservicio de AFIP
            folioAfipValido = afipClient.validarFolioArgentino(vehiculo.getFolioAfip());
        }
        // 2. Consulta INTERNA a tu propio MS_Migracion (Real)
        boolean pasajerosAprobadosPDI = pdiClient.verificarAutorizacionCruce(vehiculo.getPatente());

        boolean autorizaSag = sagClient.verificarAutorizacionSag(vehiculo.getPatente());

        // 2. Aplicamos las reglas de negocio institucionales
        if (tieneEncargo) {
            vehiculo.setEstado("RETENIDO");
            System.out.println("ALERTA: Vehículo retenido por encargo policial en Chile.");

        } else if (!folioAfipValido) {
            vehiculo.setEstado("RETENIDO");
            System.out.println("ALERTA: Vehículo retenido por documentación aduanera argentina inválida.");
        } else if (!pasajerosAprobadosPDI) {
            vehiculo.setEstado("RETENIDO");
            System.out.println("ALERTA: Vehículo retenido por documentacion rechazada por PDI.");
        } else if (!autorizaSag) {
            vehiculo.setEstado("RETENIDO_POR_SAG");
            System.out.println("BLOQUEO: Control del SAG pendiente o rechazado (alimentos/mascotas).");
        } else {
            // Si pasa ambas validaciones, se aprueba el ingreso
            vehiculo.setEstado("ACTIVO");
            // Aquí puedes ejecutar el método que calcula los 180 días legales del acuerdo internacional
            vehiculo.iniciarTransitoTemporal();
            System.out.println("Vehículo aprobado por AFIP y Carabineros. Trámite exitoso.");
        }

        // 3. Guardamos el estado final en la base de datos local (adf_vehiculos)
        return vehiculoRepository.save(vehiculo);
    }
}