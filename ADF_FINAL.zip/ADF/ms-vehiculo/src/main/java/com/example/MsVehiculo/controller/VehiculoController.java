package com.example.MsVehiculo.controller;

import com.example.MsVehiculo.model.Vehiculo;
import com.example.MsVehiculo.service.VehiculoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/api/v1/vehiculos")
public class VehiculoController {
    @Autowired
    private final VehiculoService vehiculoService;

    public VehiculoController(VehiculoService vehiculoService) {
        this.vehiculoService = vehiculoService;
    }

    @GetMapping
    @PreAuthorize("hasRole('ADUANA')")
    public ResponseEntity<List<Vehiculo>> listarTodos() {
        return ResponseEntity.ok(vehiculoService.obtenerTodos());
    }

    @PostMapping("/llegada")
    @PreAuthorize("hasRole('ADUANA')")
    public ResponseEntity<?> registrarLlegada(@RequestBody Vehiculo vehiculo) {

        Vehiculo resultado = vehiculoService.procesarLlegada(vehiculo);

        // Verificamos si entró en el modo de contingencia
        if ("PENDIENTE_POR_CAIDA_DB".equals(resultado.getEstado())) {
            Map<String, Object> errorOffline = new HashMap<>();
            errorOffline.put("mensaje", "Base de datos central caída. Guarde el trámite localmente.");
            errorOffline.put("accionRequerida", "ACTIVAR_INDEXED_DB");
            errorOffline.put("datosRescatados", resultado); // Pasamos los datos validados para que React los guarde

            return ResponseEntity.status(HttpStatus.SERVICE_UNAVAILABLE).body(errorOffline);
        }

        // Camino feliz (Guardado en MySQL correctamente)
        return ResponseEntity.ok(resultado);
    }
}