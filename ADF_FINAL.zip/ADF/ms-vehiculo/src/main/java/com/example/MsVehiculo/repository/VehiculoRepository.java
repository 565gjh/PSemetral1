package com.example.MsVehiculo.repository;

import com.example.MsVehiculo.model.Vehiculo;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;

public interface VehiculoRepository extends JpaRepository<Vehiculo, Long> {

}

