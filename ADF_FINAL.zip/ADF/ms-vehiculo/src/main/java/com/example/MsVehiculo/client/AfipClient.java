package com.example.MsVehiculo.client;

import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;

@Component
public class AfipClient {

    private final WebClient webClient;
    private final String URL_AFIP = "http://localhost:9099/api/v1/afip/admision-temporal";

    public AfipClient(WebClient webClient) {
        this.webClient = webClient;
    }

    public boolean validarFolioArgentino(String folio) {
        try {
            Boolean respuesta = webClient.get()
                    .uri(URL_AFIP + "?folio={folio}", folio)
                    .retrieve()
                    .bodyToMono(Boolean.class) // Pedimos Boolean directo
                    .timeout(java.time.Duration.ofSeconds(3))
                    .onErrorReturn(false) // Si falla la red, devolvemos false directamente
                    .block();

            return Boolean.TRUE.equals(respuesta);

        } catch (Exception e) {
            System.err.println("Excepción inesperada en AfipClient: " + e.getMessage());
            return false;
        }
    }
}