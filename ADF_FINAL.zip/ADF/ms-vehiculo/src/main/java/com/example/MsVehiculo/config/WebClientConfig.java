package com.example.MsVehiculo.config;

import io.netty.channel.ChannelOption;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.reactive.ReactorClientHttpConnector;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import org.springframework.web.reactive.function.client.ClientRequest;
import org.springframework.web.reactive.function.client.ExchangeFilterFunction;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.netty.http.client.HttpClient;

import java.time.Duration;

@Configuration
public class WebClientConfig {

    @Bean
    public WebClient webClient() {
        // Configuramos un tiempo máximo de conexión de 3 segundos
        HttpClient httpClient = HttpClient.create()
                .option(ChannelOption.CONNECT_TIMEOUT_MILLIS, 3000)
                .responseTimeout(Duration.ofSeconds(3));

        return WebClient.builder()
                .clientConnector(new ReactorClientHttpConnector(httpClient))
                .filter(addBearerTokenFilter()) // 👈 Inyectamos el filtro interceptor aquí
                .build();
    }

    /**
     * Filtro mágico: Captura el token de la petición entrante (Postman)
     * y se lo pega a las peticiones salientes (hacia PDI, SAG, etc.)
     */
    private ExchangeFilterFunction addBearerTokenFilter() {
        return (request, next) -> {
            ServletRequestAttributes attributes = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
            if (attributes != null) {
                HttpServletRequest servletRequest = attributes.getRequest();
                String token = servletRequest.getHeader("Authorization");

                // Si encontramos un token, clonamos la petición y le agregamos el header
                if (token != null) {
                    ClientRequest authRequest = ClientRequest.from(request)
                            .header("Authorization", token)
                            .build();
                    return next.exchange(authRequest);
                }
            }
            // Si no hay token, la dejamos pasar normal
            return next.exchange(request);
        };
    }
}
