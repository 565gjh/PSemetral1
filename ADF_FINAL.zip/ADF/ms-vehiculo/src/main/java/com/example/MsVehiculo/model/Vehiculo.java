package com.example.MsVehiculo.model;

import jakarta.persistence.*;
import lombok.Data;

import java.time.LocalDate;

@Data
@Entity
@Table(name = "vehiculos")
public class Vehiculo {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(unique = true, nullable = false, length = 10)
    private String patente;

    // --- NUEVAS VARIABLES DE INTERNACIONALIZACIÓN ---

    // Ej: "CHILE" o "ARGENTINA"
    @Column(nullable = false)
    private String paisOrigen;

    // Aquí guardas el "AFIP-999" si es argentino. Si es chileno, puede quedar null.
    private String folioAfip;

    // ------------------------------------------------

    private String marca;
    private String modelo;
    private String estado;

    // Datos del conductor y plazos (Acuerdo de 180 días)
    private String documentoConductor;
    private LocalDate fechaIngresoTemporal;
    private LocalDate fechaVencimientoTemporal;

    public Vehiculo() {}

    public void iniciarTransitoTemporal() {
        this.estado = "ACTIVO";
        this.fechaIngresoTemporal = LocalDate.now();
        this.fechaVencimientoTemporal = LocalDate.now().plusDays(180);
    }

    // Getters y Setters...
}