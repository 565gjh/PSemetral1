package com.example.MsVehiculo.client;

import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import reactor.core.publisher.Mono;
import java.time.Duration;

@Component
public class PdiClient {

    private final WebClient webClient;
    // URL apuntando a tu MS_Migracion real
    private final String URL_PDI_BASE = "http://localhost:9093/api/v1/migracion";

    public PdiClient(WebClient webClient) {
        this.webClient = webClient;
    }

    public boolean verificarAutorizacionCruce(String patente) {
        try {
            Boolean todosAprobados = webClient.get()
                    .uri(URL_PDI_BASE + "/vehiculo/{patente}/autorizacion-cruce", patente)
                    .retrieve()
                    .bodyToMono(Boolean.class)
                    .timeout(Duration.ofSeconds(4)) // Timeout para no bloquear Aduanas si PDI está lento
                    .onErrorResume(e -> {
                        System.err.println("Error de red al consultar a la PDI: " + e.getMessage());
                        return Mono.just(false); // Por seguridad, si PDI falla, no dejamos pasar el auto
                    })
                    .block();

            return Boolean.TRUE.equals(todosAprobados);

        } catch (WebClientResponseException e) {
            System.err.println("El MS_Migracion respondió con error HTTP: " + e.getStatusCode());
            return false;
        }
    }
}