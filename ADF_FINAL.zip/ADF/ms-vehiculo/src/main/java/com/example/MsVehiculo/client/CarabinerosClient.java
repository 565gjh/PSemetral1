package com.example.MsVehiculo.client;

import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

@Component
public class CarabinerosClient {

    private final WebClient webClient;
    private final String URL_CARABINEROS = "http://localhost:9099/api/v1/carabineros/encargo";

    public CarabinerosClient(WebClient webClient) {
        this.webClient = webClient;
    }

    public boolean verificarEncargoRobo(String patente) {
        try {
            // Le pedimos directamente un Boolean.class
            Boolean respuesta = webClient.get()
                    .uri(URL_CARABINEROS + "?patente={patente}", patente)
                    .retrieve()
                    .bodyToMono(Boolean.class)
                    .timeout(java.time.Duration.ofSeconds(3))
                    .onErrorResume(e -> {
                        System.err.println("Error de conexión con Carabineros: " + e.getMessage());
                        return Mono.just(false); // Devolvemos un boolean simple en caso de error
                    })
                    .block();

            // Boolean.TRUE.equals maneja automáticamente si la respuesta llega nula
            return Boolean.TRUE.equals(respuesta);

        } catch (Exception e) {
            System.err.println("Excepción inesperada en CarabinerosClient: " + e.getMessage());
            return false;
        }
    }
}