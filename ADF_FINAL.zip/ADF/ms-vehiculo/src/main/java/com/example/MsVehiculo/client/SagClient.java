package com.example.MsVehiculo.client;

import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import reactor.core.publisher.Mono;
import java.time.Duration;

@Component
public class SagClient {

    private final WebClient webClient;
    // URL apuntando a tu MS_Fiscalizacion real (Puerto 8084)
    private final String URL_SAG_BASE = "http://localhost:9094/api/v1/fiscalizacion";

    public SagClient(WebClient webClient) {
        this.webClient = webClient;
    }

    /**
     * Consulta al SAG si el vehículo con la patente indicada está autorizado para cruzar.
     */
    public boolean verificarAutorizacionSag(String patente) {
        try {
            // El endpoint del SAG nos devolverá un String con el estado final (ej: "APROBADO")
            String estadoSag = webClient.get()
                    .uri(URL_SAG_BASE + "/vehiculo/{patente}/estado", patente)
                    .retrieve()
                    .bodyToMono(String.class)
                    .timeout(Duration.ofSeconds(4)) // Si el SAG tarda más de 4 segundos, se corta
                    .onErrorResume(e -> {
                        System.err.println("Error de comunicación con el SAG: " + e.getMessage());
                        // Por seguridad nacional, ante una caída del sistema SAG, no dejamos pasar el auto
                        return Mono.just("ERROR_CONEXION");
                    })
                    .block();

            // Solo si el SAG marcó explícitamente como "APROBADO", damos el visto bueno
            return "APROBADO".equalsIgnoreCase(estadoSag);

        } catch (WebClientResponseException e) {
            System.err.println("El MS_Fiscalizacion respondió con error HTTP: " + e.getStatusCode());
            return false;
        }
    }
}