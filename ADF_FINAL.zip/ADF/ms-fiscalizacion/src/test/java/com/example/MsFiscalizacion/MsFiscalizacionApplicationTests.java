package com.example.MsFiscalizacion;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsFiscalizacionApplicationTests {

	@Test
	void contextLoads() {
	}

}
