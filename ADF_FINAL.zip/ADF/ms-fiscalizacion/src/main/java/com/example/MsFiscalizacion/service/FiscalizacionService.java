package com.example.MsFiscalizacion.service;

import com.example.MsFiscalizacion.model.DeclaracionSag;
import com.example.MsFiscalizacion.repository.FiscalizacionRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class FiscalizacionService {

    private final FiscalizacionRepository repository;

    public FiscalizacionService(FiscalizacionRepository repository) {
        this.repository = repository;
    }

    /**
     * Procesa la declaración inicial enviada desde el Frontend (React).
     */
    public DeclaracionSag guardarDeclaracion(DeclaracionSag declaracion) {
        // Evaluamos dinámicamente si necesita inspección basándonos en sus respuestas
        if (declaracion.requiereInspeccionFisica()) {
            declaracion.setEstadoFiscalizacion("RETENIDO_PARA_INSPECCION");
        } else {
            declaracion.setEstadoFiscalizacion("APROBADO_AUTOMATICO");
        }

        return repository.save(declaracion);
    }
    /**
     * Método para que el inspector SAG actualice el estado manualmente por Patente.
     */
    public DeclaracionSag resolverInspeccionManual(String patente, boolean apruebaInspector, String observaciones) {
        Optional<DeclaracionSag> optDeclaracion = repository.findTopByPatenteVehiculoAsociadoOrderByFechaDeclaracionDesc(patente);

        if (optDeclaracion.isEmpty()) {
            throw new RuntimeException("No existe declaración para la patente: " + patente);
        }

        DeclaracionSag declaracion = optDeclaracion.get();

        // 💡 Guardamos las notas del inspector (maletero revisado, decomisos, etc.)
        declaracion.setObservaciones(observaciones);

        if (apruebaInspector) {
            declaracion.setEstadoFiscalizacion("APROBADO");
        } else {
            declaracion.setEstadoFiscalizacion("RECHAZADO_PRODUCTO_PROHIBIDO");
        }

        return repository.save(declaracion);
    }

    /**
     * Método INTERNO que responde a la consulta del MS_Vehiculo (Aduanas) por Patente.
     */
    public String obtenerEstadoParaAduanas(String patente) {
        Optional<DeclaracionSag> declaracion = repository.findTopByPatenteVehiculoAsociadoOrderByFechaDeclaracionDesc(patente);

        if (declaracion.isEmpty()) {
            return "PENDIENTE_DE_DECLARACION";
        }

        return declaracion.get().getEstadoFiscalizacion();
    }

    public List<DeclaracionSag> obtenerTodos() {
        return repository.findAll();
    }

}





