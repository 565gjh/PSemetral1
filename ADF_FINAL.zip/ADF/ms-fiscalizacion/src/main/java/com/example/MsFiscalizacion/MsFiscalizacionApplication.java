package com.example.MsFiscalizacion;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MsFiscalizacionApplication {

	public static void main(String[] args) {
		SpringApplication.run(MsFiscalizacionApplication.class, args);
	}

}
