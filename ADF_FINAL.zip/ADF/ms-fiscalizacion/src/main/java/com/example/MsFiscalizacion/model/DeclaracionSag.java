package com.example.MsFiscalizacion.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.time.LocalDateTime;


@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
@Table(name = "declaraciones_sag")
public class DeclaracionSag {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // --- Identificación del Pasajero ---
    @Column(nullable = false)
    private String nombreCompleto;

    @Column(nullable = false)
    private String correo;

    @Column(nullable = false, length = 1)
    private String genero;

    @Column(nullable = false)
    private Boolean incluyeMenores;

    // --- Información de Viaje ---
    @Column(nullable = false)
    private String tipoDocumento;

    @Column(nullable = false)
    private String numeroDocumento; // Reemplaza al antiguo documentoDeclarante

    @Column(nullable = false)
    private String paisProcedencia;

    @Column(nullable = false)
    private String tipoControl; // Ej: AEREO, MARITIMO, TERRESTRE

    @Column(nullable = false)
    private String nombreControl;

    @Column(nullable = false)
    private String medioTransporte;

    @Column(nullable = false)
    private LocalDate fechaLlegada; // LocalDate es ideal para los inputs type="date"

    // --- Declaración Jurada ---
    @Column(nullable = false)
    private Boolean traeProductosOrigenAnimalVegetal;

    @Column(nullable = false)
    private Boolean traeMercanciasNoEquipaje;

    @Column(nullable = false)
    private Boolean traeMas10000Dolares;

    // --- Control Interno y Fiscalización (Gestión exclusiva del Backend) ---
    // Ej: "PENDIENTE", "APROBADO", "RETENIDO_PARA_INSPECCION"
    @Column(nullable = false)
    private String estadoFiscalizacion = "PENDIENTE";

    @Column(nullable = false)
    private LocalDate fechaDeclaracion;

    private String patenteVehiculoAsociado; // Recuerda agregarla también al formulario Vue si es terrestre
    private String observaciones; // Para guardar lo que vio el inspector

    // --- Método Automático ---
    // Esto llena la fecha de declaración automáticamente en el momento que se guarda en la BD
    @PrePersist
    protected void onCreate() {
        this.fechaDeclaracion = LocalDate.now();
    }
    // --- REGLAS DE NEGOCIO ENCAPSULADAS ---

    /**
     * Verifica si la declaración está lista para ser aprobada automáticamente,
     * o si requiere que el inspector SAG vaya físicamente a revisar el maletero.
     */
    // --- Lógica de Negocio Transaccional ---

    @Transient
    public boolean requiereInspeccionFisica() {
        // 1. Riesgo Fitosanitario (Competencia directa del SAG)
        // Si trae frutas, semillas, quesos, carnes, etc., requiere revisión de equipaje obligatoria.
        if (Boolean.TRUE.equals(this.traeProductosOrigenAnimalVegetal)) {
            return true;
        }

        // 2. Riesgo Aduanero (Competencia de Aduanas, pero usualmente procesado en la misma fila)
        // Si trae mercancías comerciales o exceso de dinero, pasa a revisión física/documental.
        if (Boolean.TRUE.equals(this.traeMercanciasNoEquipaje) ||
                Boolean.TRUE.equals(this.traeMas10000Dolares)) {
            return true;
        }

        // Si todas las respuestas en la declaración son "No" (false),
        // el pasajero tiene "Luz Verde" y no requiere inspección.
        return false;
    }
    // Getters y Setters...
}