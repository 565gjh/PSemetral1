package com.example.MsSimulador.service;

import com.example.MsSimulador.model.EncargoPolicial;
import com.example.MsSimulador.repository.EncargoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class SimulacionService {
    @Autowired
    private final EncargoRepository encargoRepository;

    // Inyección del repositorio de Carabineros
    public SimulacionService(EncargoRepository encargoRepository) {
        this.encargoRepository = encargoRepository;
    }

    /**
     * LÓGICA SIMULADA PARA CARABINEROS DE CHILE
     * Busca en la base de datos H2 si la patente tiene un encargo por robo.
     */
    public boolean verificarEncargoRobo(String patente) {
        if (patente == null || patente.isEmpty()) {
            return false;
        }

        Optional<EncargoPolicial> encargo = encargoRepository.findById(patente.toUpperCase());
        // Si existe el registro en la BD, significa que SÍ tiene encargo por robo
        return encargo.isPresent();
    }

    /**
     * LÓGICA SIMULADA PARA LA AFIP (Argentina)
     * En lugar de crear otra tabla, aplicamos una regla de negocio simulada:
     * El folio será válido si empieza con "AFIP-" seguido de números (Ej: AFIP-12345).
     * Si viene vacío o no cumple el formato, se asume inválido o falso.
     */
    public boolean validarFolioAfip(String folio) {
        if (folio == null || folio.isEmpty()) {
            return false;
        }

        // Expresión regular: Debe empezar con AFIP- y terminar con uno o más números
        return folio.matches("^AFIP-\\d+$");
    }
}