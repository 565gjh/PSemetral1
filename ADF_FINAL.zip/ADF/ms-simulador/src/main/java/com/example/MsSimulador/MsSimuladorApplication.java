package com.example.MsSimulador;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MsSimuladorApplication {

	public static void main(String[] args) {
		SpringApplication.run(MsSimuladorApplication.class, args);
	}

}
