package com.example.MsSimulador.controller;

import com.example.MsSimulador.service.SimulacionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;


@RestController
@RequestMapping("/api/v1/afip")
public class AfipMockController {
    @Autowired
    private final SimulacionService simulacionService;

    public AfipMockController(SimulacionService simulacionService) {
        this.simulacionService = simulacionService;
    }

    @GetMapping("/validar-folio")
    public ResponseEntity<Boolean> verificarFolio(@RequestParam String folio) {
        // El servicio aplica la regla del formato "AFIP-XXXX"
        boolean esValido = simulacionService.validarFolioAfip(folio);
        return ResponseEntity.ok(esValido);
    }
}