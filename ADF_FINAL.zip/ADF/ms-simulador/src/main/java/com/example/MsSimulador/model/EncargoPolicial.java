package com.example.MsSimulador.model;


import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.Data;

@Data
@Entity
public class EncargoPolicial {

    @Id
    private String patente;
    private String motivo;
    private String fechaEncargo;

    public EncargoPolicial() {}

    public EncargoPolicial(String patente, String motivo, String fechaEncargo) {
        this.patente = patente;
        this.motivo = motivo;
        this.fechaEncargo = fechaEncargo;
    }

    // Getters y Setters...
}