package com.example.MsSimulador.repository;


import com.example.MsSimulador.model.EncargoPolicial;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface EncargoRepository extends JpaRepository<EncargoPolicial, String> {
}
