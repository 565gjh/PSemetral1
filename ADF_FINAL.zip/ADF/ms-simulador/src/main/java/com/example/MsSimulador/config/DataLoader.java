package com.example.MsSimulador.config;


import com.example.MsSimulador.model.EncargoPolicial;
import com.example.MsSimulador.repository.EncargoRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class DataLoader {

    @Bean
    CommandLineRunner iniciarDatos(EncargoRepository repository) {
        return args -> {
            // Insertamos patentes "robadas" para hacer pruebas
            repository.save(new EncargoPolicial("AB123CD", "Robo con intimidación", "2026-05-10"));
            repository.save(new EncargoPolicial("XX999YY", "Hurto de vehículo", "2026-06-01"));

            System.out.println("Base de datos de Carabineros Simulada cargada con éxito.");
        };
    }
}