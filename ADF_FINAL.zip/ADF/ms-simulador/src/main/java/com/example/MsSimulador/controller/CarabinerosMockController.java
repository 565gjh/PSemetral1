package com.example.MsSimulador.controller;

import com.example.MsSimulador.model.EncargoPolicial;
import com.example.MsSimulador.repository.EncargoRepository;
import com.example.MsSimulador.service.SimulacionService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RequiredArgsConstructor
@RestController
@RequestMapping("/api/v1/carabineros")
public class CarabinerosMockController {
    @Autowired
    private final SimulacionService simulacionService;



    @GetMapping("/encargo")
    public ResponseEntity<Boolean> consultarEncargo(@RequestParam String patente) {
        // El servicio nos dice si es robado o no (true/false)
        boolean tieneEncargo = simulacionService.verificarEncargoRobo(patente);
        return ResponseEntity.ok(tieneEncargo);
    }
}
