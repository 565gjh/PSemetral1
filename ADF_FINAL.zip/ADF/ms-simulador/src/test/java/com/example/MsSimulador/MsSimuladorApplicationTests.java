package com.example.MsSimulador;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsSimuladorApplicationTests {

	@Test
	void contextLoads() {
	}

}
