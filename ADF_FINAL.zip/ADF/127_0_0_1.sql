-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 07-07-2026 a las 17:29:38
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `adf_fiscalizacion`
--
CREATE DATABASE IF NOT EXISTS `adf_fiscalizacion` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `adf_fiscalizacion`;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `declaraciones_sag`
--

CREATE TABLE `declaraciones_sag` (
  `id` bigint(20) NOT NULL,
  `correo` varchar(255) NOT NULL,
  `estado_fiscalizacion` varchar(255) NOT NULL,
  `fecha_declaracion` date NOT NULL,
  `fecha_llegada` date NOT NULL,
  `genero` varchar(1) NOT NULL,
  `incluye_menores` bit(1) NOT NULL,
  `medio_transporte` varchar(255) NOT NULL,
  `nombre_completo` varchar(255) NOT NULL,
  `nombre_control` varchar(255) NOT NULL,
  `numero_documento` varchar(255) NOT NULL,
  `observaciones` varchar(255) DEFAULT NULL,
  `pais_procedencia` varchar(255) NOT NULL,
  `patente_vehiculo_asociado` varchar(255) DEFAULT NULL,
  `tipo_control` varchar(255) NOT NULL,
  `tipo_documento` varchar(255) NOT NULL,
  `trae_mas10000_dolares` bit(1) NOT NULL,
  `trae_mercancias_no_equipaje` bit(1) NOT NULL,
  `trae_productos_origen_animal_vegetal` bit(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `declaraciones_sag`
--

INSERT INTO `declaraciones_sag` (`id`, `correo`, `estado_fiscalizacion`, `fecha_declaracion`, `fecha_llegada`, `genero`, `incluye_menores`, `medio_transporte`, `nombre_completo`, `nombre_control`, `numero_documento`, `observaciones`, `pais_procedencia`, `patente_vehiculo_asociado`, `tipo_control`, `tipo_documento`, `trae_mas10000_dolares`, `trae_mercancias_no_equipaje`, `trae_productos_origen_animal_vegetal`) VALUES
(3, 'Juan@gmail.com', 'APROBADO_AUTOMATICO', '2026-07-07', '2026-09-13', 'M', b'0', 'auto', 'Juan Perez', 'Complejo Los Libertadores', '12345678-9', NULL, 'Argentina', NULL, 'TERRESTRE', 'DNI', b'0', b'0', b'0'),
(4, 'juan@gmail.com', 'APROBADO_AUTOMATICO', '2026-07-07', '2026-12-12', 'M', b'0', 'auto', 'Juan Perez', 'Complejo Los Libertadores', '12345678-9', NULL, 'Argentina', NULL, 'TERRESTRE', 'DNI', b'0', b'0', b'0');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `declaraciones_sag`
--
ALTER TABLE `declaraciones_sag`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `declaraciones_sag`
--
ALTER TABLE `declaraciones_sag`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- Base de datos: `adf_identidad`
--
CREATE DATABASE IF NOT EXISTS `adf_identidad` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `adf_identidad`;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `flyway_schema_history`
--

CREATE TABLE `flyway_schema_history` (
  `installed_rank` int(11) NOT NULL,
  `version` varchar(50) DEFAULT NULL,
  `description` varchar(200) NOT NULL,
  `type` varchar(20) NOT NULL,
  `script` varchar(1000) NOT NULL,
  `checksum` int(11) DEFAULT NULL,
  `installed_by` varchar(100) NOT NULL,
  `installed_on` timestamp NOT NULL DEFAULT current_timestamp(),
  `execution_time` int(11) NOT NULL,
  `success` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios_sna`
--

CREATE TABLE `usuarios_sna` (
  `tipo_usuario` varchar(31) NOT NULL,
  `id` bigint(20) NOT NULL,
  `celular` varchar(255) NOT NULL,
  `correo` varchar(255) NOT NULL,
  `nombre_completo` varchar(255) NOT NULL,
  `password_cifrada` varchar(255) NOT NULL,
  `rut` varchar(12) NOT NULL,
  `departamento` varchar(255) DEFAULT NULL,
  `numero_placa` varchar(255) DEFAULT NULL,
  `rango_institucional` varchar(255) DEFAULT NULL,
  `zona_inspeccion` varchar(255) DEFAULT NULL,
  `nacionalidad` varchar(255) DEFAULT NULL
) ;

--
-- Volcado de datos para la tabla `usuarios_sna`
--

INSERT INTO `usuarios_sna` (`tipo_usuario`, `id`, `celular`, `correo`, `nombre_completo`, `password_cifrada`, `rut`, `departamento`, `numero_placa`, `rango_institucional`, `zona_inspeccion`, `nacionalidad`) VALUES
('PASAJERO', 4, '111111111', 'topo@gmail.com', 'juanito topo', '$2a$10$1I1Z3hga8Jl6S7OwsW6HJup4.cFUmYRCiflans/DeWMRo7hcQUyuS', '88888888-8', NULL, NULL, NULL, NULL, 'Chilena'),
('PASAJERO', 5, '112233445', 'epstein@gmail.com', 'epstein', '$2a$10$FUrb22FN9zfW4TyU4SBfMOXPN2CuQmrIeNvWVy.qBNb0IP08mKUGG', '12345678-9', NULL, NULL, NULL, NULL, 'Chilena'),
('ADMIN_TI', 6, '986583590', 'benja@gmail.com', 'BENJAMIN', '$2a$10$RMs68ErLIIRtEuM7nEyu/uOCtbo/zQIW9RhzhhAIgqkTiBjUfavwu', '21076914-5', 'Informatica', NULL, NULL, NULL, NULL),
('ADUANA_OPE', 8, '998534673', 'adela@gmail.com', 'Adela thomas', '$2a$10$ya8B8I3zGt4IwNvYGC40XOFnQJ7fpAYuAv57idt7/RlgVGGWJ5EPm', '13369113-8', NULL, '12345', NULL, NULL, NULL),
('SAG_OPE', 9, '999999999', 'felipe@gmail.com', 'felipe solis', '$2a$10$s.W6RKmeK5rbC8e0ZhVn8Oz1FFaFq28p9QxGVtkplovmmUufN94iu', '19143162-6', NULL, NULL, 'INSPECTOR', NULL, NULL),
('PDI_OPE', 10, '999999999', 'Eloy@gmail.com', 'Eloy solis', '$2a$10$aQ47P7KonMuxEeEOqkXxH.4Fjx1m0G50B/2AtgswSawlsgIZSwVJ2', '13768308-3', NULL, NULL, NULL, NULL, NULL),
('PASAJERO', 15, '121212121', 'esteban@gmail.com', 'Esteban Guzman', '$2a$10$OxUCFHbvFwvFd47XfTXyHuqfNl6HX3qoXxE4IaOjFi1KYjNPM28t.', '12121212-3', NULL, NULL, NULL, NULL, 'chilena');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `flyway_schema_history`
--
ALTER TABLE `flyway_schema_history`
  ADD PRIMARY KEY (`installed_rank`),
  ADD KEY `flyway_schema_history_s_idx` (`success`);

--
-- Indices de la tabla `usuarios_sna`
--
ALTER TABLE `usuarios_sna`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `UKkyxwqognyvgywu5f1obxqp7vq` (`rut`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `usuarios_sna`
--
ALTER TABLE `usuarios_sna`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- Base de datos: `adf_registromigracion`
--
CREATE DATABASE IF NOT EXISTS `adf_registromigracion` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `adf_registromigracion`;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `registros_migratorios`
--

CREATE TABLE `registros_migratorios` (
  `id` bigint(20) NOT NULL,
  `documento_identidad` varchar(20) NOT NULL,
  `estado` varchar(255) NOT NULL,
  `fecha_nacimiento` date NOT NULL,
  `fecha_registro` date NOT NULL,
  `folio_juzgado_familia` varchar(255) DEFAULT NULL,
  `folio_permiso_notarial` varchar(255) DEFAULT NULL,
  `hora_ingreso` varchar(255) NOT NULL,
  `nacionalidad` varchar(255) NOT NULL,
  `nombres_completos` varchar(255) NOT NULL,
  `patente_vehiculo_asociado` varchar(10) NOT NULL,
  `viaja_con_ambos_padres` bit(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `registros_migratorios`
--

INSERT INTO `registros_migratorios` (`id`, `documento_identidad`, `estado`, `fecha_nacimiento`, `fecha_registro`, `folio_juzgado_familia`, `folio_permiso_notarial`, `hora_ingreso`, `nacionalidad`, `nombres_completos`, `patente_vehiculo_asociado`, `viaja_con_ambos_padres`) VALUES
(1, '21186549-0', 'PENDIENTE', '2002-11-18', '2026-07-06', NULL, NULL, '1:46:22', 'CHILENA', 'Alexis Hernandez', 'AF2312', b'0');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `registros_migratorios`
--
ALTER TABLE `registros_migratorios`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `registros_migratorios`
--
ALTER TABLE `registros_migratorios`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- Base de datos: `adf_vehiculo`
--
CREATE DATABASE IF NOT EXISTS `adf_vehiculo` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `adf_vehiculo`;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `vehiculos`
--

CREATE TABLE `vehiculos` (
  `id` bigint(20) NOT NULL,
  `documento_conductor` varchar(255) DEFAULT NULL,
  `estado` varchar(255) DEFAULT NULL,
  `fecha_ingreso_temporal` date DEFAULT NULL,
  `fecha_vencimiento_temporal` date DEFAULT NULL,
  `folio_afip` varchar(255) DEFAULT NULL,
  `marca` varchar(255) DEFAULT NULL,
  `modelo` varchar(255) DEFAULT NULL,
  `pais_origen` varchar(255) NOT NULL,
  `patente` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `vehiculos`
--

INSERT INTO `vehiculos` (`id`, `documento_conductor`, `estado`, `fecha_ingreso_temporal`, `fecha_vencimiento_temporal`, `folio_afip`, `marca`, `modelo`, `pais_origen`, `patente`) VALUES
(1, '19876543-2', 'RETENIDO', NULL, NULL, NULL, 'Toyota', 'Yaris', 'CHILE', 'AB123CD'),
(9, '12345678-9', 'ACTIVO', '2026-07-01', '2026-12-28', NULL, 'Chevrolet', 'Spark', 'CHILE', 'OK123OK');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `vehiculos`
--
ALTER TABLE `vehiculos`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `UKkxt53tfqxxydvqll7ldil6qu7` (`patente`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `vehiculos`
--
ALTER TABLE `vehiculos`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
