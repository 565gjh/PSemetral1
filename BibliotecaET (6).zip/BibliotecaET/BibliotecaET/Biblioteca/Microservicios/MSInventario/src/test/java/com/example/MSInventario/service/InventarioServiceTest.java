package com.example.MSInventario.service;

import com.example.MSInventario.model.Inventario;
import com.example.MSInventario.model.InventarioDTO;
import com.example.MSInventario.repository.InventarioRepository;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Optional;

import static org.mockito.ArgumentMatchers.any;

@ExtendWith(MockitoExtension.class)
public class InventarioServiceTest {

    @Mock
    private InventarioRepository inventarioRepository;

    @InjectMocks
    private InventarioService inventarioService;

    @Test
    void cuandoObtenerInventarioPorLibroYExiste_entoncesRetornaDtoCorrecto() {
        // GIVEN
        Long idLibro = 10L;
        Inventario inventarioMock = new Inventario();
        inventarioMock.setLibroId(idLibro);
        inventarioMock.setCantidadDisponible(15);

        Mockito.when(inventarioRepository.findByLibroId(idLibro))
                .thenReturn(Optional.of(inventarioMock));

        // WHEN
        InventarioDTO resultado = inventarioService.obtenerInventarioPorLibro(idLibro);

        // THEN
        Assertions.assertNotNull(resultado);
        Assertions.assertEquals(idLibro, resultado.getIdLibro());
        Assertions.assertEquals(15, resultado.getCantidadDisponible());
        Mockito.verify(inventarioRepository, Mockito.times(1)).findByLibroId(idLibro);
    }

    @Test
    void cuandoDescontarStockLibroExitosamente_entoncesRestaUnaUnidadYSalva() {
        // GIVEN
        Long idLibro = 1L;
        Inventario inventarioMock = new Inventario();
        inventarioMock.setLibroId(idLibro);
        inventarioMock.setCantidadDisponible(5); // Stock inicial

        Mockito.when(inventarioRepository.findByLibroId(idLibro))
                .thenReturn(Optional.of(inventarioMock));

        Mockito.when(inventarioRepository.save(any(Inventario.class)))
                .thenAnswer(invocation -> invocation.getArguments()[0]);

        // WHEN
        inventarioService.descontarStockLibro(idLibro);

        // THEN
        // Verificamos que el stock interno bajó a 4 (5 - 1 = 4)
        Assertions.assertEquals(4, inventarioMock.getCantidadDisponible());
        Mockito.verify(inventarioRepository, Mockito.times(1)).save(any(Inventario.class));
    }

    @Test
    void cuandoDescontarStockYCantidadEsCero_entoncesLanzaRuntimeException() {
        // GIVEN
        Long idLibro = 2L;
        Inventario inventarioMock = new Inventario();
        inventarioMock.setLibroId(idLibro);
        inventarioMock.setCantidadDisponible(0); // Agotado

        Mockito.when(inventarioRepository.findByLibroId(idLibro))
                .thenReturn(Optional.of(inventarioMock));

        // WHEN & THEN
        RuntimeException excepcion = Assertions.assertThrows(RuntimeException.class, () -> {
            inventarioService.descontarStockLibro(idLibro);
        });

        Assertions.assertEquals("No se puede descontar. El stock disponible ya está agotado.", excepcion.getMessage());
        // Nos aseguramos de que NUNCA intentó guardar en la base de datos ya que falló la validación
        Mockito.verify(inventarioRepository, Mockito.never()).save(any(Inventario.class));
    }
}