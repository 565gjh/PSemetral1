package com.example.MSInventario.controller;


import com.example.MSInventario.model.InventarioDTO;
import com.example.MSInventario.service.InventarioService;
import io.swagger.v3.oas.annotations.Operation;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/v1/inventario")
@Slf4j
public class InventarioController {

    @Autowired
    private InventarioService inventarioService;

    @GetMapping
    @PreAuthorize("hasAnyRole('ADMIN', 'TRABAJADOR')")
    public ResponseEntity<List<InventarioDTO>> findAll() {
        log.info("Obteniendo todo el inventario");
        return ResponseEntity.ok(inventarioService.obtenerTodos());
    }
    @Operation(summary = "Obtener stock disponible", description = "Retorna la cantidad física de unidades disponibles en bodega para un ID de libro específico")
    @GetMapping("/{idLibro}")
    @PreAuthorize("hasAnyRole('ADMIN', 'USUARIO', 'TRABAJADOR')")
    public ResponseEntity<InventarioDTO> findByIdLibro(@PathVariable Long idLibro) {
        log.info("Consultando stock para el libro ID: {}", idLibro);
        InventarioDTO inventarioDTO = inventarioService.obtenerInventarioPorLibro(idLibro);
        return ResponseEntity.ok(inventarioDTO);
    }

    @PostMapping
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<InventarioDTO> save(@Valid @RequestBody InventarioDTO inventarioDTO) {
        log.info("Guardando/Actualizando stock para el libro ID: {}", inventarioDTO.getIdLibro());
        InventarioDTO guardado = inventarioService.guardar(inventarioDTO);
        return new ResponseEntity<>(guardado, HttpStatus.CREATED);
    }
    @Operation(summary = "Descontar unidades del inventario", description = "Disminuye el stock disponible tras confirmarse un préstamo o reserva exitosa")
    @PutMapping("/{id}/descontar")
    public ResponseEntity<?> descontarStock(@PathVariable Long id) {
        log.info("📥 [InventarioController] Petición recibida para descontar stock del libro ID: {}", id);
        try {
            // Llamamos al servicio de inventario para que reste la unidad
            inventarioService.descontarStockLibro(id);

            // Retornamos un 200 OK vacío tal como lo espera el WebClient (toBodilessEntity)
            return ResponseEntity.ok().build();
        } catch (RuntimeException e) {
            log.error("❌ [InventarioController] Error al descontar stock para libro ID {}: {}", id, e.getMessage());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(Map.of("error", e.getMessage()));
        }
    }


}