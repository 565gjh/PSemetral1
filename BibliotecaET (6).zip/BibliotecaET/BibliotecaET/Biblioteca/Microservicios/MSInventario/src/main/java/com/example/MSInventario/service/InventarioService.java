package com.example.MSInventario.service;


import com.example.MSInventario.model.Inventario;
import com.example.MSInventario.model.InventarioDTO;
import com.example.MSInventario.repository.InventarioRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;
@Slf4j
@Service
public class InventarioService {

    @Autowired
    private InventarioRepository inventarioRepository;


    public List<InventarioDTO> obtenerTodos() {
        return inventarioRepository.findAll().stream()
                .map(this::mapearADto)
                .collect(Collectors.toList());
    }


    public InventarioDTO obtenerInventarioPorLibro(Long idLibro) {
        Inventario inventario = inventarioRepository.findByLibroId(idLibro)
                .orElseGet(() -> {
                    Inventario invVacio = new Inventario();
                    invVacio.setLibroId(idLibro);
                    invVacio.setCantidadDisponible(0);
                    return invVacio;
                });

        return mapearADto(inventario);
    }


    public InventarioDTO guardar(InventarioDTO dto) {
        // Buscamos si ya existe un registro para ese idLibro, si no, creamos una nueva Entidad
        Inventario inventario = inventarioRepository.findByLibroId(dto.getIdLibro())
                .orElse(new Inventario());

        inventario.setLibroId(dto.getIdLibro());
        inventario.setCantidadDisponible(dto.getCantidadDisponible());

        Inventario guardado = inventarioRepository.save(inventario);
        return mapearADto(guardado);
    }

    @Transactional
    public void descontarStockLibro(Long idLibro) {
        log.info("🔹 [InventarioService] Iniciando descuento de stock para el libro ID: {}", idLibro);

        // 1. Buscar el registro de inventario real (no creamos uno vacío porque vamos a restar)
        Inventario inventario = inventarioRepository.findByLibroId(idLibro)
                .orElseThrow(() -> new RuntimeException("No existe un registro de inventario para el libro ID: " + idLibro));

        // 2. Validar que físicamente queden libros antes de restar
        if (inventario.getCantidadDisponible() <= 0) {
            log.error("❌ [InventarioService] Operación rechazada. El stock ya es cero para el libro ID: {}", idLibro);
            throw new RuntimeException("No se puede descontar. El stock disponible ya está agotado.");
        }

        // 3. Restar la unidad y guardar
        int nuevoStock = inventario.getCantidadDisponible() - 1;
        inventario.setCantidadDisponible(nuevoStock);
        inventarioRepository.save(inventario);

        log.info("✅ [InventarioService] Stock descontado con éxito. Nuevo stock disponible para libro ID {}: {}", idLibro, nuevoStock);
    }



    private InventarioDTO mapearADto(Inventario inventario) {
        InventarioDTO dto = new InventarioDTO();
        dto.setIdLibro(inventario.getLibroId());
        dto.setCantidadDisponible(inventario.getCantidadDisponible());
        return dto;
    }


}