package com.example.MSInventario.config;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
@EnableAutoConfiguration(exclude = {
        org.springdoc.core.configuration.SpringDocHateoasConfiguration.class})
public class SwaggerConfig {

    @Bean
    public OpenAPI customOpenAPI() {
        return new OpenAPI()
                .info(new Info()
                        .title("MSInventario API - Control de Existencias")
                        .version("1.0")
                        .description("Control físico de copias disponibles, pasillos, estanterías y estado de los libros en stock.")
                );
    }
}