package com.example.MSInventario.model;

import lombok.Data;

@Data
public class InventarioDTO {
    private Long idLibro;
    private int cantidadDisponible;
}