package com.example.MSInventario.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.LocalDateTime;

@Entity
@Table(name = "inventario")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Inventario {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "libro_id", nullable = false)
    private Long libroId; // ID lógico que conecta con MSCatalogo

    @Column(name = "cantidad_disponible", nullable = false)
    @Min(value = 0, message = "El stock disponible no puede ser un número negativo")
    private int cantidadDisponible;}