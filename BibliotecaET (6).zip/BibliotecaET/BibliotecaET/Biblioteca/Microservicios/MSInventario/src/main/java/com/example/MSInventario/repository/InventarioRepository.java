package com.example.MSInventario.repository;


import com.example.MSInventario.model.Inventario;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface InventarioRepository extends JpaRepository<Inventario, Long> {

    /**
     * Spring Data JPA analiza el nombre de este método y genera automáticamente la consulta:
     * SELECT * FROM inventarios WHERE id_libro = ?
     */

    Optional<Inventario> findByLibroId(Long libroId);
    // NOTA: Métodos como save(), findAll(), y delete()
    // no necesitan declararse aquí porque ya vienen heredados de JpaRepository.
}
