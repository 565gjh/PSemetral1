package com.example.MSusuario.service;

import com.example.MSusuario.model.RegistroUsuarioDTO;
import com.example.MSusuario.model.Usuario;
import com.example.MSusuario.repository.usuarioRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
@Service
@Slf4j
public class usuarioService {
    @Autowired
    private usuarioRepository repository;


    public List<Usuario> findAll() {
        log.info("Obteniendo lista de todos los usuarios.");
        return repository.findAll();
    }

    public Usuario findById(Long id) {
        log.info("buscando usuario por id.");
        return repository.findById(id).get();
    }


    public Optional<Usuario> findByEmail(String email) {
        log.info("buscando usuario por email.");
        return repository.findByEmail(email);
    }
    public void guardarPerfil(RegistroUsuarioDTO dto) {

        // Mapeamos los datos del DTO a la Entidad JPA de ms-usuarios
        Usuario usuario = new Usuario();

        // ¡ESTE ES EL NEXO MÁS IMPORTANTE DEL SISTEMA!
        usuario.setIdAuth(dto.getAuthId());

        usuario.setNombre1(dto.getNombre1());
        usuario.setApellido1(dto.getApellido1());
        usuario.setEmail(dto.getEmail());
        usuario.setRol(dto.getTipoUsuario());

        // Guardamos en la base de datos de perfiles
        repository.save(usuario);
    }

    // 🌟 AGREGAR ESTO AL FINAL DE LA CLASE usuarioService
    public List<Usuario> findByApellido1(String apellido1) {
        log.info("Buscando usuarios con el apellido paterno: {}", apellido1);
        return repository.findByApellido1(apellido1);
    }
}