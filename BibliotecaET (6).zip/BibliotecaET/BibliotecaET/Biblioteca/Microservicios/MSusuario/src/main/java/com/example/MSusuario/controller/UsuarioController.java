package com.example.MSusuario.controller;

import com.example.MSusuario.model.RegistroUsuarioDTO;
import com.example.MSusuario.client.AuthClient;
import com.example.MSusuario.model.Usuario;
import com.example.MSusuario.service.usuarioService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PostFilter;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

// 1. 👈 NUEVOS IMPORTS ADICIONADOS (HATEOAS & Swagger)
import org.springframework.hateoas.EntityModel;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;

// 2. 👈 NUEVO: Etiqueta de Swagger asignada a la clase
@Tag(name = "Usuarios", description = "Gestión de perfiles de usuario")
@RestController
@RequestMapping("/api/v1/usuarios")
@RequiredArgsConstructor
public class UsuarioController {

    @Autowired
    private usuarioService service;

    @GetMapping
    @PreAuthorize("hasAnyRole('ADMIN', 'TRABAJADOR')")
    public List<Usuario> findAll() {
        return service.findAll();
    }

    // 🌟 AGREGAR ESTO EN TU UsuarioController
    @Operation(summary = "Obtener usuarios por apellido paterno", description = "Retorna una lista de perfiles que coincidan con el apellido indicado")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Búsqueda procesada con éxito"),
            @ApiResponse(responseCode = "403", description = "Acceso denegado")
    })
    @GetMapping("/apellido/{apellido}")
    @PreAuthorize("hasAnyRole('ADMIN', 'TRABAJADOR')")
    public ResponseEntity<List<Usuario>> findByApellido(
            @Parameter(description = "Primer apellido del usuario", example = "Solis")
            @PathVariable String apellido) {

        List<Usuario> usuarios = service.findByApellido1(apellido);
        return ResponseEntity.ok(usuarios);
    }

    // 3. 👈 REEMPLAZADO: El método findById ahora soporta documentación Swagger y HATEOAS
    @Operation(summary = "Obtener usuario por ID", description = "Retorna el usuario con enlace HATEOAS self")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Usuario encontrado",
                    content = @Content(schema = @Schema(implementation = Usuario.class))),
            @ApiResponse(responseCode = "404", description = "No encontrado", content = @Content),
            @ApiResponse(responseCode = "403", description = "Sin permiso",   content = @Content)
    })
    @GetMapping("/id/{id}")
    @PreAuthorize("hasAnyRole('ADMIN', 'TRABAJADOR')")
    public ResponseEntity<EntityModel<Usuario>> findById(
            @Parameter(description = "ID del usuario", example = "1")
            @PathVariable Long id) {

        Usuario usuario = service.findById(id); // Tu lógica original sin tocar

        // Se envuelve el objeto usuario y se le asocia el link auto-referenciado de HATEOAS
        EntityModel<Usuario> recurso = EntityModel.of(usuario,
                linkTo(methodOn(UsuarioController.class).findById(id)).withSelfRel()
        );
        return ResponseEntity.ok(recurso);
    }

    @PostMapping
    public ResponseEntity<Void> recibirNuevoUsuario(@RequestBody RegistroUsuarioDTO perfil) {
        service.guardarPerfil(perfil);
        return ResponseEntity.status(HttpStatus.CREATED).build();
    }

    public ResponseEntity<Optional<Usuario>> findByEmail(@PathVariable String email) {
        return ResponseEntity.ok(service.findByEmail(email));
    }
}