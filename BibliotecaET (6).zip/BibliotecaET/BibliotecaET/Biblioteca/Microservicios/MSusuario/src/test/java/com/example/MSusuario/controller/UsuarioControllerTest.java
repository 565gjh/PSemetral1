package com.example.MSusuario.controller;

import com.example.MSusuario.model.RegistroUsuarioDTO;
import com.example.MSusuario.model.Usuario;
import com.example.MSusuario.service.usuarioService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.webmvc.test.autoconfigure.WebMvcTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;
import java.util.Arrays;
import java.util.NoSuchElementException;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(UsuarioController.class)
public class UsuarioControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockitoBean
    private usuarioService service;

    @Autowired
    private ObjectMapper objectMapper;

    @Test
    public void cuandoObtenerPorIdExistente_deberiaRetornarStatus200() throws Exception {
        Usuario usuarioFake = Usuario.builder()
                .id(1L)
                .nombre1("Juan")
                .apellido1("Perez")
                .email("juan@duocuc.cl")
                .rol("ESTUDIANTE")
                .build();

        Mockito.when(service.findById(1L)).thenReturn(usuarioFake);

        mockMvc.perform(get("/api/usuarios/1"))
                .andExpect(status().isOk())
                .andExpect(content().contentType(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$.id").value(1))
                .andExpect(jsonPath("$.nombre1").value("Juan"));
    }

    @Test
    public void cuandoObtenerPorIdInexistente_deberiaRetornarStatus404() throws Exception {
        Mockito.when(service.findById(99L)).thenThrow(new NoSuchElementException());

        mockMvc.perform(get("/api/usuarios/99"))
                .andExpect(status().isNotFound());
    }

    @Test
    public void cuandoCrearUsuario_deberiaRetornarStatus200() throws Exception {
        // GIVEN: Preparamos el DTO tal como lo espera tu método guardarPerfil
        RegistroUsuarioDTO dtoFake = new RegistroUsuarioDTO();
        dtoFake.setAuthId(100L);
        dtoFake.setNombre1("Maria");
        dtoFake.setApellido1("Concha");
        dtoFake.setEmail("maria@duocuc.cl");
        dtoFake.setTipoUsuario("DOCENTE");

        // Como el método del servicio es void, usamos Mockito.doNothing()
        Mockito.doNothing().when(service).guardarPerfil(Mockito.any(RegistroUsuarioDTO.class));

        // WHEN & THEN: Hacemos el POST enviando el DTO
        mockMvc.perform(post("/api/usuarios")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(dtoFake)))
                .andExpect(status().isOk());

        // Verificamos que el controlador efectivamente llamó al servicio con el DTO
        Mockito.verify(service, Mockito.times(1)).guardarPerfil(Mockito.any(RegistroUsuarioDTO.class));
    }

    @Test
    public void cuandoObtenerTodos_deberiaRetornarListaYStatus200() throws Exception {
        Usuario u1 = Usuario.builder().id(1L).nombre1("Juan").build();
        Usuario u2 = Usuario.builder().id(2L).nombre1("Maria").build();

        Mockito.when(service.findAll()).thenReturn(Arrays.asList(u1, u2));

        mockMvc.perform(get("/api/usuarios"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.length()").value(2))
                .andExpect(jsonPath("$[0].nombre1").value("Juan"));
    }
}