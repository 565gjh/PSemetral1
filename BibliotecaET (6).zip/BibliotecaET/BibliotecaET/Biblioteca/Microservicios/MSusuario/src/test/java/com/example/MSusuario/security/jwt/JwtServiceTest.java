package com.example.MSusuario.security.jwt;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.lang.reflect.Field;
import java.util.Date;
import javax.crypto.SecretKey;

import static org.junit.jupiter.api.Assertions.*;

public class JwtServiceTest {

    private JwtService jwtService;
    private final String claveFalsa = "ClaveSecretaSuperSeguraParaLosTokensJWT2026";

    @BeforeEach
    void setUp() throws Exception {
        jwtService = new JwtService();

        // 🧠 TRUCO DE REFLEXIÓN: Inyectamos manualmente el String en el campo privado 'secretKey'
        Field field = JwtService.class.getDeclaredField("secretKey");
        field.setAccessible(true);
        field.set(jwtService, claveFalsa);
    }

    // 🔒 Método auxiliar para generar tokens válidos en los tests
    private String generarTokenDePrueba(String subject, String rol, long duracionMs) {
        SecretKey key = Keys.hmacShaKeyFor(claveFalsa.getBytes());
        return Jwts.builder()
                .subject(subject)
                .claim("rol", rol)
                .issuedAt(new Date())
                .expiration(new Date(System.currentTimeMillis() + duracionMs))
                .signWith(key)
                .compact();
    }

    @Test
    void cuandoTokenEsValido_extractUsername_deberiaRetornarUsuario() {
        String token = generarTokenDePrueba("profesor@duocuc.cl", "ADMIN", 60000);

        String username = jwtService.extractUsername(token);

        assertEquals("profesor@duocuc.cl", username);
    }

    @Test
    void cuandoTokenEsInvalido_extractUsername_deberiaRetornarNull() {
        String tokenInvalido = "un.token.malformado";

        String username = jwtService.extractUsername(tokenInvalido);

        assertNull(username);
    }

    @Test
    void cuandoTokenContieneRol_extractRole_deberiaRetornarRol() {
        String token = generarTokenDePrueba("alumno@duocuc.cl", "ESTUDIANTE", 60000);

        String rol = jwtService.extractRole(token);

        assertEquals("ESTUDIANTE", rol);
    }

    @Test
    void cuandoTokenEsInvalido_extractRole_deberiaRetornarNull() {
        String tokenInvalido = "un.token.malformado";

        String rol = jwtService.extractRole(tokenInvalido);

        assertNull(rol);
    }

    @Test
    void cuandoTokenEsVigente_isTokenValid_deberiaRetornarTrue() {
        String token = generarTokenDePrueba("user@test.cl", "USER", 60000);

        boolean esValido = jwtService.isTokenValid(token);

        assertTrue(esValido);
    }

    @Test
    void cuandoTokenEstaExpirado_isTokenValid_deberiaRetornarFalse() {
        // Generamos un token que ya expiró hace 10 minutos (-600000 ms)
        String tokenExpirado = generarTokenDePrueba("user@test.cl", "USER", -600000);

        boolean esValido = jwtService.isTokenValid(tokenExpirado);

        assertFalse(esValido);
    }
}