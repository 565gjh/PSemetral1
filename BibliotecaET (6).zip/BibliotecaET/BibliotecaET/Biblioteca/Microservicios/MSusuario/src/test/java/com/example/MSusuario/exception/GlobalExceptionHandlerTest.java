package com.example.MSusuario.exception;

import org.junit.jupiter.api.Test;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

public class GlobalExceptionHandlerTest {

    private final GlobalExceptionHandler handler = new GlobalExceptionHandler();

    @Test
    void cuandoManejarRuntimeException_deberiaRetornar404ConDetalles() {
        // GIVEN: Simulamos una excepción de tiempo de ejecución con un mensaje de negocio
        RuntimeException exception = new RuntimeException("El usuario con ID 99 no existe");

        // WHEN: Invocamos directamente al método del Handler
        ResponseEntity<Map<String, Object>> respuesta = handler.handleRuntimeException(exception);

        // THEN: Verificamos que el código de estado HTTP sea 404
        assertNotNull(respuesta);
        assertEquals(HttpStatus.NOT_FOUND, respuesta.getStatusCode());

        // Verificamos el contenido del JSON (Map) de respuesta
        Map<String, Object> body = respuesta.getBody();
        assertNotNull(body);
        assertEquals(HttpStatus.NOT_FOUND.value(), body.get("status"));
        assertEquals("Recurso no encontrado o error interno", body.get("error"));
        assertEquals("El usuario con ID 99 no existe", body.get("message"));
        assertNotNull(body.get("timestamp"));
    }

    @Test
    void cuandoManejarExceptionGenerica_deberiaRetornar500ConMensajeInesperado() {
        // GIVEN: Simulamos una falla grave o inesperada del sistema
        Exception exception = new Exception("Error de conexión a la base de datos");

        // WHEN: Invocamos el método genérico
        ResponseEntity<Map<String, Object>> respuesta = handler.handleGenericException(exception);

        // THEN: Verificamos que responda con un 500 Internal Server Error
        assertNotNull(respuesta);
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, respuesta.getStatusCode());

        // Verificamos las propiedades del mapa
        Map<String, Object> body = respuesta.getBody();
        assertNotNull(body);
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR.value(), body.get("status"));
        assertEquals("Internal Server Error", body.get("error"));
        assertEquals("Ocurrió un error inesperado en el servidor", body.get("message"));
        assertNotNull(body.get("timestamp"));
    }
}