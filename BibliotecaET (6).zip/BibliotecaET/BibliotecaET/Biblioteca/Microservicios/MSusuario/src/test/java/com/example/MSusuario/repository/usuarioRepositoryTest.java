package com.example.MSusuario.repository;

import com.example.MSusuario.model.Usuario;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface usuarioRepositoryTest extends JpaRepository<Usuario, Long> {
    // JpaRepository ya incluye el findById(Long id) que usa tu test
}