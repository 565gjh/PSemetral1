package com.example.MSusuario.service;

import com.example.MSusuario.model.Usuario;
import com.example.MSusuario.repository.usuarioRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
public class UsuarioServiceTest {

    @Mock
    private usuarioRepository repository;

    @InjectMocks
    private usuarioService service;

    @Test
    public void cuandoBuscarUsuarioExistente_deberiaRetornarUsuario() {
        // GIVEN: Creamos el usuario usando el Builder real de tu entidad
        Usuario usuarioFake = Usuario.builder()
                .id(1L)
                .idAuth(100L)
                .nombre1("Juan")
                .apellido1("Perez")
                .celular(912345678)
                .email("juan@duocuc.cl")
                .rol("ESTUDIANTE")
                .build();

        Mockito.when(repository.findById(1L)).thenReturn(Optional.of(usuarioFake));

        // WHEN
        Usuario resultado = service.findById(1L);

        // THEN
        assertNotNull(resultado);
        assertEquals(1L, resultado.getId());
        assertEquals("Juan", resultado.getNombre1());
        assertEquals("ESTUDIANTE", resultado.getRol());
    }

    @Test
    public void cuandoBuscarUsuarioInexistente_deberiaLanzarExcepcion() {
        // GIVEN
        Mockito.when(repository.findById(99L)).thenReturn(Optional.empty());

        // WHEN & THEN
        assertThrows(java.util.NoSuchElementException.class, () -> {
            service.findById(99L);
        });
    }

    @Test
    public void cuandoGuardarPerfil_deberiaEjecutarseCorrectamente() {
        com.example.MSusuario.model.RegistroUsuarioDTO dtoParaGuardar = new com.example.MSusuario.model.RegistroUsuarioDTO();
        dtoParaGuardar.setAuthId(100L);
        dtoParaGuardar.setNombre1("Maria");
        dtoParaGuardar.setApellido1("Concha");
        dtoParaGuardar.setEmail("maria@duocuc.cl");
        dtoParaGuardar.setTipoUsuario("DOCENTE");

        Mockito.when(repository.save(Mockito.any(com.example.MSusuario.model.Usuario.class)))
                .thenReturn(new com.example.MSusuario.model.Usuario());

        assertDoesNotThrow(() -> {
            service.guardarPerfil(dtoParaGuardar);
        }, "El método guardarPerfil no debería lanzar ninguna excepción");


        Mockito.verify(repository, Mockito.times(1)).save(Mockito.any(com.example.MSusuario.model.Usuario.class));
    }

    @Test
    public void cuandoBuscarTodos_deberiaRetornarListaDeUsuarios() {
        // GIVEN
        Usuario u1 = Usuario.builder().id(1L).nombre1("Juan").build();
        Usuario u2 = Usuario.builder().id(2L).nombre1("Maria").build();

        List<Usuario> listaFake = Arrays.asList(u1, u2);

        Mockito.when(repository.findAll()).thenReturn(listaFake);

        // WHEN
        List<Usuario> resultado = service.findAll();

        // THEN
        assertNotNull(resultado);
        assertEquals(2, resultado.size());
    }
}