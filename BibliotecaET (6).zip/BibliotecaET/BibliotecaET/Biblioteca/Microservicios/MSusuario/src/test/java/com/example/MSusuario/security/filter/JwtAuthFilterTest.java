package com.example.MSusuario.security.filter;

import com.example.MSusuario.security.jwt.JwtService;
import jakarta.servlet.FilterChain;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.core.context.SecurityContextHolder;

import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
public class JwtAuthFilterTest {

    @Mock
    private JwtService jwtService;

    @Mock
    private FilterChain filterChain;

    @Mock
    private HttpServletRequest request;

    @Mock
    private HttpServletResponse response;

    @InjectMocks
    private JwtAuthFilter jwtAuthFilter; // 👈 Nombre exacto de tu clase

    @BeforeEach
    @AfterEach
    void limpiarContexto() {
        SecurityContextHolder.clearContext();
    }

    @Test
    void cuandoPeticionEsDeSwagger_deberiaPasarDeLargoSinEvaluarToken() throws Exception {
        Mockito.when(request.getRequestURI()).thenReturn("/swagger-ui/index.html");

        jwtAuthFilter.doFilterInternal(request, response, filterChain);

        Mockito.verify(filterChain, Mockito.times(1)).doFilter(request, response);
        Mockito.verifyNoInteractions(jwtService);
    }

    @Test
    void cuandoNoExisteHeaderAuthorization_deberiaContinuarLaCadena() throws Exception {
        Mockito.when(request.getRequestURI()).thenReturn("/api/usuarios");
        Mockito.when(request.getHeader("Authorization")).thenReturn(null);

        jwtAuthFilter.doFilterInternal(request, response, filterChain);

        Mockito.verify(filterChain, Mockito.times(1)).doFilter(request, response);
        assertNull(SecurityContextHolder.getContext().getAuthentication());
    }

    @Test
    void cuandoHeaderNoEmpiezaConBearer_deberiaContinuarLaCadena() throws Exception {
        Mockito.when(request.getRequestURI()).thenReturn("/api/usuarios");
        Mockito.when(request.getHeader("Authorization")).thenReturn("TokenInvalido 12345");

        jwtAuthFilter.doFilterInternal(request, response, filterChain);

        Mockito.verify(filterChain, Mockito.times(1)).doFilter(request, response);
    }

    @Test
    void cuandoTokenEsValido_deberiaAutenticarYSettearContexto() throws Exception {
        String tokenValido = "un.token.real.aqui";
        Mockito.when(request.getRequestURI()).thenReturn("/api/usuarios");
        Mockito.when(request.getHeader("Authorization")).thenReturn("Bearer " + tokenValido);
        Mockito.when(jwtService.isTokenValid(tokenValido)).thenReturn(true);
        Mockito.when(jwtService.extractUsername(tokenValido)).thenReturn("alumno@duocuc.cl");
        Mockito.when(jwtService.extractRole(tokenValido)).thenReturn("ESTUDIANTE");

        jwtAuthFilter.doFilterInternal(request, response, filterChain);

        assertNotNull(SecurityContextHolder.getContext().getAuthentication());
        assertEquals("alumno@duocuc.cl", SecurityContextHolder.getContext().getAuthentication().getName());
        assertTrue(SecurityContextHolder.getContext().getAuthentication().getAuthorities().stream()
                .anyMatch(a -> a.getAuthority().equals("ROLE_ESTUDIANTE")));
        Mockito.verify(filterChain, Mockito.times(1)).doFilter(request, response);
    }

    @Test
    void cuandoOcurreUnaException_deberiaCapturarlaConElCatchYContinuar() throws Exception {
        Mockito.when(request.getRequestURI()).thenReturn("/api/usuarios");
        Mockito.when(request.getHeader("Authorization")).thenReturn("Bearer ");

        assertDoesNotThrow(() -> {
            jwtAuthFilter.doFilterInternal(request, response, filterChain);
        });
        Mockito.verify(filterChain, Mockito.times(1)).doFilter(request, response);
    }
}