package com.example.MSNotificaciones.service;

import com.example.MSNotificaciones.model.Notificacion;
import com.example.MSNotificaciones.repository.notificacionRepository;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Optional;

import static org.mockito.ArgumentMatchers.any;

@ExtendWith(MockitoExtension.class)
public class NotificacionServiceTest {

    @Mock
    private notificacionRepository repository;

    @InjectMocks
    private notificacionService service;

    @Test
    void cuandoSeGuardaNotificacion_entoncesAsignaFechaEnvioCorrectamente() {
        // GIVEN
        Notificacion notificacion = new Notificacion();
        notificacion.setFechaEnvio(null);

        Mockito.when(repository.save(any(Notificacion.class))).thenAnswer(i -> i.getArguments()[0]);

        // WHEN
        Notificacion resultado = service.save(notificacion);

        // THEN
        Assertions.assertNotNull(resultado.getFechaEnvio());
        Mockito.verify(repository, Mockito.times(1)).save(any(Notificacion.class));
    }
}