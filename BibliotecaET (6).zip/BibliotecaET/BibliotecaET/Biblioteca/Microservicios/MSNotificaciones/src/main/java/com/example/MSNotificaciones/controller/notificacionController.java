package com.example.MSNotificaciones.controller;


import com.example.MSNotificaciones.model.Notificacion;
import com.example.MSNotificaciones.service.notificacionService;
import io.swagger.v3.oas.annotations.Operation;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/notificaciones")
public class notificacionController {

    @Autowired
    private notificacionService service;

    @GetMapping
    public List<Notificacion> findAll() {
        return service.findAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Notificacion> findById(@PathVariable Long id) {
        Notificacion notificacion = service.findById(id);
        return notificacion != null ? ResponseEntity.ok(notificacion) : ResponseEntity.notFound().build();
    }

    @Operation(summary = "Enviar notificación", description = "Despacha alertas automáticas (emails o mensajes de sistema) sobre vencimientos de préstamos o confirmación de reservas")
    @PostMapping("/enviar")
    public ResponseEntity<Notificacion> save(@Valid @RequestBody Notificacion notificacion) {
        return new ResponseEntity<>(service.save(notificacion), HttpStatus.CREATED);
    }

    @DeleteMapping("/{id}")
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}
