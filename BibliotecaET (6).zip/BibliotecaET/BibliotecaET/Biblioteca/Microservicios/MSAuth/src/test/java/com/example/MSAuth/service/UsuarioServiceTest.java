package com.example.MSAuth.service;

import com.example.MSAuth.client.UsuarioClient;
import com.example.MSAuth.exception.ResourceNotFoundException;
import com.example.MSAuth.model.Usuario;
import com.example.MSAuth.repository.UsuarioRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
public class UsuarioServiceTest {

    @Mock
    private UsuarioRepository usuarioRepository;

    @Mock
    private PasswordEncoder passwordEncoder;

    @Mock
    private UsuarioClient usuarioClient;

    @InjectMocks
    private UsuarioService service;

    @Test
    public void cuandoBuscarUsuarioExistente_deberiaRetornarUsuario() {
        // GIVEN: un usuario real guardado en el repositorio
        Usuario usuarioFake = new Usuario();
        usuarioFake.setId(1L);
        usuarioFake.setUsername("cristian");
        usuarioFake.setEmail("cristian@ejemplo.com");
        usuarioFake.setRol("ADMIN");

        Mockito.when(usuarioRepository.findById(1L)).thenReturn(Optional.of(usuarioFake));

        // WHEN
        Usuario resultado = service.findById(1L);

        // THEN
        assertNotNull(resultado, "El usuario retornado no debería ser nulo");
        assertEquals("cristian", resultado.getUsername());
        assertEquals("ADMIN", resultado.getRol());
    }

    @Test
    public void cuandoBuscarUsuarioInexistente_deberiaLanzarResourceNotFoundException() {
        // GIVEN: el repositorio no encuentra el usuario con ID 99
        Mockito.when(usuarioRepository.findById(99L)).thenReturn(Optional.empty());

        // WHEN & THEN: findById usa .orElseThrow(), así que debe lanzar
        // exactamente ResourceNotFoundException, no un NoSuchElementException genérico
        ResourceNotFoundException ex = assertThrows(ResourceNotFoundException.class, () -> {
            service.findById(99L);
        });
        assertTrue(ex.getMessage().contains("99"), "El mensaje debe incluir el ID buscado");
    }

    @Test
    public void cuandoActualizarUsuarioSinNuevaPassword_noDeberiaReencriptarla() {
        // GIVEN: un usuario existente con una contraseña ya encriptada
        Usuario existente = new Usuario();
        existente.setId(1L);
        existente.setPassword("hashOriginal");
        existente.setEstado(true);

        Usuario datosActualizados = new Usuario();
        datosActualizados.setEstado(false);
        datosActualizados.setPassword(null); // no se envía password nueva

        Mockito.when(usuarioRepository.findById(1L)).thenReturn(Optional.of(existente));
        Mockito.when(usuarioRepository.save(Mockito.any(Usuario.class)))
                .thenAnswer(invocation -> invocation.getArgument(0));

        // WHEN
        Usuario resultado = service.actualizarUsuario(1L, datosActualizados);

        // THEN: el estado cambió, pero la contraseña original se mantiene intacta
        assertFalse(resultado.getEstado());
        assertEquals("hashOriginal", resultado.getPassword());
        Mockito.verify(passwordEncoder, Mockito.never()).encode(Mockito.anyString());
    }

    @Test
    public void cuandoActualizarUsuarioConNuevaPassword_deberiaReencriptarla() {
        // GIVEN
        Usuario existente = new Usuario();
        existente.setId(1L);
        existente.setPassword("hashViejo");
        existente.setEstado(true);

        Usuario datosActualizados = new Usuario();
        datosActualizados.setEstado(true);
        datosActualizados.setPassword("nuevaClaveEnTextoPlano");

        Mockito.when(usuarioRepository.findById(1L)).thenReturn(Optional.of(existente));
        Mockito.when(passwordEncoder.encode("nuevaClaveEnTextoPlano")).thenReturn("hashNuevo");
        Mockito.when(usuarioRepository.save(Mockito.any(Usuario.class)))
                .thenAnswer(invocation -> invocation.getArgument(0));

        // WHEN
        Usuario resultado = service.actualizarUsuario(1L, datosActualizados);

        // THEN: la contraseña fue re-encriptada usando el encoder, no guardada en texto plano
        assertEquals("hashNuevo", resultado.getPassword());
        Mockito.verify(passwordEncoder, Mockito.times(1)).encode("nuevaClaveEnTextoPlano");
    }

    @Test
    public void cuandoActualizarUsuarioInexistente_deberiaLanzarResourceNotFoundException() {
        // GIVEN
        Mockito.when(usuarioRepository.findById(404L)).thenReturn(Optional.empty());

        // WHEN & THEN
        assertThrows(ResourceNotFoundException.class, () -> {
            service.actualizarUsuario(404L, new Usuario());
        });
    }
}