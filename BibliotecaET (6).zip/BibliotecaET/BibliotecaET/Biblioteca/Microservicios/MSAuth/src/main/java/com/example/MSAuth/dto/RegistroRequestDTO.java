package com.example.MSAuth.dto;

import jakarta.validation.constraints.*;

public class RegistroRequestDTO {
    @NotBlank(message = "El username es obligatorio")
    private String username;

    @NotBlank(message = "El password es obligatorio")
    @Size(min = 6, message = "El password debe tener al menos 6 caracteres")
    private String password;

    @NotBlank(message = "El email es obligatorio")
    @Email(message = "El formato del email no es válido")
    private String email;

    @NotBlank(message = "El nombre es obligatorio")
    private String nombre1;

    @NotBlank(message = "El apellido es obligatorio")
    private String apellido1;

    @Pattern(regexp = "USUARIO|ADMIN|TRABAJADOR", message = "Rol debe ser USUARIO, ADMIN o TRABAJADOR")
    private String rol = "USUARIO";

    // Getters y Setters
    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }
    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    public String getNombre1() { return nombre1; }
    public void setNombre1(String nombre1) { this.nombre1 = nombre1; }
    public String getApellido1() { return apellido1; }
    public void setApellido1(String apellido1) { this.apellido1 = apellido1; }
    public String getRol() { return rol; }
    public void setRol(String rol) { this.rol = rol; }
}