package com.example.MSAuth.client;

import com.example.MSAuth.model.RegistroUsuarioDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

@Component
public class UsuarioClient {

    @Autowired
    private WebClient.Builder webClientBuilder;

    public Mono<Void> enviarPerfil(RegistroUsuarioDTO dto) {
        return webClientBuilder.build()
                .post()
                .uri("http://ms-usuario/api/v1/usuarios")
                .bodyValue(dto)
                .retrieve()
                .onStatus(status -> status.isError(), response ->
                        response.bodyToMono(String.class).flatMap(errorBody ->
                                Mono.error(new RuntimeException("Error al crear perfil en MSusuario: " + errorBody))
                        )
                )
                .bodyToMono(Void.class);
    }
}