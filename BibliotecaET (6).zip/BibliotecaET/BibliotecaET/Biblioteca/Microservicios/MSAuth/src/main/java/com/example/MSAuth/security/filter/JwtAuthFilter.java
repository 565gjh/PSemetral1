package com.example.MSAuth.security.filter;

import com.example.MSAuth.security.jwt.JwtService;
import com.example.MSAuth.service.CustomUserDetailsService;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;

@Component
public class JwtAuthFilter extends OncePerRequestFilter {

    private static final Logger log = LoggerFactory.getLogger(JwtAuthFilter.class);

    private final JwtService jwtService;
    private final CustomUserDetailsService userDetailsService;

    public JwtAuthFilter(JwtService jwtService, CustomUserDetailsService userDetailsService) {
        this.jwtService = jwtService;
        this.userDetailsService = userDetailsService;
    }

    @Override
    protected boolean shouldNotFilter(HttpServletRequest request) throws ServletException {
        String path = request.getRequestURI();

        // ⭐ El filtro dejará pasar CUALQUIER cosa que huela a Swagger o API-docs
        return path.contains("/v3/api-docs")
                || path.contains("/swagger-ui")
                || path.contains("/swagger-resources")
                || path.contains("/webjars");
    }

    @Override
    protected void doFilterInternal(HttpServletRequest request,
                                    HttpServletResponse response,
                                    FilterChain filterChain) throws ServletException, IOException {

        String path = request.getRequestURI();

        // NO validar token en rutas públicas estándar de tu controlador o la consola H2
        if (path.startsWith("/api/v1/auth/") || path.startsWith("/h2-console/")) {
            filterChain.doFilter(request, response);
            return;
        }

        String authHeader = request.getHeader("Authorization");

        if (authHeader != null && authHeader.startsWith("Bearer ")) {
            try {
                String token = authHeader.substring(7);

                // ⭐ VALIDAR EL TOKEN
                if (jwtService.isTokenValid(token)) {
                    String username = jwtService.extractUsername(token);

                    // ⭐ CARGAR EL USUARIO
                    UserDetails userDetails = userDetailsService.loadUserByUsername(username);

                    // ⭐ CREAR LA AUTENTICACIÓN
                    UsernamePasswordAuthenticationToken authToken =
                            new UsernamePasswordAuthenticationToken(
                                    userDetails,
                                    null,
                                    userDetails.getAuthorities()
                            );

                    authToken.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));

                    // ⭐ ESTABLECER LA AUTENTICACIÓN EN EL CONTEXTO DE SEGURIDAD
                    SecurityContextHolder.getContext().setAuthentication(authToken);

                    // ⭐ LOG DE ÉXITO CON SLF4J
                    log.info("✅ Token validado con éxito para el usuario: {}", username);
                } else {
                    // ⭐ LOG DE ERROR CON SLF4J
                    log.error("❌ Token inválido o expirado en la petición");
                }
            } catch (Exception e) {
                log.error("❌ Excepción al procesar el token JWT: {}", e.getMessage());
            }
        }

        filterChain.doFilter(request, response);
    }
}