package com.example.MSAuth.service;

import com.example.MSAuth.exception.ResourceNotFoundException;
import com.example.MSAuth.model.RegistroUsuarioDTO;
import com.example.MSAuth.client.UsuarioClient;
import com.example.MSAuth.model.Usuario;
import com.example.MSAuth.repository.UsuarioRepository;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;
import java.util.Map;
import com.example.MSAuth.dto.RegistroRequestDTO;

@Service
public class UsuarioService {

    @Autowired
    private UsuarioRepository usuarioRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private UsuarioClient usuarioClient;

    // 1. CREATE (Guardar usuario con validaciones de negocio en capa Service)
    public void register(RegistroRequestDTO body) {
        Usuario nuevoUsuario = new Usuario();
        nuevoUsuario.setUsername(body.getUsername());
        nuevoUsuario.setPassword(passwordEncoder.encode(body.getPassword()));
        nuevoUsuario.setEmail(body.getEmail());
        nuevoUsuario.setRol(body.getRol());
        nuevoUsuario.setEstado(true);

        Usuario guardado = usuarioRepository.save(nuevoUsuario);

        RegistroUsuarioDTO perfilParaEnviar = new RegistroUsuarioDTO();
        perfilParaEnviar.setAuthId(guardado.getId());
        perfilParaEnviar.setNombre1(body.getNombre1());
        perfilParaEnviar.setApellido1(body.getApellido1());
        perfilParaEnviar.setEmail(body.getEmail());
        perfilParaEnviar.setTipoUsuario(body.getRol());

        usuarioClient.enviarPerfil(perfilParaEnviar).block();
    }

    // 2. READ (Obtener todos)
    public List<Usuario> obtenerTodos() {
        return usuarioRepository.findAll();
    }

    // 3. UPDATE (Modificado con control de excepciones de negocio)
    public Usuario actualizarUsuario(Long id, Usuario datosActualizados) {
        return usuarioRepository.findById(id).map(usuario -> {
            usuario.setEstado(datosActualizados.getEstado());

            // Solo re-encriptar si el usuario envía una nueva contraseña
            if (datosActualizados.getPassword() != null && !datosActualizados.getPassword().isEmpty()) {
                usuario.setPassword(passwordEncoder.encode(datosActualizados.getPassword()));
            }
            return usuarioRepository.save(usuario);
        }).orElseThrow(() -> new ResourceNotFoundException("Usuario no encontrado con id: " + id));
    }

    // 4. READ (Búsqueda por ID con control explícito de ausencia para evitar .get() directo)
    public Usuario findById(Long id) {
        return usuarioRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Usuario no encontrado con id: " + id));
    }

    public Optional<Usuario> findByUsername(String username) {
        return usuarioRepository.findByUsername(username);
    }

    public Optional<Usuario> findByEmail(String email) {
        return usuarioRepository.findByEmail(email);
    }

    public List<Usuario> findByEstado(boolean estado) {
        return usuarioRepository.findByEstado(estado);
    }

}