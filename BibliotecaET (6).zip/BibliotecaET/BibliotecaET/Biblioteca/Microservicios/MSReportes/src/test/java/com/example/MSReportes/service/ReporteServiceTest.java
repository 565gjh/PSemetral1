package com.example.MSReportes.service;

import com.example.MSReportes.model.Reporte;
import com.example.MSReportes.repository.reporteRepository;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.mockito.ArgumentMatchers.any;

@ExtendWith(MockitoExtension.class)
public class ReporteServiceTest {

    @Mock
    private reporteRepository repository;

    @InjectMocks
    private reporteService service;

    @Test
    void cuandoSeGeneraReporte_entoncesAsignaFechaCreacion() {
        // GIVEN
        Reporte reporte = new Reporte();
        reporte.setFechaCreacion(null);

        Mockito.when(repository.save(any(Reporte.class))).thenAnswer(i -> i.getArguments()[0]);

        // WHEN
        Reporte resultado = service.save(reporte);

        // THEN
        Assertions.assertNotNull(resultado.getFechaCreacion());
        Mockito.verify(repository, Mockito.times(1)).save(any(Reporte.class));
    }
}