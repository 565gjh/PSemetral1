package com.example.MSResenas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsResenasApplicationTests {

    @Test
    void contextLoads() {
    }

}
