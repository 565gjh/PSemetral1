package com.example.MSResenas.repository;

import com.example.MSResenas.model.Resena;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.data.jpa.test.autoconfigure.DataJpaTest;
import org.springframework.boot.jdbc.test.autoconfigure.AutoConfigureTestDatabase;
import java.time.LocalDateTime;
import java.util.List;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.springframework.boot.jdbc.test.autoconfigure.AutoConfigureTestDatabase.Replace.ANY;

@DataJpaTest
@AutoConfigureTestDatabase(replace = ANY)
class ResenaRepositoryTest {

    @Autowired
    private ResenaRepository resenaRepository;

    @Test
    void findByLibroId_devuelveSoloLasResenasDeEseLibro() {
        Resena r1 = new Resena(null, 1L, 10L, "Buena", 5, LocalDateTime.now());
        Resena r2 = new Resena(null, 2L, 10L, "Regular", 3, LocalDateTime.now());
        resenaRepository.save(r1);
        resenaRepository.save(r2);

        List<Resena> resultado = resenaRepository.findByLibroId(1L);

        assertEquals(1, resultado.size());
        assertEquals(5, resultado.get(0).getPuntuacion());
    }
}