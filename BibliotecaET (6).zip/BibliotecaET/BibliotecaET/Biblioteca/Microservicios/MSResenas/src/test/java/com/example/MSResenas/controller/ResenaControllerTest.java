package com.example.MSResenas.controller;

import com.example.MSResenas.model.Resena;
import com.example.MSResenas.model.ResenaRequestDTO;
import com.example.MSResenas.security.filter.JwtAuthFilter;
import com.example.MSResenas.service.ResenaService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
// 🟢 NUEVOS IMPORTS PARA SPRING BOOT 4.x
import org.springframework.boot.webmvc.test.autoconfigure.WebMvcTest;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(ResenaController.class)
class ResenaControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    // 🟢 CAMBIADO A @MockitoBean
    @MockitoBean
    private ResenaService resenaService;

    // 🟢 CAMBIADO A @MockitoBean
    @MockitoBean
    private JwtAuthFilter jwtAuthFilter;

    @Test
    @WithMockUser
    void crearResena_conDatosValidos_retorna201() throws Exception {
        ResenaRequestDTO dto = new ResenaRequestDTO();
        dto.setLibroId(1L);
        dto.setUsuarioId(1L);
        dto.setComentario("Excelente");
        dto.setPuntuacion(4);

        Resena creada = new Resena();
        creada.setId(1L);

        when(resenaService.crearResena(any())).thenReturn(creada);

        mockMvc.perform(post("/api/v1/resenas")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(dto)))
                .andExpect(status().isCreated());
    }

    @Test
    @WithMockUser
    void crearResena_conPuntuacionInvalida_retorna400() throws Exception {
        ResenaRequestDTO dto = new ResenaRequestDTO();
        dto.setLibroId(1L);
        dto.setUsuarioId(1L);
        dto.setComentario("Malo");
        dto.setPuntuacion(9); // Fuera de rango 1-5

        mockMvc.perform(post("/api/v1/resenas")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(dto)))
                .andExpect(status().isBadRequest());
    }
}