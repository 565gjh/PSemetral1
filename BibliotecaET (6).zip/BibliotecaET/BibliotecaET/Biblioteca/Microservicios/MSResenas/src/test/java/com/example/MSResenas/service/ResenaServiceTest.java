package com.example.MSResenas.service;

import com.example.MSResenas.client.CatalogoClient;
import com.example.MSResenas.client.UsuarioClient;
import com.example.MSResenas.model.*;
import com.example.MSResenas.repository.ResenaRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class ResenaServiceTest {

    @Mock private ResenaRepository resenaRepository;
    @Mock private CatalogoClient catalogoClient;
    @Mock private UsuarioClient usuarioClient;

    @InjectMocks
    private ResenaService resenaService;

    private ResenaRequestDTO dtoValido;

    @BeforeEach
    void setUp() {
        dtoValido = new ResenaRequestDTO();
        dtoValido.setLibroId(1L);
        dtoValido.setUsuarioId(1L);
        dtoValido.setComentario("Muy buen libro");
        dtoValido.setPuntuacion(5);
    }

    @Test
    void cuandoLibroYUsuarioExisten_entoncesGuardaLaResena() {
        // GIVEN
        when(catalogoClient.obtenerLibro(1L)).thenReturn(new LibroResponseDTO());
        when(usuarioClient.obtenerUsuario(1L)).thenReturn(new UsuarioDTO());
        when(resenaRepository.save(any(Resena.class))).thenAnswer(i -> i.getArguments()[0]);

        // WHEN
        Resena resultado = resenaService.crearResena(dtoValido);

        // THEN
        assertNotNull(resultado);
        assertNotNull(resultado.getFechaCreacion());
        assertEquals(5, resultado.getPuntuacion());
        verify(resenaRepository, times(1)).save(any(Resena.class));
    }

    @Test
    void cuandoLibroNoExiste_entoncesLanzaExcepcion() {
        when(catalogoClient.obtenerLibro(1L)).thenReturn(null);

        RuntimeException ex = assertThrows(RuntimeException.class,
                () -> resenaService.crearResena(dtoValido));

        assertTrue(ex.getMessage().contains("libro"));
        verify(resenaRepository, never()).save(any());
    }

    @Test
    void cuandoUsuarioNoExiste_entoncesLanzaExcepcion() {
        when(catalogoClient.obtenerLibro(1L)).thenReturn(new LibroResponseDTO());
        when(usuarioClient.obtenerUsuario(1L)).thenReturn(null);

        RuntimeException ex = assertThrows(RuntimeException.class,
                () -> resenaService.crearResena(dtoValido));

        assertTrue(ex.getMessage().contains("usuario"));
        verify(resenaRepository, never()).save(any());
    }

    @Test
    void obtenerPorLibro_delegaCorrectamenteAlRepositorio() {
        when(resenaRepository.findByLibroId(1L)).thenReturn(List.of(new Resena()));

        List<Resena> resultado = resenaService.obtenerPorLibro(1L);

        assertEquals(1, resultado.size());
        verify(resenaRepository).findByLibroId(1L);
    }

    @Test
    void obtenerPorUsuario_delegaCorrectamenteAlRepositorio() {
        when(resenaRepository.findByUsuarioId(2L)).thenReturn(List.of());

        List<Resena> resultado = resenaService.obtenerPorUsuario(2L);

        assertTrue(resultado.isEmpty());
        verify(resenaRepository).findByUsuarioId(2L);
    }
}