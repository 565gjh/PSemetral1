package com.example.MSResenas.config;

import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.reactive.function.client.WebClient;

@Configuration
public class WebClientConfig {

    @Bean
    @LoadBalanced // Permite usar nombres de Eureka en lugar de IPs fijas
    public WebClient.Builder webClientBuilder() {
        return WebClient.builder();
    }
}