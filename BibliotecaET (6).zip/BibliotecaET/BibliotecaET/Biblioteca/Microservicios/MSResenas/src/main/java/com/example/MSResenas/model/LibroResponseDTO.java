// model/LibroResponseDTO.java
package com.example.MSResenas.model;

import lombok.Data;

@Data
public class LibroResponseDTO {
    private Long id;
    private String titulo;
}