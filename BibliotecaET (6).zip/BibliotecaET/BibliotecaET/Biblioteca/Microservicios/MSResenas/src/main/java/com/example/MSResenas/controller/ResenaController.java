package com.example.MSResenas.controller;

import com.example.MSResenas.model.Resena;
import com.example.MSResenas.model.ResenaRequestDTO;
import com.example.MSResenas.service.ResenaService;
import io.swagger.v3.oas.annotations.Operation;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/resenas")
public class ResenaController {

    @Autowired
    private ResenaService resenaService;

    @Operation(summary = "Crear una reseña", description = "Valida que el libro y el usuario existan antes de guardar")
    @PostMapping
    public ResponseEntity<?> crear(@Valid @RequestBody ResenaRequestDTO dto) {
        Resena creada = resenaService.crearResena(dto);
        return ResponseEntity.status(HttpStatus.CREATED).body(creada);
    }

    @GetMapping
    public ResponseEntity<List<Resena>> listarTodas() {
        return ResponseEntity.ok(resenaService.obtenerTodas());
    }

    @GetMapping("/libro/{libroId}")
    public ResponseEntity<List<Resena>> porLibro(@PathVariable Long libroId) {
        return ResponseEntity.ok(resenaService.obtenerPorLibro(libroId));
    }

    @GetMapping("/usuario/{usuarioId}")
    public ResponseEntity<List<Resena>> porUsuario(@PathVariable Long usuarioId) {
        return ResponseEntity.ok(resenaService.obtenerPorUsuario(usuarioId));
    }
}