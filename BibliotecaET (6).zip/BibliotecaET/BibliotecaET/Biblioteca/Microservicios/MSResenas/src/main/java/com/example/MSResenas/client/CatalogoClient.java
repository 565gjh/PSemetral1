package com.example.MSResenas.client;

import com.example.MSResenas.model.LibroResponseDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;

@Component
public class CatalogoClient {

    @Autowired
    private WebClient.Builder webClientBuilder;

    public LibroResponseDTO obtenerLibro(Long libroId) {
        try {
            return webClientBuilder.build()
                    .get()
                    .uri("http://ms-catalogo/api/v1/catalogo/libro/id/" + libroId)
                    .retrieve()
                    .bodyToMono(LibroResponseDTO.class)
                    .block();
        } catch (Exception e) {
            return null;
        }
    }
}