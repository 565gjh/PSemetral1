CREATE TABLE resenas (
                         id BIGINT AUTO_INCREMENT PRIMARY KEY,
                         libro_id BIGINT NOT NULL,
                         usuario_id BIGINT NOT NULL,
                         comentario VARCHAR(500) NOT NULL,
                         puntuacion INT NOT NULL,
                         fecha_creacion DATETIME NOT NULL
);