// model/UsuarioDTO.java
package com.example.MSResenas.model;

import lombok.Data;

@Data
public class UsuarioDTO {
    private Long id;
    private String nombre;
}