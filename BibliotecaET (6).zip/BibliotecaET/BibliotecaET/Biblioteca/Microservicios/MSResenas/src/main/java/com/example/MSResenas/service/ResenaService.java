package com.example.MSResenas.service;

import com.example.MSResenas.client.CatalogoClient;
import com.example.MSResenas.client.UsuarioClient;
import com.example.MSResenas.model.*;
import com.example.MSResenas.repository.ResenaRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Slf4j
@Service
public class ResenaService {

    @Autowired
    private ResenaRepository resenaRepository;

    @Autowired
    private CatalogoClient catalogoClient;

    @Autowired
    private UsuarioClient usuarioClient;

    public Resena crearResena(ResenaRequestDTO dto) {
        LibroResponseDTO libro = catalogoClient.obtenerLibro(dto.getLibroId());
        if (libro == null) {
            throw new RuntimeException("El libro indicado no existe en el catálogo.");
        }

        UsuarioDTO usuario = usuarioClient.obtenerUsuario(dto.getUsuarioId());
        if (usuario == null) {
            throw new RuntimeException("El usuario indicado no existe.");
        }

        Resena resena = new Resena();
        resena.setLibroId(dto.getLibroId());
        resena.setUsuarioId(dto.getUsuarioId());
        resena.setComentario(dto.getComentario());
        resena.setPuntuacion(dto.getPuntuacion());
        resena.setFechaCreacion(LocalDateTime.now());

        Resena guardada = resenaRepository.save(resena);
        log.info("Reseña creada con id {} para libro {}", guardada.getId(), guardada.getLibroId());
        return guardada;
    }

    public List<Resena> obtenerPorLibro(Long libroId) {
        return resenaRepository.findByLibroId(libroId);
    }

    public List<Resena> obtenerPorUsuario(Long usuarioId) {
        return resenaRepository.findByUsuarioId(usuarioId);
    }

    public List<Resena> obtenerTodas() {
        return resenaRepository.findAll();
    }
}