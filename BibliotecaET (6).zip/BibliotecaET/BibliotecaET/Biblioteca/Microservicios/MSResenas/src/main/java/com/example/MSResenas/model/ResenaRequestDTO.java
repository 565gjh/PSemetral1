package com.example.MSResenas.model;

import jakarta.validation.constraints.*;
import lombok.Data;

@Data
public class ResenaRequestDTO {

    @NotNull(message = "El id del libro es obligatorio")
    private Long libroId;

    @NotNull(message = "El id del usuario es obligatorio")
    private Long usuarioId;

    @NotBlank(message = "El comentario no puede estar vacío")
    @Size(max = 500)
    private String comentario;

    @NotNull
    @Min(1) @Max(5)
    private Integer puntuacion;
}