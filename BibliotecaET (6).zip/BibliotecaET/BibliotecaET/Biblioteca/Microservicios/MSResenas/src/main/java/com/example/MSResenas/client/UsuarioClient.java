package com.example.MSResenas.client;

import com.example.MSResenas.model.UsuarioDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;

@Component
public class UsuarioClient {

    @Autowired
    private WebClient.Builder webClientBuilder;

    public UsuarioDTO obtenerUsuario(Long usuarioId) {
        try {
            return webClientBuilder.build()
                    .get()
                    .uri("http://ms-usuario/api/v1/usuarios/id/" + usuarioId)
                    .retrieve()
                    .bodyToMono(UsuarioDTO.class)
                    .block();
        } catch (Exception e) {
            return null;
        }
    }
}