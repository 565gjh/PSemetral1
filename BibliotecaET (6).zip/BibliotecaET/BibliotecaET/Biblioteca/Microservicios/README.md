# Sistema de Microservicios - Gestión de Biblioteca

Este proyecto implementa el backend de un sistema de biblioteca utilizando una arquitectura de microservicios con Spring Boot, Spring Cloud y persistencia independiente por servicio (Database-per-Microservice). Todo el ecosistema está preparado para levantarse en contenedores mediante Docker.

## Integrantes
* Benjamin Solis
* Cristobal Vasquez
* Juan Pablo Palominos 

---
## Distribución de Tareas
***Cristóbal Vásquez**
* **Responsabilidades clave:** Configuración e implementación de Docker Compose, despliegue del ecosistema en contenedores, desarrollo de Pruebas Unitarias automatizadas (JUnit 5 + Mockito), finalización del proyecto y control de calidad (ajustes de estructura y corrección de errores).
* **Co-desarrollo:** Modificación y optimización de microservicios, integración de rutas en el API Gateway.

***Benjamín Solís**
* **Responsabilidades clave:** Arquitectura inicial del proyecto, creación de la estructura base de los microservicios, desarrollo de la lógica de negocio principal, manejo centralizado de excepciones (`@RestControllerAdvice`) e implementación de trazas de log con SLF4J.
* **Co-desarrollo:** Pruebas de endpoints e integración mediante Postman, comunicación síncrona entre servicios.


**Juan Pablo Palominos**
    * *Sin asignación de tareas por falta de participación en el desarrollo, documentación y pruebas del proyecto.*
---
## Estructura del Proyecto

El sistema se divide en componentes de infraestructura básica y los servicios que manejan la lógica de negocio:

### Infraestructura
* **api-gateway (Puerto 9090):** Centraliza las peticiones del cliente y redirige el tráfico al microservicio que corresponda. Está configurado en formato YAML para mantener las rutas limpias y legibles.
* **eureka-server (Puerto 8761):** Servidor de descubrimiento donde se registran automáticamente todos los servicios al levantar.

### Servicios de Negocio
* **MSAuth (Puerto 9091):** Maneja el registro, login y validación de tokens JWT. Tiene implementado logging estructurado con SLF4J en los filtros de seguridad.
* **MSReservas (Puerto 8082):** Gestiona las reservas y se comunica internamente con otros servicios usando RestTemplate para validar datos de usuarios y libros.
* **Servicios base:** MSCatalogo, MSInventario, MSPrestamo, MSMultas, MSNotificaciones, MSReportes y MSUsuario.

---
### Pruebas Unitarias (JUnit 5 + Mockito)
***MSReservas:** `ms-reservas/src/test/java/com/example/MSReservas/service/reservaServiceTest.java`.

** **MSUsuario:** `ms-usuario/src/test/java/com/example/MSusuario/service/UsuarioServiceTest.java`.

** **MSCatalogo:** `ms-catalogo/src/test/java/com/example/MSCatalogo/service/LibroServiceBusquedaTest.java`.

** **MicroServicios Restantes:** Cada microservicio cuenta con su propia Prueba Unitaria en Test -> Service -> "Nombre del test". 


***Comando de ejecución:** `mvn test`

---
## Ajustes y Mejoras de Calidad (Rúbrica)

Para cumplir con las exigencias de la pauta de evaluación, nos enfocamos en tres puntos clave:

1. **Reemplazo de System.out por SLF4J** : Implementación de trazabilidad con SLF4J mediante la anotación @Slf4j en la capa de servicios para un registro estructurado de eventos en consola.
2. **Manejo Centralizado de Errores:** Se implementó `@RestControllerAdvice` a lo largo de los servicios. Si un endpoint falla o no encuentra un recurso, interceptamos la excepción para responder con un JSON limpio (con estado HTTP correcto y timestamp) en lugar de exponer la traza interna de Spring.
3. **Pruebas Unitarias Reales con Mockito:** Diseñamos pruebas para validar la lógica del Service de reservas sin depender de que la base de datos o los otros microservicios estén activos. Usamos `@Mock` para simular las respuestas del repositorio y de las llamadas externas de RestTemplate, asegurando que los métodos armen los DTOs exactamente como se espera.
4. **Estructura de perfiles híbrida**: uso de application.properties para la configuración base local de Spring Boot y application-docker.yml optimizado para la contenedorización mediante perfiles de despliegue aislados.
5. **Corrección Crítica de Nombres de Perfil:** Detección y corrección del error de tipeo en MSCatalogo, MSInventario y MSPrestamo (se cambió application.docker.yml por el formato correcto application-docker.yml con guion), reactivando la conexión automática a las bases de datos en Docker.
6. **Sincronización de Puertos (MSInventario):** Eliminación del desajuste triple de puertos (9095, 8084, 8087) unificando todo el microservicio en el puerto 9095 en Spring Boot y docker-compose.yml.
7. **Actualización de Swagger UI (Línea 3.x)**: Inyección de la dependencia visual de SpringDoc en MSMultas, MSNotificaciones, MSPrestamo y MSReportes escalando a la versión 3.0.3 para asegurar compatibilidad total con Spring Boot 4.0.6.
8. **Estructuración de Tests Unitarios Reales**: Implementación de suites de pruebas con JUnit 5 y Mockito en MSReservas y MSCatalogo (LibroServiceBusquedaTest.java), simulando con éxito los repositorios y la Comunicación inter-servicio asíncrona y reactiva implementada mediante WebClient con balanceo de carga dinámico (@LoadBalanced) a través del servidor de descubrimiento Eureka."
9. **Aislamiento y Manejo de Excepciones:** Cobertura de pruebas específica para verificar el lanzamiento de excepciones controladas de negocio (ResourceNotFoundException y EntityNotFoundException) interceptadas por el Handler Global.
10. Implementacion del Decimo Microservicio.

---

## Documentación de las APIs (Swagger)

La documentación de los endpoints está unificada a través del API Gateway, por lo que se puede probar todo desde una sola URL sin necesidad de ir puerto por puerto:

* **URL de Swagger UI:** http://localhost:9090/swagger-ui/index.html

*Nota para la presentación:* Una vez abierta la interfaz de Swagger, se puede cambiar entre los endpoints de un servicio u otro usando el menú desplegable que está arriba a la derecha (Select a definition).


---
## Interfaces de Documentación Interactiva (Swagger UI)

Direcciones asignadas para interactuar con los endpoints de cada microservicio, enviar peticiones de prueba en tiempo real y verificar las estructuras de los DTOs (Request/Response):

* MSUsuario (Gestión de Usuarios)

  Interfaz Visual: http://localhost:8081/swagger-ui/index.html

  Definición JSON/Metadata: http://localhost:8081/v3/api-docs
* MSReservas (Control de Reservas)

  Interfaz Visual: http://localhost:8082/swagger-ui/index.html

  Definición JSON/Metadata: http://localhost:8082/v3/api-docs
* MSReportes (Módulo Estadístico y Reportes)

  Interfaz Visual: http://localhost:8083/swagger-ui/index.html

  Definición JSON/Metadata: http://localhost:8083/v3/api-docs
* MSNotificaciones (Alertas y Correos)

  Interfaz Visual: http://localhost:8085/swagger-ui/index.html

  Definición JSON/Metadata: http://localhost:8085/v3/api-docs
* MSMultas (Control de Infracciones)

  Interfaz Visual: http://localhost:8086/swagger-ui/index.html

  Definición JSON/Metadata: http://localhost:8086/v3/api-docs
* MSAuth (Seguridad y Autenticación)

  Interfaz Visual: http://localhost:9091/swagger-ui/index.html

  Definición JSON/Metadata: http://localhost:9091/v3/api-docs
* MSPrestamo (Gestión de Préstamos)

  Interfaz Visual: http://localhost:9093/swagger-ui/index.html

  Definición JSON/Metadata: http://localhost:9093/v3/api-docs
* MSCatalogo (Catálogo Bibliográfico)

  Interfaz Visual: http://localhost:9094/swagger-ui/index.html

  Definición JSON/Metadata: http://localhost:9094/v3/api-docs
* MSResenas (Gestión de Reseñas y Valoraciones)

  Interfaz Visual: http://localhost:8084/swagger-ui/index.html

  Definición JSON/Metadata: http://localhost:8084/v3/api-docs
* MSInventario (Control de Existencias/Stock)

  Interfaz Visual: http://localhost:9095/swagger-ui/index.html

  Definición JSON/Metadata: http://localhost:9095/v3/api-docs

---
## Puerta de Enlace Perimetral (API Gateway)

Punto de entrada único para las peticiones de los clientes (Frontend/Postman). Se encarga de enrutar las solicitudes hacia los microservicios correspondientes de forma interna.

* URL Base de Enrutamiento: http://localhost:9090


---
## Panel de Control del Servidor de Descubrimiento (Eureka)
Es la consola central donde la comisión puede verificar en tiempo real qué microservicios están vivos (UP) dentro de la red de Docker.

* URL del Dashboard de Eureka: http://localhost:8761

---

## Cómo Levantar el Proyecto

Para compilar y levantar todo el ecosistema con sus respectivas dependencias, ejecuta el siguiente comando en la raíz donde está el archivo compose:

```bash
docker compose up -d --build


