package com.example.MSReservas.controller;

import com.example.MSReservas.dto.EstadoReservaRequestDto;
import com.example.MSReservas.dto.ReservaRequestDto;
import com.example.MSReservas.dto.ReservaResponseDto;
import com.example.MSReservas.model.Reserva;
import com.example.MSReservas.service.reservaService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/reservas")
@Tag(name = "Reservas", description = "Gestión de la fila de espera de libros de la biblioteca")
public class reservaController {

    @Autowired
    private reservaService reservaService;

    @Operation(summary = "Crear una reserva",
            description = "Valida al usuario en ms-usuario y al libro en ms-catalogo, "
                    + "rechaza reservas activas duplicadas y calcula la posición en la fila")
    @ApiResponses({
            @ApiResponse(responseCode = "201", description = "Reserva creada correctamente"),
            @ApiResponse(responseCode = "400", description = "Datos inválidos o reserva duplicada"),
            @ApiResponse(responseCode = "404", description = "El usuario o el libro no existen")
    })
    @PostMapping
    public ResponseEntity<Reserva> crearReserva(@Valid @RequestBody ReservaRequestDto request) {
        Reserva creada = reservaService.crearReserva(request);
        return ResponseEntity.status(HttpStatus.CREATED).body(creada);
    }

    @Operation(summary = "Listar todas las reservas")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Listado obtenido"),
            @ApiResponse(responseCode = "204", description = "No hay reservas registradas")
    })
    @GetMapping
    public ResponseEntity<List<Reserva>> listarTodas() {
        List<Reserva> reservas = reservaService.obtenerTodas();
        if (reservas.isEmpty()) {
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.ok(reservas);
    }

    @Operation(summary = "Obtener reserva detallada",
            description = "Recupera la reserva e integra dinámicamente los datos de ms-usuario "
                    + "y ms-catalogo resolviendo las URLs mediante Eureka")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Reserva encontrada"),
            @ApiResponse(responseCode = "404", description = "La reserva no existe")
    })
    @GetMapping("/{id}")
    public ResponseEntity<ReservaResponseDto> buscarReservaPorId(@PathVariable Long id) {
        return ResponseEntity.ok(reservaService.obtenerPorId(id));
    }

    @Operation(summary = "Listar reservas por usuario y estado")
    @ApiResponse(responseCode = "200", description = "Listado obtenido")
    @GetMapping("/usuario/{usuarioId}/estado/{estado}")
    public ResponseEntity<List<Reserva>> buscarPorUsuarioYEstado(
            @PathVariable Long usuarioId,
            @PathVariable String estado) {
        return ResponseEntity.ok(reservaService.listarPorUsuarioYEstado(usuarioId, estado));
    }

    @Operation(summary = "Actualizar el estado de una reserva",
            description = "Solo acepta ACTIVA, CANCELADA o COMPLETADA. "
                    + "Una reserva COMPLETADA es terminal y no admite cambios")
    @ApiResponses({
            @ApiResponse(responseCode = "200", description = "Estado actualizado"),
            @ApiResponse(responseCode = "400", description = "Estado inválido o reserva ya completada"),
            @ApiResponse(responseCode = "404", description = "La reserva no existe")
    })
    @PutMapping("/{id}")
    public ResponseEntity<Reserva> actualizarEstado(
            @PathVariable Long id,
            @Valid @RequestBody EstadoReservaRequestDto request) {
        return ResponseEntity.ok(reservaService.actualizarEstado(id, request.getEstado()));
    }

    @Operation(summary = "Eliminar una reserva")
    @ApiResponses({
            @ApiResponse(responseCode = "204", description = "Reserva eliminada"),
            @ApiResponse(responseCode = "404", description = "La reserva no existe")
    })
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminarReserva(@PathVariable Long id) {
        reservaService.eliminarReserva(id);
        return ResponseEntity.noContent().build();
    }
}