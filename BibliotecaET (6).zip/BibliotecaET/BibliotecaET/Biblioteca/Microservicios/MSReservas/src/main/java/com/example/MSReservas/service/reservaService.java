package com.example.MSReservas.service;

import com.example.MSReservas.dto.LibroDto;
import com.example.MSReservas.dto.ReservaRequestDto;
import com.example.MSReservas.dto.ReservaResponseDto;
import com.example.MSReservas.dto.UsuarioDto;
import com.example.MSReservas.model.Reserva;
import com.example.MSReservas.repository.reservaRepository;
import jakarta.persistence.EntityNotFoundException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.time.LocalDateTime;
import java.util.List;

@Service
@Slf4j
public class reservaService {

    private static final String ESTADO_ACTIVA = "ACTIVA";

    @Autowired
    private reservaRepository reservaRepository;

    @Autowired
    private RestTemplate restTemplate;

    // ─────────────────────────── CREATE ───────────────────────────

    /**
     * Registra una nueva reserva aplicando las reglas de negocio del dominio:
     * 1. El usuario debe existir en ms-usuario.
     * 2. El libro debe existir en ms-catalogo.
     * 3. Un usuario no puede tener dos reservas ACTIVAS sobre el mismo libro.
     * 4. La posición en la fila se calcula automáticamente según las reservas activas del libro.
     */
    public Reserva crearReserva(ReservaRequestDto request) {
        log.info("Iniciando creación de reserva para usuario {} y libro {}",
                request.getUsuarioId(), request.getLibroId());

        validarUsuarioExiste(request.getUsuarioId());
        validarLibroExiste(request.getLibroId());

        if (reservaRepository.existsByUsuarioIdAndLibroIdAndEstado(
                request.getUsuarioId(), request.getLibroId(), ESTADO_ACTIVA)) {
            log.warn("Reserva duplicada rechazada: usuario {} ya tiene una reserva activa del libro {}",
                    request.getUsuarioId(), request.getLibroId());
            throw new IllegalArgumentException(
                    "El usuario ya tiene una reserva activa para este libro");
        }

        int posicion = calcularPosicionEnFila(request.getLibroId());

        Reserva reserva = new Reserva();
        reserva.setUsuarioId(request.getUsuarioId());
        reserva.setLibroId(request.getLibroId());
        reserva.setPosicionFila(posicion);
        reserva.setEstado(ESTADO_ACTIVA);
        reserva.setFechaReserva(LocalDateTime.now());

        Reserva guardada = reservaRepository.save(reserva);
        log.info("Reserva creada con ID {} en la posición {} de la fila", guardada.getId(), posicion);
        return guardada;
    }

    /** Regla de negocio: la posición es el número de reservas activas del libro + 1. */
    private int calcularPosicionEnFila(Long libroId) {
        return reservaRepository.findByLibroIdAndEstado(libroId, ESTADO_ACTIVA).size() + 1;
    }

    // ─────────────────────────── READ ───────────────────────────

    public List<Reserva> obtenerTodas() {
        log.info("Listando todas las reservas registradas");
        return reservaRepository.findAll();
    }

    public List<Reserva> listarPorUsuarioYEstado(Long usuarioId, String estado) {
        log.info("Buscando reservas del usuario ID: {} con estado: {}", usuarioId, estado);
        return reservaRepository.findByUsuarioIdAndEstado(usuarioId, estado);
    }

    /** Recupera la reserva y enriquece la respuesta con datos remotos de ms-usuario y ms-catalogo. */
    public ReservaResponseDto obtenerPorId(Long id) {
        log.info("Buscando reserva en la base de datos con ID: {}", id);

        Reserva reserva = buscarReservaOLanzar(id);

        UsuarioDto usuario;
        try {
            String urlUsuarios = "http://ms-usuario/api/v1/usuarios/id/" + reserva.getUsuarioId();
            log.info("Consultando datos de usuario al servicio externo: {}", urlUsuarios);
            usuario = restTemplate.getForObject(urlUsuarios, UsuarioDto.class);
        } catch (Exception e) {
            log.warn("No se pudo comunicar con ms-usuario para la reserva {}. Aplicando fallback.", id);
            usuario = new UsuarioDto();
            usuario.setId(reserva.getUsuarioId());
            usuario.setNombre("Usuario No disponible");
            usuario.setEmail("(Error de comunicación)");
        }

        LibroDto libro;
        try {
            String urlLibros = "http://ms-catalogo/api/v1/catalogo/libro/id/" + reserva.getLibroId();
            log.info("Consultando datos del libro al servicio externo: {}", urlLibros);
            libro = restTemplate.getForObject(urlLibros, LibroDto.class);
        } catch (Exception e) {
            log.warn("No se pudo comunicar con ms-catalogo para la reserva {}. Aplicando fallback.", id);
            libro = new LibroDto();
            libro.setId(reserva.getLibroId());
            libro.setTitulo("Libro No disponible");
            libro.setIsbn("(Error de comunicación)");
        }

        log.info("Armando respuesta consolidada para la reserva ID: {}", id);
        ReservaResponseDto response = new ReservaResponseDto();
        response.setId(reserva.getId());
        response.setFechaReserva(reserva.getFechaReserva());
        response.setPosicionFila(reserva.getPosicionFila());
        response.setEstado(reserva.getEstado());
        response.setUsuario(usuario);
        response.setLibro(libro);

        return response;
    }

    // ─────────────────────────── UPDATE ───────────────────────────

    /**
     * Actualiza el estado de una reserva.
     * Regla de negocio: una reserva COMPLETADA es terminal y no admite cambios posteriores.
     */
    public Reserva actualizarEstado(Long id, String nuevoEstado) {
        log.info("Actualizando estado de la reserva {} a {}", id, nuevoEstado);

        Reserva reserva = buscarReservaOLanzar(id);

        if ("COMPLETADA".equals(reserva.getEstado())) {
            log.warn("Intento de modificar la reserva {} que ya se encuentra COMPLETADA", id);
            throw new IllegalArgumentException(
                    "No se puede modificar una reserva que ya está COMPLETADA");
        }

        reserva.setEstado(nuevoEstado);
        Reserva actualizada = reservaRepository.save(reserva);
        log.info("Reserva {} actualizada correctamente al estado {}", id, nuevoEstado);
        return actualizada;
    }

    // ─────────────────────────── DELETE ───────────────────────────

    public void eliminarReserva(Long id) {
        log.info("Solicitud de eliminación de la reserva con ID: {}", id);
        Reserva reserva = buscarReservaOLanzar(id);
        reservaRepository.delete(reserva);
        log.info("Reserva {} eliminada correctamente", id);
    }

    // ─────────────────────────── Apoyo ───────────────────────────

    private Reserva buscarReservaOLanzar(Long id) {
        return reservaRepository.findById(id)
                .orElseThrow(() -> {
                    log.error("No se encontró la reserva con ID: {}", id);
                    return new EntityNotFoundException("La reserva con ID " + id + " no existe.");
                });
    }

    private void validarUsuarioExiste(Long usuarioId) {
        try {
            String url = "http://ms-usuario/api/v1/usuarios/id/" + usuarioId;
            UsuarioDto usuario = restTemplate.getForObject(url, UsuarioDto.class);
            if (usuario == null) {
                throw new EntityNotFoundException("El usuario con ID " + usuarioId + " no existe.");
            }
        } catch (EntityNotFoundException e) {
            throw e;
        } catch (Exception e) {
            log.error("Error validando usuario {} en ms-usuario: {}", usuarioId, e.getMessage());
            throw new EntityNotFoundException(
                    "No se pudo validar el usuario con ID " + usuarioId + " en ms-usuario.");
        }
    }

    private void validarLibroExiste(Long libroId) {
        try {
            String url = "http://ms-catalogo/api/v1/catalogo/libro/id/" + libroId;
            LibroDto libro = restTemplate.getForObject(url, LibroDto.class);
            if (libro == null) {
                throw new EntityNotFoundException("El libro con ID " + libroId + " no existe.");
            }
        } catch (EntityNotFoundException e) {
            throw e;
        } catch (Exception e) {
            log.error("Error validando libro {} en ms-catalogo: {}", libroId, e.getMessage());
            throw new EntityNotFoundException(
                    "No se pudo validar el libro con ID " + libroId + " en ms-catalogo.");
        }
    }
}