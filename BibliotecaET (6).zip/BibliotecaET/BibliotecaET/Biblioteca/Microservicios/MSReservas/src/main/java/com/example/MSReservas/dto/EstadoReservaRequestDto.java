package com.example.MSReservas.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import lombok.Data;

/**
 * DTO de entrada para la actualización del estado de una reserva.
 * El @Pattern garantiza que solo se acepten los estados válidos del dominio,
 * rechazando cualquier otro valor con un 400 antes de llegar al servicio.
 */
@Data
@Schema(description = "Nuevo estado que se asignará a la reserva")
public class EstadoReservaRequestDto {

    @NotBlank(message = "El estado es obligatorio")
    @Pattern(
            regexp = "ACTIVA|CANCELADA|COMPLETADA",
            message = "El estado debe ser ACTIVA, CANCELADA o COMPLETADA"
    )
    @Schema(description = "Estado de la reserva", example = "CANCELADA",
            allowableValues = {"ACTIVA", "CANCELADA", "COMPLETADA"})
    private String estado;
}