package com.example.MSReservas.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import lombok.Data;

/**
 * DTO de entrada para la creación de reservas.
 * Separa la entidad JPA del contrato público de la API: el cliente no puede
 * inyectar id, fechaReserva, posicionFila ni estado, ya que esos valores son
 * responsabilidad de la capa de servicio.
 */
@Data
@Schema(description = "Datos necesarios para registrar una nueva reserva")
public class ReservaRequestDto {

    @NotNull(message = "El ID del usuario es obligatorio")
    @Positive(message = "El ID del usuario debe ser un número positivo")
    @Schema(description = "Identificador del usuario que reserva", example = "1")
    private Long usuarioId;

    @NotNull(message = "El ID del libro es obligatorio")
    @Positive(message = "El ID del libro debe ser un número positivo")
    @Schema(description = "Identificador del libro a reservar", example = "1")
    private Long libroId;
}