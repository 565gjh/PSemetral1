package com.example.MSReservas.repository;

import com.example.MSReservas.model.Reserva;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface reservaRepository extends JpaRepository<Reserva, Long> {

    /** Spring Data combina ambas columnas con un AND lógico en la consulta SQL generada. */
    List<Reserva> findByUsuarioIdAndEstado(Long usuarioId, String estado);

    /** Soporta la regla de negocio que calcula la posición en la fila de espera. */
    List<Reserva> findByLibroIdAndEstado(Long libroId, String estado);

    /** Soporta la regla que impide reservas activas duplicadas del mismo usuario sobre el mismo libro. */
    boolean existsByUsuarioIdAndLibroIdAndEstado(Long usuarioId, Long libroId, String estado);
}