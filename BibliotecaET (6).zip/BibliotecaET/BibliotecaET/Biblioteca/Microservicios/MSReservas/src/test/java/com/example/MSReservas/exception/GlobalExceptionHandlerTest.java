package com.example.MSReservas.exception;

import jakarta.persistence.EntityNotFoundException;
import org.junit.jupiter.api.Test;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

class GlobalExceptionHandlerTest {

    private final GlobalExceptionHandler handler = new GlobalExceptionHandler();

    @Test
    void cuandoManejarEntityNotFoundException_deberiaRetornar404ConDetalles() {
        // GIVEN: Excepción específica de recurso no encontrado
        EntityNotFoundException exception = new EntityNotFoundException("El usuario con ID 99 no existe");

        // WHEN: Invocamos el método handleNotFound
        ResponseEntity<Map<String, Object>> respuesta = handler.handleNotFound(exception);

        // THEN: Verificamos que responda con 404 y su estructura real
        assertNotNull(respuesta);
        assertEquals(HttpStatus.NOT_FOUND, respuesta.getStatusCode());

        Map<String, Object> body = respuesta.getBody();
        assertNotNull(body);
        assertEquals(HttpStatus.NOT_FOUND.value(), body.get("status"));
        assertEquals("El usuario con ID 99 no existe", body.get("error")); // Tu método inyecta ex.getMessage() aquí
        assertNotNull(body.get("timestamp"));
    }

    @Test
    void cuandoManejarIllegalArgumentException_deberiaRetornar400() {
        // GIVEN: Excepción de regla de negocio
        IllegalArgumentException exception = new IllegalArgumentException("Reserva duplicada");

        // WHEN: Invocamos el método handleReglaNegocio
        ResponseEntity<Map<String, Object>> respuesta = handler.handleReglaNegocio(exception);

        // THEN: Verificamos respuesta 400 Bad Request
        assertNotNull(respuesta);
        assertEquals(HttpStatus.BAD_REQUEST, respuesta.getStatusCode());
        assertEquals("Reserva duplicada", respuesta.getBody().get("error"));
    }

    @Test
    void cuandoManejarExceptionGenerica_deberiaRetornar500ConMensajeFijo() {
        // GIVEN: Una excepción genérica cualquiera
        Exception exception = new Exception("Error de conexión interno");

        // WHEN: Invocamos el manejador genérico
        ResponseEntity<Map<String, Object>> respuesta = handler.handleGenericException(exception);

        // THEN: Verificamos respuesta 500 con el string exacto de tu handler
        assertNotNull(respuesta);
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, respuesta.getStatusCode());

        Map<String, Object> body = respuesta.getBody();
        assertNotNull(body);
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR.value(), body.get("status"));
        assertEquals("Ocurrió un error interno en el servidor de reservas", body.get("error"));
        assertNotNull(body.get("timestamp"));
    }
}