package com.example.MSReservas.service;

import com.example.MSReservas.dto.LibroDto;
import com.example.MSReservas.dto.ReservaResponseDto;
import com.example.MSReservas.dto.UsuarioDto;
import com.example.MSReservas.model.Reserva;
import com.example.MSReservas.repository.reservaRepository;
import jakarta.persistence.EntityNotFoundException;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.web.client.RestTemplate;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class reservaServiceTest {

    @Mock
    private reservaRepository reservaRepository;

    @Mock
    private RestTemplate restTemplate;

    @InjectMocks
    private reservaService reservaService;

    @Test
    @DisplayName("Debería retornar DTO completo cuando el ID de la reserva existe de forma exitosa")
    public void cuandoObtenerPorIdEsExitoso_debeRetornarDtoCompleto() {
        Long reservaId = 1L;

        Reserva reservaMock = new Reserva();
        reservaMock.setId(reservaId);
        reservaMock.setUsuarioId(10L);
        reservaMock.setLibroId(20L);
        reservaMock.setFechaReserva(java.time.LocalDateTime.now());
        reservaMock.setPosicionFila(1);
        reservaMock.setEstado("ACTIVA");

        UsuarioDto usuarioMock = new UsuarioDto();
        usuarioMock.setId(10L);
        usuarioMock.setNombre("Juan Pérez");
        usuarioMock.setEmail("juan@example.com");

        LibroDto libroMock = new LibroDto();
        libroMock.setId(20L);
        libroMock.setTitulo("Cien años de soledad");
        libroMock.setIsbn("978-3-16-148410-0");

        Mockito.when(reservaRepository.findById(reservaId)).thenReturn(Optional.of(reservaMock));

        Mockito.when(restTemplate.getForObject("http://ms-usuario/api/v1/usuarios/id/10", UsuarioDto.class))
                .thenReturn(usuarioMock);

        Mockito.when(restTemplate.getForObject("http://ms-catalogo/api/v1/catalogo/libro/id/20", LibroDto.class))
                .thenReturn(libroMock);

        ReservaResponseDto resultado = reservaService.obtenerPorId(reservaId);

        assertNotNull(resultado, "La respuesta no debería ser nula");
        assertEquals(reservaId, resultado.getId());
        assertEquals("ACTIVA", resultado.getEstado());

        assertNotNull(resultado.getUsuario());
        assertEquals("Juan Pérez", resultado.getUsuario().getNombre());

        assertNotNull(resultado.getLibro());
        assertEquals("Cien años de soledad", resultado.getLibro().getTitulo());
    }

    @Test
    @DisplayName("Debería lanzar EntityNotFoundException cuando la reserva consultada no existe")
    public void buscarPorIdInexistenteLanzaExcepcion() {
        Long idInexistente = 999L;

        // Simulamos que al buscar el ID 999 la base de datos retorna un Optional vacío
        Mockito.when(reservaRepository.findById(idInexistente)).thenReturn(Optional.empty());

        // Verificamos que el método de tu servicio lance la excepción controlada que agregamos
        assertThrows(EntityNotFoundException.class, () -> {
            reservaService.obtenerPorId(idInexistente);
        });

        // Verificamos que se interactuó con el repositorio exactamente una vez
        verify(reservaRepository, times(1)).findById(idInexistente);
    }
}