package com.example.MSReservas.security.jwt;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.security.Keys;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.test.util.ReflectionTestUtils;

import javax.crypto.SecretKey;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

class Jwtservicetest {

    private JwtService jwtService;
    private String rawSecret;

    @BeforeEach
    void setUp() {
        jwtService = new JwtService();
        // Generamos una clave de prueba de 256 bits segura para la librería
        SecretKey key = Keys.secretKeyFor(SignatureAlgorithm.HS256);
        rawSecret = java.util.Base64.getEncoder().encodeToString(key.getEncoded());

        // Inyectamos el secret simulando el @Value("${jwt.secret}")
        ReflectionTestUtils.setField(jwtService, "secretKey", rawSecret);
    }

    @Test
    void testTokenValid_Exitoso() {
        Map<String, Object> claims = new HashMap<>();
        claims.put("rol", "ADMIN");

        String token = Jwts.builder()
                .claims(claims)
                .subject("cristobal")
                .issuedAt(new Date())
                .expiration(new Date(System.currentTimeMillis() + 60000))
                .signWith(Keys.hmacShaKeyFor(rawSecret.getBytes()))
                .compact();

        assertTrue(jwtService.isTokenValid(token));
        assertEquals("cristobal", jwtService.extractUsername(token));
        assertEquals("ADMIN", jwtService.extractRole(token));
    }

    @Test
    void testTokenInvalido() {
        assertFalse(jwtService.isTokenValid("token.falso.invalido"));
        assertNull(jwtService.extractUsername("token.falso.invalido"));
        assertNull(jwtService.extractRole("token.falso.invalido"));
    }
}