package com.example.MSPrestamo.service;


import com.example.MSPrestamo.client.CatalogoClient;
import com.example.MSPrestamo.client.UsuarioClient;
import com.example.MSPrestamo.model.*;
import com.example.MSPrestamo.repository.PrestamoRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;
@Slf4j
@Service
public class PrestamoService {

    @Autowired
    private UsuarioClient usuarioClient;

    @Autowired
    private CatalogoClient catalogoClient;

    @Autowired
    private PrestamoRepository prestamoRepository;

    public List<Prestamo> obtenerTodosLosPrestamos() {
        return prestamoRepository.findAll();
    }
    // 👈 Cambiamos el tipo de authId a Long
    public void procesarPrestamoDirecto(Long usuarioId, Long libroId) {
        log.info("Iniciando proceso de préstamo directo");

        // 1. Validar el usuario en ms-usuarios
        UsuarioDTO usuario;
        try {
            usuario = usuarioClient.obtenerUsuario(usuarioId);
        } catch (Exception e) {
            throw new RuntimeException("El usuario no existe o la comunicación falló.");
        }

        // 2. Validar el libro en ms-catalogo
        LibroResponseDTO libro;
        try {
            libro = catalogoClient.obtenerLibro(libroId);
        } catch (Exception e) {
            throw new RuntimeException("El libro solicitado no existe en el catálogo.");
        }

        if (libro.getStockDisponible() <= 0) {
            throw new RuntimeException("Stock agotado para el libro: " + libro.getTitulo());
        }

        // 3. Guardar el préstamo
        Prestamo nuevoPrestamo = new Prestamo();
        nuevoPrestamo.setUsuarioId(usuarioId);
        nuevoPrestamo.setLibroId(libroId);
        nuevoPrestamo.setFechaPrestamo(LocalDate.now());
        nuevoPrestamo.setFechaDevolucionMaxima(LocalDate.now().plusDays(7));
        nuevoPrestamo.setEstado("ACTIVO");

        prestamoRepository.save(nuevoPrestamo);
        log.info("Préstamo guardado con éxito en la base de datos.");

        // 4. 🚀 DISMINUIR EL STOCK EN EL CATÁLOGO
        try {
            catalogoClient.descontarStockLibro(libroId);
            log.info("Stock disminuido con éxito para el libro ID: {}", libroId);
        } catch (Exception e) {
            // NOTA: En producción aquí aplicarías un patrón "Saga" o compensación si quieres borrar el préstamo si esto falla.
            throw new RuntimeException("El préstamo se registró pero no se pudo actualizar el inventario.");
        }
    }
}