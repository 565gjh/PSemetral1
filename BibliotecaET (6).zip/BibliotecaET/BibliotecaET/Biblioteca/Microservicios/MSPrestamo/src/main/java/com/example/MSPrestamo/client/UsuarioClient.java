package com.example.MSPrestamo.client;

import com.example.MSPrestamo.model.UsuarioDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.server.ResponseStatusException;

@Component
public class UsuarioClient {

    @Autowired
    private WebClient.Builder webClientBuilder;

    public UsuarioDTO obtenerUsuario(Long usuarioId) {
        return webClientBuilder.build()
                .get()
                .uri("http://ms-usuario/api/v1/usuarios/id/" + usuarioId)
                .retrieve()
                .onStatus(status -> status.value() == 404, response ->
                        reactor.core.publisher.Mono.error(new ResponseStatusException(
                                HttpStatus.NOT_FOUND, "Usuario no encontrado")))
                .bodyToMono(UsuarioDTO.class)
                .block();
    }
}