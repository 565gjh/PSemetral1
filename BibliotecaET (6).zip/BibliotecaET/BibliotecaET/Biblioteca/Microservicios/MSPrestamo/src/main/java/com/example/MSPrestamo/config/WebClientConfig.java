package com.example.MSPrestamo.config;

import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpHeaders;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import org.springframework.web.reactive.function.client.ClientRequest;
import org.springframework.web.reactive.function.client.ExchangeFilterFunction;
import org.springframework.web.reactive.function.client.WebClient;

@Configuration
public class WebClientConfig {

    @Bean
    @LoadBalanced
    public WebClient.Builder webClientBuilder() {
        return WebClient.builder()
                .filter(reenviarTokenFilter());
    }

    private ExchangeFilterFunction reenviarTokenFilter() {
        return (request, next) -> {
            ServletRequestAttributes attributes = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();

            if (attributes != null) {
                String authHeader = attributes.getRequest().getHeader(HttpHeaders.AUTHORIZATION);

                // 🚨 CÁMARA 1: Vemos si logró sacar el token
                System.out.println("🔍 [Filtro WebClient] Token capturado: " + authHeader);

                if (authHeader != null) {
                    ClientRequest nuevaRequest = ClientRequest.from(request)
                            .header(HttpHeaders.AUTHORIZATION, authHeader)
                            .build();
                    return next.exchange(nuevaRequest);
                } else {
                    // 🚨 CÁMARA 2: Entró a la petición, pero el header venía vacío
                    System.out.println("⚠️ [Filtro WebClient] ALERTA: El header de autorización es NULL.");
                }
            } else {
                // 🚨 CÁMARA 3: Problema de Hilos (Threads)
                System.out.println("⚠️ [Filtro WebClient] ALERTA: 'attributes' es NULL. Se perdió el contexto de la petición original.");
            }

            return next.exchange(request);
        };
    }
}