package com.example.MSPrestamo.controller;

import com.example.MSPrestamo.model.Prestamo;
import com.example.MSPrestamo.service.PrestamoService;
import io.swagger.v3.oas.annotations.Operation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/v1/prestamos")
public class PrestamoController {

    @Autowired
    private PrestamoService prestamoService;

    @GetMapping
    public ResponseEntity<List<Prestamo>> listarTodos() {
        List<Prestamo> lista = prestamoService.obtenerTodosLosPrestamos();

        if (lista.isEmpty()) {
            return ResponseEntity.noContent().build();
        }

        return ResponseEntity.ok(lista);
    }


    @Operation(summary = "Registrar nuevo préstamo", description = "Verifica la disponibilidad del libro en ms-catalogo y el estado del usuario en ms-usuario antes de emitir la orden")
    @PostMapping("/crear")
    public ResponseEntity<?> crearPrestamo(
            @RequestBody Map<String, Long> body) {

        try {
            // Extraemos los datos numéricos sin necesidad de convertirlos
            Long usuarioId = body.get("usuarioId");
            Long libroId = body.get("libroId");

            prestamoService.procesarPrestamoDirecto(usuarioId, libroId);
            return ResponseEntity.status(HttpStatus.CREATED)
                    .body(Map.of("mensaje", "Préstamo registrado exitosamente"));

        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(Map.of("error", e.getMessage()));
        }
    }
}