package com.example.MSPrestamo.service;

import com.example.MSPrestamo.client.CatalogoClient;
import com.example.MSPrestamo.client.UsuarioClient;
import com.example.MSPrestamo.model.LibroResponseDTO;
import com.example.MSPrestamo.model.Prestamo;
import com.example.MSPrestamo.model.UsuarioDTO;
import com.example.MSPrestamo.repository.PrestamoRepository;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.mockito.ArgumentMatchers.any;

@ExtendWith(MockitoExtension.class)
public class PrestamoServiceTest {

    @Mock
    private UsuarioClient usuarioClient;

    @Mock
    private CatalogoClient catalogoClient;

    @Mock
    private PrestamoRepository prestamoRepository;

    @InjectMocks
    private PrestamoService prestamoService;

    @Test
    void cuandoProcesarPrestamoEsExitoso_entoncesGuardaPrestamoYDescuentaStock() {
        // GIVEN
        Long usuarioId = 1L;
        Long libroId = 100L;

        UsuarioDTO usuarioMock = new UsuarioDTO();
        LibroResponseDTO libroMock = new LibroResponseDTO();
        libroMock.setStockDisponible(5);
        libroMock.setTitulo("Java Avanzado");

        Mockito.when(usuarioClient.obtenerUsuario(usuarioId)).thenReturn(usuarioMock);
        Mockito.when(catalogoClient.obtenerLibro(libroId)).thenReturn(libroMock);

        // WHEN
        prestamoService.procesarPrestamoDirecto(usuarioId, libroId);

        // THEN
        Mockito.verify(prestamoRepository, Mockito.times(1)).save(any(Prestamo.class));
        Mockito.verify(catalogoClient, Mockito.times(1)).descontarStockLibro(libroId);
    }

    @Test
    void cuandoLibroNoTieneStock_entoncesLanzaRuntimeExceptionYNoGuarda() {
        // GIVEN
        Long usuarioId = 1L;
        Long libroId = 100L;

        UsuarioDTO usuarioMock = new UsuarioDTO();
        LibroResponseDTO libroMock = new LibroResponseDTO();
        libroMock.setStockDisponible(0); // SIN STOCK
        libroMock.setTitulo("Java Agotado");

        Mockito.when(usuarioClient.obtenerUsuario(usuarioId)).thenReturn(usuarioMock);
        Mockito.when(catalogoClient.obtenerLibro(libroId)).thenReturn(libroMock);

        // WHEN & THEN
        RuntimeException excepcion = Assertions.assertThrows(RuntimeException.class, () -> {
            prestamoService.procesarPrestamoDirecto(usuarioId, libroId);
        });

        Assertions.assertTrue(excepcion.getMessage().contains("Stock agotado"));
        Mockito.verify(prestamoRepository, Mockito.never()).save(any(Prestamo.class));
    }
}