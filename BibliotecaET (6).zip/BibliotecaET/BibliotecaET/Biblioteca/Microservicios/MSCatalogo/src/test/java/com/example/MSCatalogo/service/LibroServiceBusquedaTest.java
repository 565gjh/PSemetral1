package com.example.MSCatalogo.service;

import com.example.MSCatalogo.client.InventarioClient;
import com.example.MSCatalogo.exception.ResourceNotFoundException;
import com.example.MSCatalogo.model.Autor;
import com.example.MSCatalogo.model.Categoria;
import com.example.MSCatalogo.model.Libro;
import com.example.MSCatalogo.model.LibroResponseDTO;
import com.example.MSCatalogo.repository.LibroRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class LibroServiceBusquedaTest {

    @Mock
    private LibroRepository libroRepository;

    @Mock
    private InventarioClient inventarioClient; // Mock necesario para el método con stock

    @InjectMocks
    private LibroService libroService;

    private Autor autorFake;
    private Categoria categoriaFake;
    private Libro libroFake;

    @BeforeEach
    void setUp() {
        autorFake = new Autor();
        autorFake.setId(7L);
        autorFake.setNombre("Gabriel Garcia Marquez");

        categoriaFake = new Categoria();
        categoriaFake.setId(2L);
        categoriaFake.setNombre("Realismo Magico");

        libroFake = new Libro();
        libroFake.setId(101L);
        libroFake.setTitulo("Cien Anos de Soledad");
        libroFake.setAutor(autorFake);
        libroFake.setCategoria(categoriaFake);
    }

    @Test
    @DisplayName("Debería retornar lista de DTOs cuando se busca por ID de Autor")
    public void cuandoBuscarPorAutor_deberiaRetornarListaDeLibrosDto() {
        List<Libro> listaLibrosFake = new ArrayList<>();
        listaLibrosFake.add(libroFake);

        when(libroRepository.findByAutorId(7L)).thenReturn(listaLibrosFake);

        List<LibroResponseDTO> resultado = libroService.obtenerPorAutor(7L);

        assertNotNull(resultado, "La lista de respuesta no debería ser nula");
        assertEquals(1, resultado.size());
        assertEquals("Cien Anos de Soledad", resultado.get(0).getTitulo());

        verify(libroRepository, times(1)).findByAutorId(7L);
    }

    @Test
    @DisplayName("Debería mapear stock correctamente cuando el libro existe e invoca al cliente Feign")
    public void cuandoObtenerLibroConStock_DeberiaRetornarDtoConStock() {
        // Simular que el repositorio encuentra el libro y el cliente Feign retorna 15 unidades de stock
        when(libroRepository.findById(101L)).thenReturn(Optional.of(libroFake));
        when(inventarioClient.obtenerStock(101L)).thenReturn(15);

        LibroResponseDTO resultado = libroService.obtenerLibroConStock(101L);

        assertNotNull(resultado);
        assertEquals(101L, resultado.getLibroId());
        assertEquals("Cien Anos de Soledad", resultado.getTitulo());
        assertEquals(15, resultado.getStockDisponible(), "El stock debe ser el devuelto por el cliente externo");

        verify(libroRepository, times(1)).findById(101L);
        verify(inventarioClient, times(1)).obtenerStock(101L);
    }

    @Test
    @DisplayName("Debería lanzar ResourceNotFoundException si el ID del libro no existe en catálogo")
    public void cuandoObtenerLibroInexistente_DeberiaLanzarResourceNotFoundException() {
        // Simular que el libro no existe en la base de datos
        when(libroRepository.findById(999L)).thenReturn(Optional.empty());

        assertThrows(ResourceNotFoundException.class, () -> {
            libroService.obtenerLibroConStock(999L);
        });

        // Asegurar que nunca intente llamar al inventario si el libro no existe
        verify(libroRepository, times(1)).findById(999L);
        verifyNoInteractions(inventarioClient);
    }
}