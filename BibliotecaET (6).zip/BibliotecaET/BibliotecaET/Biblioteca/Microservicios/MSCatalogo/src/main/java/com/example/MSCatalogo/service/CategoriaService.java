package com.example.MSCatalogo.service;

import com.example.MSCatalogo.model.Categoria;
import com.example.MSCatalogo.repository.CategoriaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CategoriaService {

    @Autowired
    private CategoriaRepository categoriaRepository;


    public Categoria guardarCategoria(Categoria categoria) {
        // Las validaciones de campos únicos (como que no se repita el nombre de la categoría)
        // las maneja JPA automáticamente si configuraste el @Column(unique = true)
        return categoriaRepository.save(categoria);
    }

    public List<Categoria> obtenerTodas() {
        return categoriaRepository.findAll();
    }

    public Categoria obtenerPorId(Long id) {
        return categoriaRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Categoría no encontrada"));
    }

    // Aquí podrías agregar métodos para crear, actualizar o eliminar categorías
}