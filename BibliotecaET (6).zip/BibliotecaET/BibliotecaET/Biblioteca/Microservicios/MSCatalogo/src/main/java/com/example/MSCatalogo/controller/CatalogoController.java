package com.example.MSCatalogo.controller;

import com.example.MSCatalogo.model.*;
import com.example.MSCatalogo.service.AutorService;
import com.example.MSCatalogo.service.CategoriaService;
import com.example.MSCatalogo.service.LibroService;
import io.swagger.v3.oas.annotations.Operation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/v1/catalogo")
@Slf4j
public class CatalogoController {

    @Autowired
    private LibroService libroService;

    @Autowired
    private AutorService autorService;

    @Autowired
    private CategoriaService categoriaService;

    // 🌟 AGREGAR ESTO EN TU CONTROLLER
    @Operation(summary = "Obtener libros por nacionalidad del autor", description = "Filtra el catálogo devolviendo los libros cuyo autor coincida con la nacionalidad especificada")
    @GetMapping("/libro/autor/nacionalidad/{nacionalidad}")
    @PreAuthorize("hasAnyRole('ADMIN', 'USUARIO', 'TRABAJADOR')")
    public ResponseEntity<List<LibroResponseDTO>> obtenerPorNacionalidad(@PathVariable String nacionalidad) {
        log.info("Buscando libros con autores de nacionalidad: {}", nacionalidad);
        return ResponseEntity.ok(libroService.obtenerPorNacionalidadAutor(nacionalidad));
    }

    @Operation(summary = "Obtener todos los libros", description = "Devuelve la lista completa de libros con stock inicializado en cero para vistas rápidas")
    @GetMapping
    @PreAuthorize("hasAnyRole('ADMIN', 'USUARIO', 'TRABAJADOR')")
    public ResponseEntity<List<LibroResponseDTO>> obtenerTodos() {
        log.info("Solicitando la lista completa de libros");
        return ResponseEntity.ok(libroService.obtenerTodos());
    }

    @Operation(summary = "Obtener libro por ID", description = "Busca un libro en el catálogo y consulta su stock en tiempo real en ms-inventario")
    @GetMapping("/libro/id/{id}")
    public ResponseEntity<LibroResponseDTO> obtenerPorId(@PathVariable Long id) {
        log.info("Buscando libro con id: {}", id);
        return ResponseEntity.ok(libroService.obtenerLibroConStock(id));
    }

    @Operation(summary = "Descontar stock de un libro", description = "Valida la existencia del libro y dispara el descuento hacia el servicio remoto de inventario")
    @PutMapping("/libro/{id}/descontar")
    public ResponseEntity<?> descontarStock(@PathVariable Long id) {
        log.info("Solicitando descuento de stock para libro id: {}", id);
        libroService.descontarStock(id);
        return ResponseEntity.ok(Map.of("mensaje", "Stock descontado exitosamente"));
    }

    @Operation(summary = "Crear un nuevo libro", description = "Valida el autor y la categoría antes de persistir el nuevo registro en el catálogo")
    @PostMapping("/libro")
    @PreAuthorize("hasAnyRole('ADMIN', 'USUARIO', 'TRABAJADOR')")
    public ResponseEntity<LibroResponseDTO> crearLibro(@RequestBody LibroRequestDTO request) {
        log.info("Procesando la creación del libro: {}", request.getTitulo());
        LibroResponseDTO nuevoLibro = libroService.guardarLibro(request);
        return ResponseEntity.status(HttpStatus.CREATED).body(nuevoLibro);
    }

    @Operation(summary = "Registrar un autor", description = "Añade un nuevo autor al catálogo para el posterior enlazado de libros")
    @PostMapping("/autor")
    @PreAuthorize("hasAnyRole('ADMIN', 'USUARIO', 'TRABAJADOR')")
    public ResponseEntity<Autor> crearAutor(@RequestBody Autor autor) {
        return ResponseEntity.status(HttpStatus.CREATED).body(autorService.guardarAutor(autor));
    }

    @Operation(summary = "Registrar una categoría", description = "Añade una nueva categoría o género literario al sistema")
    @PostMapping("/categoria")
    @PreAuthorize("hasAnyRole('ADMIN', 'USUARIO', 'TRABAJADOR')")
    public ResponseEntity<Categoria> crearCategoria(@RequestBody Categoria categoria) {
        return ResponseEntity.status(HttpStatus.CREATED).body(categoriaService.guardarCategoria(categoria));
    }
}