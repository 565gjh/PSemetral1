package com.example.MSCatalogo.config;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
@EnableAutoConfiguration(exclude = {
        org.springdoc.core.configuration.SpringDocHateoasConfiguration.class})
public class SwaggerConfig {

    @Bean
    public OpenAPI customOpenAPI() {
        return new OpenAPI()
                .info(new Info()
                        .title("MSCatalogo API - Catálogo de Libros")
                        .version("1.0")
                        .description("Gestión del catálogo bibliográfico, títulos, autores, categorías e información conceptual de los textos.")
                );
    }
}