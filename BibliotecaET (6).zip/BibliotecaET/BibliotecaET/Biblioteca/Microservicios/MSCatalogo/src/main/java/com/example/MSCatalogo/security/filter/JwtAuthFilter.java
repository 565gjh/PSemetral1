package com.example.MSCatalogo.security.filter;


import com.example.MSCatalogo.security.jwt.JwtService;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
import java.util.List;

@Component
public class JwtAuthFilter extends OncePerRequestFilter {

    private final JwtService jwtService;

    public JwtAuthFilter(JwtService jwtService) {
        this.jwtService = jwtService;
    }

    @Override
    protected void doFilterInternal(HttpServletRequest request,
                                    HttpServletResponse response,
                                    FilterChain filterChain) throws ServletException, IOException {

        System.out.println("🛡️ [Filtro Catálogo] Entrando al filtro para la ruta: " + request.getRequestURI());
        String authHeader = request.getHeader("Authorization");
        System.out.println("🛡️ [Filtro Catálogo] Header Authorization recibido: " + authHeader);

        if (authHeader == null || !authHeader.startsWith("Bearer ")) {
            System.out.println("❌ [Filtro Catálogo] No se encontró token válido o falta el prefijo 'Bearer'. Ignorando...");
            filterChain.doFilter(request, response);
            return;
        }

        try {
            String token = authHeader.substring(7);

            // 📍 LOG 1: Verificar si pasa la validación matemática del token
            boolean esValido = jwtService.isTokenValid(token);
            System.out.println("🕵️‍♂️ [Filtro Catálogo] ¿El token es estructuralmente válido?: " + esValido);

            if (esValido) {
                String username = jwtService.extractUsername(token);
                String role = jwtService.extractRole(token);

                // 📍 LOG 2: Ver los datos extraídos del JWT en bruto
                System.out.println("✅ [Filtro Catálogo] Token descifrado. Usuario extraído: [" + username + "] | Rol extraído: [" + role + "]");

                List<GrantedAuthority> authorities = List.of(
                        new SimpleGrantedAuthority("ROLE_" + role)
                );

                // 📍 LOG 3: Ver cómo se transformó para Spring Security
                System.out.println("🏷️ [Filtro Catálogo] Autoridades asignadas a Spring: " + authorities);

                UsernamePasswordAuthenticationToken authToken =
                        new UsernamePasswordAuthenticationToken(username, null, authorities);

                authToken.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));

                // 🔑 PASO CRÍTICO: Guardar en el contexto
                SecurityContextHolder.getContext().setAuthentication(authToken);

                // 📍 LOG 4: Confirmar que Spring Security ya tiene al usuario guardado
                System.out.println("🚀 [Filtro Catálogo] ¡Éxito! Usuario establecido en el SecurityContextHolder de Spring.");
            } else {
                System.out.println("⚠️ [Filtro Catálogo] El método jwtService.isTokenValid(token) devolvió FALSE.");
            }
        } catch (Exception e) {
            System.out.println("💥 [Filtro Catálogo] ERROR AL VALIDAR EL TOKEN: " + e.getMessage());
            e.printStackTrace();
        }

        // 📍 LOG 5: Saber que salimos del bloque de seguridad listos para ir al controlador
        System.out.println("🚪 [Filtro Catálogo] Saliendo del filtro. Pasando el request a la cadena principal...");
        filterChain.doFilter(request, response);
    }
}