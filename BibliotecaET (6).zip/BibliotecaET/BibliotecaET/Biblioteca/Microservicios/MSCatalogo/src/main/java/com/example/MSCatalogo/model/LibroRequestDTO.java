package com.example.MSCatalogo.model;

import lombok.Data;

@Data
public class LibroRequestDTO {
    private String titulo;
    private Long idAutor;      // Solo pedimos el ID del autor
    private Long idCategoria;  // Solo pedimos el ID de la categoría
}