package com.example.MSCatalogo.repository;

import com.example.MSCatalogo.model.Libro;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface LibroRepository extends JpaRepository<Libro, Long> {
    List<Libro> findByCategoriaId(Long categoriaId);
    List<Libro> findByAutorId(Long autorId);

    // 🌟 AGREGAR ESTO: Spring camina por la entidad 'autor' y filtra por su 'nacionalidad'
    List<Libro> findByAutorNacionalidad(String nacionalidad);
}