package com.example.MSCatalogo.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Entity
@Table(name = "libros")
public class Libro {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, length = 150)
    private String titulo;

    @Column(nullable = false, unique = true, length = 20)
    private String isbn;

    // COMUNICACIÓN JPA: Muchos libros pertenecen a UN Autor
    // optional = false obliga a que todo libro tenga un autor real (genera INNER JOIN eficiente)
    @ManyToOne(fetch = FetchType.EAGER, optional = false)
    @JoinColumn(name = "autor_id", nullable = false)
    @JsonIgnoreProperties("libros")
    private Autor autor;

    // COMUNICACIÓN JPA: Muchos libros pertenecen a UNA Categoría
    @ManyToOne(fetch = FetchType.EAGER, optional = false)
    @JoinColumn(name = "categoria_id", nullable = false)
    @JsonIgnoreProperties("libros")
    private Categoria categoria;




}