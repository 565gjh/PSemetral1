package com.example.MSCatalogo.service;

import com.example.MSCatalogo.model.Autor;
import com.example.MSCatalogo.repository.AutorRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AutorService {

    @Autowired
    private AutorRepository autorRepository;

    /**
     * Guarda un nuevo autor en la base de datos
     */
    public Autor guardarAutor(Autor autor) {
        // Aquí podrías agregar validaciones de negocio extra si lo deseas
        // (ej. verificar que el nombre no venga vacío)
        return autorRepository.save(autor);
    }

    public List<Autor> obtenerTodos() {
        return autorRepository.findAll();
    }

    public Autor obtenerPorId(Long id) {
        return autorRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Autor no encontrado con el ID: " + id));
    }
}