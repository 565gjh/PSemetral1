package com.example.MSCatalogo.model;

import lombok.Data;

@Data
public class LibroResponseDTO {
    private Long libroId;
    private String titulo;
    private String autor;       // Podríamos sacar el nombre del autor de la relación
    private String categoria;   // Podríamos sacar el nombre de la categoría
    private int stockDisponible; // 👈 ¡Vuelve aquí!
}