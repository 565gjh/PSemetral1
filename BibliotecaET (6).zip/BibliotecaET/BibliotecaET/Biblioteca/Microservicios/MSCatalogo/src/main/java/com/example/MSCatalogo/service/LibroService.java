package com.example.MSCatalogo.service;

import com.example.MSCatalogo.client.InventarioClient;
import com.example.MSCatalogo.exception.ResourceNotFoundException;
import com.example.MSCatalogo.model.*;
import com.example.MSCatalogo.repository.AutorRepository;
import com.example.MSCatalogo.repository.CategoriaRepository;
import com.example.MSCatalogo.repository.LibroRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@Service
public class LibroService {

    @Autowired
    private LibroRepository libroRepository;

    @Autowired
    private CategoriaRepository categoriaRepository;

    @Autowired
    private InventarioClient inventarioClient;

    @Autowired
    private AutorRepository autorRepository;

    public List<LibroResponseDTO> obtenerTodos() {
        List<Libro> libros = libroRepository.findAll();
        return libros.stream()
                .map(libro -> mapearADto(libro, 0))
                .collect(Collectors.toList());
    }

    public LibroResponseDTO guardarLibro(LibroRequestDTO request) {
        // A. Validar y obtener el Autor usando la excepción personalizada de negocio (Evita el 500)
        Autor autor = autorRepository.findById(request.getIdAutor())
                .orElseThrow(() -> new ResourceNotFoundException("No se puede crear el libro. El Autor con ID " + request.getIdAutor() + " no existe."));

        // B. Validar y obtener la Categoría usando la excepción personalizada de negocio
        Categoria categoria = categoriaRepository.findById(request.getIdCategoria())
                .orElseThrow(() -> new ResourceNotFoundException("No se puede crear el libro. La Categoría con ID " + request.getIdCategoria() + " no existe."));

        // C. Construir la Entidad Libro original para la Base de Datos
        Libro nuevoLibro = new Libro();
        nuevoLibro.setTitulo(request.getTitulo());
        nuevoLibro.setAutor(autor);
        nuevoLibro.setCategoria(categoria);

        // D. Guardar en la base de datos de ms-catalogo
        Libro libroGuardado = libroRepository.save(nuevoLibro);

        // E. Retornar el DTO de respuesta.
        return mapearADto(libroGuardado, 0);
    }

    public LibroResponseDTO obtenerLibroConStock(Long idLibro) {
        Libro libro = libroRepository.findById(idLibro)
                .orElseThrow(() -> new ResourceNotFoundException("Libro no encontrado con id: " + idLibro));
        int stock = inventarioClient.obtenerStock(idLibro);
        return mapearADto(libro, stock);
    }

    public List<LibroResponseDTO> obtenerPorCategoria(Long idCategoria) {
        List<Libro> libros = libroRepository.findByCategoriaId(idCategoria);
        return libros.stream()
                .map(libro -> mapearADto(libro, 0))
                .collect(Collectors.toList());
    }

    public List<LibroResponseDTO> obtenerPorAutor(Long idAutor) {
        List<Libro> libros = libroRepository.findByAutorId(idAutor);
        return libros.stream()
                .map(libro -> mapearADto(libro, 0))
                .collect(Collectors.toList());
    }

    public void descontarStock(Long idLibro) {
        if (!libroRepository.existsById(idLibro)) {
            throw new ResourceNotFoundException("El libro solicitado no existe en el catálogo.");
        }
        inventarioClient.descontarStock(idLibro);
    }

    private LibroResponseDTO mapearADto(Libro libro, int stock) {
        LibroResponseDTO dto = new LibroResponseDTO();
        dto.setLibroId(libro.getId());
        dto.setTitulo(libro.getTitulo());
        dto.setAutor(libro.getAutor().getNombre());
        dto.setCategoria(libro.getCategoria().getNombre());
        dto.setStockDisponible(stock);
        return dto;
    }
    // 🌟 AGREGAR ESTO AL FINAL DE LA CLASE (Arriba de mapearADto)
    public List<LibroResponseDTO> obtenerPorNacionalidadAutor(String nacionalidad) {
        List<Libro> libros = libroRepository.findByAutorNacionalidad(nacionalidad);
        return libros.stream()
                .map(libro -> mapearADto(libro, 0)) // Usa tu mapeador existente
                .collect(Collectors.toList());
    }
}