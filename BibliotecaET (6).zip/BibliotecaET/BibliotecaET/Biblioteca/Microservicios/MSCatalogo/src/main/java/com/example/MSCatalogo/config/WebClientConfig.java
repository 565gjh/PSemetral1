package com.example.MSCatalogo.config;

import org.apache.catalina.Server;
import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpHeaders;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import org.springframework.web.reactive.function.client.ClientRequest;
import org.springframework.web.reactive.function.client.ExchangeFilterFunction;
import org.springframework.web.reactive.function.client.WebClient;

@Configuration
public class WebClientConfig {

    @Bean
    @LoadBalanced  // Descomenta esto si estás usando Eureka Server
    public WebClient.Builder webClientBuilder() {
        return WebClient.builder()
                .filter(reenviarTokenFilter()); // Aplicamos nuestro filtro
    }

    /**
     * Este filtro intercepta la petición saliente, busca el header "Authorization"
     * en la petición original del usuario, y se lo inyecta a la llamada hacia el otro microservicio.
     */
    private ExchangeFilterFunction reenviarTokenFilter() {
        return (request, next) -> {
            ServletRequestAttributes attributes = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();

            if (attributes != null) {
                // Sacamos el token de la petición original (Frontend/Postman -> ms-catalogo)
                String authHeader = attributes.getRequest().getHeader(HttpHeaders.AUTHORIZATION);

                if (authHeader != null) {
                    // Clonamos la petición saliente y le pegamos el token
                    ClientRequest nuevaRequest = ClientRequest.from(request)
                            .header(HttpHeaders.AUTHORIZATION, authHeader)
                            .build();
                    return next.exchange(nuevaRequest);
                }
            }
            // Si no hay token (por ejemplo, en un endpoint público), seguimos sin token
            return next.exchange(request);
        };
    }
}
