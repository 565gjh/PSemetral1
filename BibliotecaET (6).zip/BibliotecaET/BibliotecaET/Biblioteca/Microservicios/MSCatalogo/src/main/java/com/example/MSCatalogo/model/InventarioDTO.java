package com.example.MSCatalogo.model;

import lombok.Data;

@Data
public class InventarioDTO {
    private Long idLibro;
    private int cantidadDisponible;
}