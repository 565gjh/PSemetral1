package com.example.MSMultas.service;

import com.example.MSMultas.model.Multa;
import com.example.MSMultas.repository.multaRepository;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDateTime;
import java.util.Optional;

import static org.mockito.ArgumentMatchers.any;

@ExtendWith(MockitoExtension.class)
public class MultaServiceTest {

    @Mock
    private multaRepository repository;

    @InjectMocks
    private multaService service;

    @Test
    void cuandoSeGuardaMultaSinFecha_entoncesAsignaFechaActualYGuarda() {
        // GIVEN
        Multa multa = new Multa();
        multa.setFechaGeneracion(null);

        Mockito.when(repository.save(any(Multa.class))).thenAnswer(i -> i.getArguments()[0]);

        // WHEN
        Multa resultado = service.save(multa);

        // THEN
        Assertions.assertNotNull(resultado.getFechaGeneracion());
        Mockito.verify(repository, Mockito.times(1)).save(any(Multa.class));
    }

    @Test
    void cuandoSeBuscaMultaPorIdInexistente_entoncesRetornaNull() {
        // GIVEN
        Mockito.when(repository.findById(99L)).thenReturn(Optional.empty());

        // WHEN
        Multa resultado = service.findById(99L);

        // THEN
        Assertions.assertNull(resultado);
    }
}