package com.example.MSusuario.controller;

import com.example.MSusuario.model.RegistroUsuarioDTO;
import com.example.MSusuario.client.AuthClient;
import com.example.MSusuario.model.Usuario;
import com.example.MSusuario.service.usuarioService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PostFilter;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;

@RestController
@RequestMapping("/api/v1/usuarios")
@RequiredArgsConstructor
@SecurityRequirement(name = "bearerAuth")
@Tag(name = "Usuarios", description = "Gestión del perfil de usuarios: nombre, email y rol. Recibe datos desde MSAuth al registrar un nuevo usuario.")
public class usuarioController {

    private final AuthClient authClient;

    @Autowired
    private usuarioService service;

    @Operation(
            summary = "Listar todos los usuarios",
            description = "Retorna la lista de perfiles de usuarios con enlaces HATEOAS a cada perfil individual. ADMIN ve todos los roles; TRABAJADOR solo ve usuarios con rol USUARIO."
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Lista de usuarios retornada correctamente"),
            @ApiResponse(responseCode = "401", description = "No autenticado"),
            @ApiResponse(responseCode = "403", description = "Sin permisos: requiere rol ADMIN o TRABAJADOR")
    })
    @GetMapping
    @PreAuthorize("hasAnyRole('ADMIN', 'TRABAJADOR')")
    @PostFilter("hasRole('ADMIN') or filterObject.rol == 'USUARIO'")
    public List<Usuario> findAll() {
        List<Usuario> usuarios = service.findAll();
        usuarios.forEach(u -> {
            u.add(linkTo(methodOn(usuarioController.class).findById(u.getId())).withSelfRel());
            u.add(linkTo(methodOn(usuarioController.class).findAll()).withRel("todos"));
            u.add(linkTo(methodOn(usuarioController.class).findByEmail(u.getEmail())).withRel("buscar-por-email"));
        });
        return usuarios;
    }

    @Operation(
            summary = "Buscar usuario por ID",
            description = "Retorna el perfil del usuario con el ID especificado, más enlaces HATEOAS para navegar al listado completo y buscar por email. ADMIN puede ver cualquier rol; TRABAJADOR solo ve usuarios con rol USUARIO."
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Usuario encontrado"),
            @ApiResponse(responseCode = "404", description = "Usuario no encontrado"),
            @ApiResponse(responseCode = "401", description = "No autenticado"),
            @ApiResponse(responseCode = "403", description = "Sin permisos suficientes")
    })
    @GetMapping("/id/{id}")
    @PreAuthorize("hasAnyRole('ADMIN', 'TRABAJADOR')")
    @PostFilter("hasRole('ADMIN') or filterObject.rol == 'USUARIO'")
    public ResponseEntity<Usuario> findById(@PathVariable Long id) {
        Usuario usuario = service.findById(id);
        usuario.add(linkTo(methodOn(usuarioController.class).findById(id)).withSelfRel());
        usuario.add(linkTo(methodOn(usuarioController.class).findAll()).withRel("todos"));
        usuario.add(linkTo(methodOn(usuarioController.class).findByEmail(usuario.getEmail())).withRel("buscar-por-email"));
        return ResponseEntity.ok(usuario);
    }

    @Operation(
            summary = "Recibir nuevo perfil de usuario desde MSAuth",
            description = "Endpoint interno llamado por MSAuth al registrar un usuario. Guarda los datos de perfil (nombre, email, rol) y retorna enlaces HATEOAS para consultar el perfil creado."
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "201", description = "Perfil de usuario guardado correctamente"),
            @ApiResponse(responseCode = "400", description = "Datos de perfil inválidos")
    })
    @PostMapping
    public ResponseEntity<Void> recibirNuevoUsuario(@RequestBody RegistroUsuarioDTO perfil) {
        service.guardarPerfil(perfil);
        return ResponseEntity.status(HttpStatus.CREATED).build();
    }

    @Operation(
            summary = "Buscar usuario por email",
            description = "Retorna el perfil del usuario cuyo email coincida con el indicado, con enlaces HATEOAS para navegar al listado y al perfil por ID."
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Usuario encontrado"),
            @ApiResponse(responseCode = "404", description = "Email no registrado"),
            @ApiResponse(responseCode = "401", description = "No autenticado")
    })
    @GetMapping("/email/{email}")
    public ResponseEntity<Optional<Usuario>> findByEmail(@PathVariable String email) {
        Optional<Usuario> usuarioOpt = service.findByEmail(email);
        usuarioOpt.ifPresent(u -> {
            u.add(linkTo(methodOn(usuarioController.class).findByEmail(email)).withSelfRel());
            u.add(linkTo(methodOn(usuarioController.class).findById(u.getId())).withRel("perfil-por-id"));
            u.add(linkTo(methodOn(usuarioController.class).findAll()).withRel("todos"));
        });
        return ResponseEntity.ok(usuarioOpt);
    }
}
