package com.example.MSusuario.model;

import lombok.Data;

@Data
public class RegistroUsuarioDTO {
    private Long authId;
    private String nombre1;
    private String apellido1;
    private String email;
    private String tipoUsuario;
}

