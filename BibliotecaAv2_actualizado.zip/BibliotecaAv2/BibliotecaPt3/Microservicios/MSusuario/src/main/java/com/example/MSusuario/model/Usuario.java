package com.example.MSusuario.model;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.EqualsAndHashCode;
import org.springframework.hateoas.RepresentationModel;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Table(name = "usuarios")
@EqualsAndHashCode(callSuper = false)
@Schema(description = "Perfil del usuario de la biblioteca con datos personales y de contacto")
public class Usuario extends RepresentationModel<Usuario> {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Schema(description = "Identificador único del perfil en MSusuario", example = "1", accessMode = Schema.AccessMode.READ_ONLY)
    private Long id;

    @Schema(description = "ID del registro de autenticación en MSAuth (referencia cruzada)", example = "3")
    private Long idAuth;

    @NotBlank(message = "El primer nombre es obligatorio")
    @Schema(description = "Primer nombre del usuario", example = "Juan", requiredMode = Schema.RequiredMode.REQUIRED)
    private String nombre1;

    @Schema(description = "Segundo nombre del usuario (opcional)", example = "Carlos")
    private String nombre2;

    @NotBlank(message = "El apellido paterno es obligatorio")
    @Schema(description = "Apellido paterno del usuario", example = "Pérez", requiredMode = Schema.RequiredMode.REQUIRED)
    private String apellido1;

    @Schema(description = "Apellido materno del usuario (opcional)", example = "González")
    private String apellido2;

    @Schema(description = "Número de celular del usuario", example = "912345678")
    private int celular;

    @NotBlank(message = "El email es obligatorio")
    @Email(message = "Debe ser un correo válido")
    @Column(unique = true)
    @Schema(description = "Correo electrónico del usuario", example = "juan.perez@gmail.com", requiredMode = Schema.RequiredMode.REQUIRED)
    private String email;

    @NotBlank(message = "El rol es obligatorio")
    @Schema(description = "Rol del usuario: USUARIO, ADMIN o TRABAJADOR", example = "USUARIO", requiredMode = Schema.RequiredMode.REQUIRED)
    private String rol;
}
