package com.example.MSPrestamo.client;

import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;
import java.util.Map;

@Component
public class NotificacionClient {

    private final WebClient notificacionesWebClient;

    public NotificacionClient(WebClient notificacionesWebClient) {
        this.notificacionesWebClient = notificacionesWebClient;
    }

    public Mono<Void> enviarAlerta(Long usuarioId, String mensaje) {
        Map<String, Object> cuerpoNotificacion = Map.of(
                "usuarioId", usuarioId,
                "mensaje", mensaje,
                "leido", false
        );

        return this.notificacionesWebClient.post()
                .bodyValue(cuerpoNotificacion)
                .retrieve()
                .toBodilessEntity()
                .then()
                .onErrorResume(e -> {
                    System.out.println("Error al enviar notificación: " + e.getMessage());
                    return Mono.empty();
                });
    }
}