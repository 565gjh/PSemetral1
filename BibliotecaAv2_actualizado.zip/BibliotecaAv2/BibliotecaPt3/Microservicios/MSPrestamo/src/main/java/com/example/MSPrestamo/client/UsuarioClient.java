package com.example.MSPrestamo.client;

import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

@Component
public class UsuarioClient {

    private final WebClient usuarioWebClient;

    public UsuarioClient(WebClient usuarioWebClient) {
        this.usuarioWebClient = usuarioWebClient;
    }

    // Método para validar si el usuario existe (devuelve true o false, o puedes adaptarlo a tu DTO de Usuario)
    public Mono<Boolean> verificarUsuarioExiste(Long usuarioId) {
        return this.usuarioWebClient.get()
                .uri("/{id}", usuarioId)
                .retrieve()
                .toBodilessEntity() // Solo nos interesa saber si responde 200 OK
                .map(response -> response.getStatusCode().is2xxSuccessful())
                .onErrorReturn(false);
    }
}