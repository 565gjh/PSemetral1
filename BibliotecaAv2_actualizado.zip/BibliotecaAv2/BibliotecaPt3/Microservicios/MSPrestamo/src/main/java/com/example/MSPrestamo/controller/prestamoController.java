package com.example.MSPrestamo.controller;

import com.example.MSPrestamo.model.PrestamoDetalle;
import com.example.MSPrestamo.service.prestamoService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.Link;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;

@RestController
@RequestMapping("/api/v1/prestamos")
@SecurityRequirement(name = "bearerAuth")
@Tag(name = "Préstamos", description = "Gestión de préstamos de libros: estados VIGENTE, DEVUELTO y ATRASADO. Consume MSInventario y MSCatalogo.")
public class prestamoController {

    @Autowired
    private prestamoService prestamoService;

    @Operation(
            summary = "Buscar préstamo por ID",
            description = "Retorna el detalle enriquecido de un préstamo: datos del préstamo, título del libro (desde MSCatalogo), código de barra del ejemplar (desde MSInventario) y enlaces HATEOAS contextuales. Si el préstamo está ATRASADO, se incluye el enlace para registrar una multa."
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Préstamo encontrado con detalles completos"),
            @ApiResponse(responseCode = "404", description = "Préstamo no encontrado"),
            @ApiResponse(responseCode = "401", description = "No autenticado"),
            @ApiResponse(responseCode = "403", description = "Sin permisos suficientes")
    })
    @GetMapping("/{id}")
    public ResponseEntity<PrestamoDetalle> buscarPrestamoPorId(@PathVariable Long id) {
        PrestamoDetalle prestamo = prestamoService.obtenerPorId(id);

        // Self link
        prestamo.add(linkTo(methodOn(prestamoController.class).buscarPrestamoPorId(id)).withSelfRel());

        // Si el préstamo está ATRASADO, el cliente puede navegar directamente a crear una multa
        if (prestamo.getPrestamo() != null && "ATRASADO".equals(prestamo.getPrestamo().getEstado())) {
            prestamo.add(Link.of("/api/v1/multas").withRel("registrar-multa"));
        }

        // Enlace al inventario del ejemplar prestado para verificar su estado
        if (prestamo.getPrestamo() != null) {
            prestamo.add(Link.of("/api/v1/inventario/" + prestamo.getPrestamo().getInventarioId()).withRel("ejemplar-prestado"));
        }

        return ResponseEntity.ok(prestamo);
    }
}
