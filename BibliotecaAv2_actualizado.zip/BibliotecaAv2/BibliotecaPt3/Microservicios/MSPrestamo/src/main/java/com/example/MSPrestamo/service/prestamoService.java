package com.example.MSPrestamo.service;


import com.example.MSPrestamo.client.CatalogoClient;
import com.example.MSPrestamo.client.InventarioClient;
import com.example.MSPrestamo.model.*;
import com.example.MSPrestamo.repository.prestamoRepository;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

import java.util.List;

@Service
public class PrestamoService {

    private final prestamoRepository prestamoRepository;
    private final InventarioClient inventarioClient;
    private final CatalogoClient catalogoClient;

    public PrestamoService(prestamoRepository prestamoRepository,
                           InventarioClient inventarioClient,
                           CatalogoClient catalogoClient) {
        this.prestamoRepository = prestamoRepository;
        this.inventarioClient = inventarioClient;
        this.catalogoClient = catalogoClient;
    }

    public Mono<UsuarioPrestamos> obtenerHistorialUsuario(Long usuarioId, String email, String nombre) {
        // 1. Obtener la lista de préstamos locales desde el repositorio JPA
        List<Prestamo> prestamosLocales = prestamoRepository.findByUsuarioId(usuarioId);

        // 2. Procesar la lista de manera reactiva y no bloqueante
        return Flux.fromIterable(prestamosLocales)
                .flatMap(prestamo -> {
                    // Inicializar el DTO individual de detalle
                    PrestamoDetalle detalle = new PrestamoDetalle();
                    detalle.setPrestamoId(prestamo.getId());
                    detalle.setFechaPrestamo(prestamo.getFechaPrestamo());
                    detalle.setFechaDevolucionMaxima(prestamo.getFechaDevolucionMaxima());
                    detalle.setEstado(prestamo.getEstado());

                    // Invocar de manera reactiva al cliente de Inventario
                    return inventarioClient.obtenerItemInventario(prestamo.getInventarioId())
                            .flatMap(inv -> {
                                detalle.setCodigoBarraEjemplar(inv.getCodigoBarra());
                                detalle.setLibroId(inv.getLibroId());

                                // Anidar la llamada a Catálogo usando el ID obtenido de Inventario
                                return catalogoClient.obtenerDatosLibro(inv.getLibroId())
                                        .map(libro -> {
                                            detalle.setTituloLibro(libro.getTitulo());
                                            return detalle;
                                        })
                                        // Si Catálogo falla, salvamos el flujo con datos parciales
                                        .defaultIfEmpty(detalle);
                            })
                            // Si Inventario falla por completo, asignamos valores por defecto
                            .defaultIfEmpty(detalle)
                            .doOnNext(d -> {
                                if (d.getTituloLibro() == null) {
                                    d.setTituloLibro("Información de catálogo no disponible");
                                }
                            });
                })
                .collectList() // Reunimos todos los hilos procesados asíncronamente en una Lista reactiva
                .map(listaDetalles -> {
                    // 3. Construir e integrar todo en el DTO raíz del Usuario
                    UsuarioPrestamos usuarioDTO = new UsuarioPrestamos();
                    usuarioDTO.setUsuarioId(usuarioId);
                    usuarioDTO.setEmail(email);
                    usuarioDTO.setNombreCompleto(nombre);
                    usuarioDTO.setPrestamos(listaDetalles);
                    return usuarioDTO;
                });
    }
}