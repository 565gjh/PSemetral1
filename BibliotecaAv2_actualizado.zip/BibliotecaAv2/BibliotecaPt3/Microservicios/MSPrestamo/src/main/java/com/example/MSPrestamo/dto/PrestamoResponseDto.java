package com.example.MSPrestamo.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.LocalDate;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class PrestamoResponseDto {
    private Long id;
    private Long libroId;
    private String rutUsuario;
    private String codigoBarra;
    private LocalDate fechaPrestamo;
    private LocalDate fechaDevolucion;
    private String estadoPrestamo; // "ACTIVO", "DEVUELTO", etc.
    private String mensajeInformativo; // Para aclaraciones de la respuesta
}