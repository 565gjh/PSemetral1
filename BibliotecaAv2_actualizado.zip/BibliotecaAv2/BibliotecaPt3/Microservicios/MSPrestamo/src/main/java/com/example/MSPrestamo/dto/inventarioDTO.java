package com.example.MSPrestamo.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class inventarioDTO {
    private Long id;
    private Long libroId;
    private String codigoBarra;
    private String estado; // "DISPONIBLE", "PRESTADO", etc.
}