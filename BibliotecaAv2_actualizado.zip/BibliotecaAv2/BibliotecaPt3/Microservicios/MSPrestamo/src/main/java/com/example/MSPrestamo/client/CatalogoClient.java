package com.example.MSPrestamo.client;

import com.example.MSPrestamo.model.*;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

@Component
public class CatalogoClient {

    private final WebClient catalogoWebClient;

    public CatalogoClient(WebClient catalogoWebClient) {
        this.catalogoWebClient = catalogoWebClient;
    }

    public Mono<Libro> obtenerDatosLibro(Long libroId) {
        return this.catalogoWebClient.get()
                .uri("/{id}", libroId)
                .retrieve()
                .bodyToMono(Libro.class)
                .onErrorResume(e -> Mono.empty());
    }
}