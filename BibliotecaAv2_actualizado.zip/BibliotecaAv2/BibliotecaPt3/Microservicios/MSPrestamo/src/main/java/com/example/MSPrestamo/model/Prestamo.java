package com.example.MSPrestamo.model;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.EqualsAndHashCode;
import org.springframework.hateoas.RepresentationModel;
import java.time.LocalDate;

@Entity
@Table(name = "prestamos")
@Data
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = false)
@Schema(description = "Préstamo de un ejemplar físico de libro a un usuario de la biblioteca")
public class Prestamo extends RepresentationModel<Prestamo> {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Schema(description = "Identificador único del préstamo", example = "1", accessMode = Schema.AccessMode.READ_ONLY)
    private Long id;

    @Column(name = "usuario_id", nullable = false)
    @Schema(description = "ID del usuario (de MSAuth) que realiza el préstamo", example = "5", requiredMode = Schema.RequiredMode.REQUIRED)
    private Long usuarioId;

    @Column(name = "inventario_id", nullable = false)
    @Schema(description = "ID del ejemplar físico (de MSInventario) que se presta", example = "12", requiredMode = Schema.RequiredMode.REQUIRED)
    private Long inventarioId;

    @Column(name = "fecha_prestamo", nullable = false)
    @Schema(description = "Fecha en que se realizó el préstamo", example = "2024-06-01", requiredMode = Schema.RequiredMode.REQUIRED)
    private LocalDate fechaPrestamo;

    @Column(name = "fecha_devolucion_maxima", nullable = false)
    @Schema(description = "Fecha límite para devolver el libro (generalmente +15 días desde el préstamo)", example = "2024-06-16", requiredMode = Schema.RequiredMode.REQUIRED)
    private LocalDate fechaDevolucionMaxima;

    @Column(nullable = false, length = 50)
    @Schema(description = "Estado del préstamo", example = "VIGENTE", allowableValues = {"VIGENTE", "DEVUELTO", "ATRASADO"}, requiredMode = Schema.RequiredMode.REQUIRED)
    private String estado;
}
