package com.example.MSPrestamo.client;

import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;
import java.util.Map;

@Component
public class MultasClient {

    private final WebClient multasWebClient;

    public MultasClient(WebClient multasWebClient) {
        this.multasWebClient = multasWebClient;
    }

    // Método para generar una multa automáticamente cuando hay retraso
    public Mono<Void> generarMulta(Long usuarioId, Long prestamoId, Double monto) {
        Map<String, Object> datosMulta = Map.of(
                "usuarioId", usuarioId,
                "prestamoId", prestamoId,
                "monto", monto,
                "estado", "PENDIENTE"
        );

        return this.multasWebClient.post()
                .bodyValue(datosMulta)
                .retrieve()
                .toBodilessEntity()
                .then()
                .onErrorResume(e -> {
                    System.out.println("Error al comunicar con MSMultas: " + e.getMessage());
                    return Mono.empty();
                });
    }
}