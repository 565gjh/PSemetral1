package com.example.MSNotificaciones.controller;

import com.example.MSNotificaciones.model.Notificacion;
import com.example.MSNotificaciones.service.notificacionService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.Link;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;

@RestController
@RequestMapping("/api/v1/notificaciones")
@SecurityRequirement(name = "bearerAuth")
@Tag(name = "Notificaciones", description = "Envío y consulta de notificaciones a usuarios sobre préstamos, devoluciones y multas")
public class notificacionController {

    @Autowired
    private notificacionService service;

    @Operation(
            summary = "Listar todas las notificaciones",
            description = "Retorna todas las notificaciones con enlaces HATEOAS. Las notificaciones PENDIENTES incluyen enlace al perfil del usuario destinatario para tomar acción."
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Lista de notificaciones retornada correctamente"),
            @ApiResponse(responseCode = "401", description = "No autenticado")
    })
    @GetMapping
    public List<Notificacion> findAll() {
        List<Notificacion> notificaciones = service.findAll();
        notificaciones.forEach(n -> {
            n.add(linkTo(methodOn(notificacionController.class).findById(n.getId())).withSelfRel());
            n.add(linkTo(methodOn(notificacionController.class).findAll()).withRel("todas"));
            // Enlace al usuario destinatario en MSusuario
            n.add(Link.of("/api/v1/usuarios/id/" + n.getUsuarioId()).withRel("usuario-destinatario"));
            // Las notificaciones PENDIENTES ofrecen eliminar para reintento o descarte
            if ("PENDIENTE".equals(n.getEstado())) {
                n.add(linkTo(methodOn(notificacionController.class).delete(n.getId())).withRel("eliminar-pendiente"));
            }
        });
        return notificaciones;
    }

    @Operation(
            summary = "Buscar notificación por ID",
            description = "Retorna la notificación con el ID especificado. Incluye enlace HATEOAS al usuario destinatario y, si está PENDIENTE, enlace para eliminarla o reenviarla."
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Notificación encontrada"),
            @ApiResponse(responseCode = "404", description = "Notificación no encontrada"),
            @ApiResponse(responseCode = "401", description = "No autenticado")
    })
    @GetMapping("/{id}")
    public ResponseEntity<Notificacion> findById(@PathVariable Long id) {
        Notificacion notificacion = service.findById(id);
        if (notificacion == null) return ResponseEntity.notFound().build();

        notificacion.add(linkTo(methodOn(notificacionController.class).findById(id)).withSelfRel());
        notificacion.add(linkTo(methodOn(notificacionController.class).findAll()).withRel("todas"));
        notificacion.add(Link.of("/api/v1/usuarios/id/" + notificacion.getUsuarioId()).withRel("usuario-destinatario"));
        if ("PENDIENTE".equals(notificacion.getEstado())) {
            notificacion.add(linkTo(methodOn(notificacionController.class).delete(id)).withRel("eliminar"));
        }
        return ResponseEntity.ok(notificacion);
    }

    @Operation(
            summary = "Crear nueva notificación",
            description = "Registra una notificación para un usuario. Retorna la notificación creada con enlace HATEOAS al perfil del usuario destinatario para verificar sus datos de contacto."
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "201", description = "Notificación creada correctamente"),
            @ApiResponse(responseCode = "400", description = "Datos inválidos: mensaje vacío, tipo o estado incorrecto"),
            @ApiResponse(responseCode = "401", description = "No autenticado")
    })
    @PostMapping
    public ResponseEntity<Notificacion> save(@Valid @RequestBody Notificacion notificacion) {
        Notificacion nueva = service.save(notificacion);
        nueva.add(linkTo(methodOn(notificacionController.class).findById(nueva.getId())).withSelfRel());
        nueva.add(linkTo(methodOn(notificacionController.class).findAll()).withRel("todas"));
        // Enlace al usuario para verificar email/celular antes de enviar
        nueva.add(Link.of("/api/v1/usuarios/id/" + nueva.getUsuarioId()).withRel("usuario-destinatario"));
        return new ResponseEntity<>(nueva, HttpStatus.CREATED);
    }

    @Operation(
            summary = "Eliminar notificación",
            description = "Elimina una notificación del sistema por su ID."
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Notificación eliminada correctamente"),
            @ApiResponse(responseCode = "404", description = "Notificación no encontrada"),
            @ApiResponse(responseCode = "401", description = "No autenticado")
    })
    @DeleteMapping("/{id}")
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}
