package com.example.MSNotificaciones.model;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.EqualsAndHashCode;
import org.springframework.hateoas.RepresentationModel;
import java.time.LocalDateTime;

@Entity
@Table(name = "notificaciones")
@Data
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = false)
@Schema(description = "Notificación enviada a un usuario sobre eventos del sistema de biblioteca")
public class Notificacion extends RepresentationModel<Notificacion> {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Schema(description = "Identificador único de la notificación", example = "1", accessMode = Schema.AccessMode.READ_ONLY)
    private Long id;

    @NotNull(message = "El ID del usuario es obligatorio")
    @Schema(description = "ID del usuario destinatario (de MSusuario)", example = "10", requiredMode = Schema.RequiredMode.REQUIRED)
    private Long usuarioId;

    @NotBlank(message = "El mensaje no puede estar vacío")
    @Schema(description = "Contenido del mensaje de la notificación", example = "Su préstamo del libro 'Cien Años de Soledad' vence mañana.", requiredMode = Schema.RequiredMode.REQUIRED)
    private String mensaje;

    @NotBlank(message = "El tipo de notificación es obligatorio (EMAIL/APP)")
    @Schema(description = "Canal de envío de la notificación", example = "EMAIL", allowableValues = {"EMAIL", "APP"}, requiredMode = Schema.RequiredMode.REQUIRED)
    private String tipo;

    @Schema(description = "Fecha y hora en que se envió la notificación", example = "2024-06-01T09:00:00", accessMode = Schema.AccessMode.READ_ONLY)
    private LocalDateTime fechaEnvio;

    @NotBlank(message = "El estado es obligatorio (ENVIADO/PENDIENTE)")
    @Schema(description = "Estado de la notificación", example = "PENDIENTE", allowableValues = {"PENDIENTE", "ENVIADO"}, requiredMode = Schema.RequiredMode.REQUIRED)
    private String estado;
}
