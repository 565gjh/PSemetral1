package com.example.MSMultas.controller;

import com.example.MSMultas.model.Multa;
import com.example.MSMultas.service.multaService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.Link;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;

@RestController
@RequestMapping("/api/v1/multas")
@SecurityRequirement(name = "bearerAuth")
@Tag(name = "Multas", description = "Gestión de multas generadas por devolución tardía de préstamos de libros")
public class multaController {

    @Autowired
    private multaService service;

    @Operation(
            summary = "Listar todas las multas",
            description = "Retorna todas las multas registradas con enlaces HATEOAS. Las multas con estado 'Pendiente' incluyen enlace para pagar; las 'Pagadas' incluyen enlace para eliminar."
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Lista de multas retornada correctamente"),
            @ApiResponse(responseCode = "401", description = "No autenticado")
    })
    @GetMapping
    public List<Multa> findAll() {
        List<Multa> multas = service.findAll();
        multas.forEach(multa -> {
            multa.add(linkTo(methodOn(multaController.class).findById(multa.getId())).withSelfRel());
            multa.add(linkTo(methodOn(multaController.class).findAll()).withRel("todas"));
            // Enlace al préstamo que originó la multa
            multa.add(Link.of("/api/v1/prestamos/" + multa.getPrestamoId()).withRel("prestamo-origen"));
            // Enlace al perfil del usuario multado
            multa.add(Link.of("/api/v1/usuarios/id/" + multa.getUsuarioId()).withRel("usuario"));
            // Solo las multas Pendientes ofrecen acción de pago; las Pagadas ofrecen eliminar
            if ("Pendiente".equals(multa.getEstado())) {
                multa.add(linkTo(methodOn(multaController.class).delete(multa.getId())).withRel("pagar-o-eliminar"));
            }
        });
        return multas;
    }

    @Operation(
            summary = "Buscar multa por ID",
            description = "Retorna la multa con el ID especificado. Incluye enlaces HATEOAS: al préstamo que la originó, al usuario multado y, si está Pendiente, al endpoint para eliminar/pagar."
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Multa encontrada"),
            @ApiResponse(responseCode = "404", description = "Multa no encontrada"),
            @ApiResponse(responseCode = "401", description = "No autenticado")
    })
    @GetMapping("/{id}")
    public ResponseEntity<Multa> findById(@PathVariable Long id) {
        Multa multa = service.findById(id);
        if (multa == null) return ResponseEntity.notFound().build();

        multa.add(linkTo(methodOn(multaController.class).findById(id)).withSelfRel());
        multa.add(linkTo(methodOn(multaController.class).findAll()).withRel("todas"));
        multa.add(Link.of("/api/v1/prestamos/" + multa.getPrestamoId()).withRel("prestamo-origen"));
        multa.add(Link.of("/api/v1/usuarios/id/" + multa.getUsuarioId()).withRel("usuario"));
        if ("Pendiente".equals(multa.getEstado())) {
            multa.add(linkTo(methodOn(multaController.class).delete(id)).withRel("eliminar"));
        }
        return ResponseEntity.ok(multa);
    }

    @Operation(
            summary = "Registrar nueva multa",
            description = "Crea una multa asociada a un usuario y un préstamo atrasado. Retorna la multa con enlaces HATEOAS al préstamo origen y al perfil del usuario."
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "201", description = "Multa registrada correctamente"),
            @ApiResponse(responseCode = "400", description = "Datos inválidos: monto negativo o campos obligatorios faltantes"),
            @ApiResponse(responseCode = "401", description = "No autenticado")
    })
    @PostMapping
    public ResponseEntity<Multa> save(@Valid @RequestBody Multa multa) {
        Multa nuevaMulta = service.save(multa);
        nuevaMulta.add(linkTo(methodOn(multaController.class).findById(nuevaMulta.getId())).withSelfRel());
        nuevaMulta.add(linkTo(methodOn(multaController.class).findAll()).withRel("todas"));
        nuevaMulta.add(Link.of("/api/v1/prestamos/" + nuevaMulta.getPrestamoId()).withRel("prestamo-origen"));
        nuevaMulta.add(Link.of("/api/v1/usuarios/id/" + nuevaMulta.getUsuarioId()).withRel("usuario"));
        return new ResponseEntity<>(nuevaMulta, HttpStatus.CREATED);
    }

    @Operation(
            summary = "Eliminar multa",
            description = "Elimina una multa del sistema por su ID. Solo debe usarse si la multa fue creada por error o ha sido pagada."
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Multa eliminada correctamente"),
            @ApiResponse(responseCode = "404", description = "Multa no encontrada"),
            @ApiResponse(responseCode = "401", description = "No autenticado")
    })
    @DeleteMapping("/{id}")
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}
