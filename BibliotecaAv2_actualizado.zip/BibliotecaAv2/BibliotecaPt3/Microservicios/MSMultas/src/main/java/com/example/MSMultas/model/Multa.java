package com.example.MSMultas.model;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.EqualsAndHashCode;
import org.springframework.hateoas.RepresentationModel;
import java.time.LocalDateTime;

@Entity
@Table(name = "multas")
@Data
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = false)
@Schema(description = "Multa generada por devolución tardía de un préstamo de biblioteca")
public class Multa extends RepresentationModel<Multa> {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Schema(description = "Identificador único de la multa", example = "1", accessMode = Schema.AccessMode.READ_ONLY)
    private Long id;

    @NotNull(message = "El ID del usuario es obligatorio")
    @Schema(description = "ID del usuario (de MSusuario) al que pertenece la multa", example = "10", requiredMode = Schema.RequiredMode.REQUIRED)
    private Long usuarioId;

    @NotNull(message = "El ID del préstamo asociado es obligatorio")
    @Schema(description = "ID del préstamo (de MSPrestamo) que originó esta multa", example = "25", requiredMode = Schema.RequiredMode.REQUIRED)
    private Long prestamoId;

    @NotNull(message = "El monto de la multa es obligatorio")
    @Min(value = 0, message = "El monto no puede ser negativo")
    @Schema(description = "Monto en pesos de la multa a pagar", example = "2500.0", minimum = "0", requiredMode = Schema.RequiredMode.REQUIRED)
    private Double monto;

    @NotBlank(message = "El estado de la multa es obligatorio (Pendiente/Pagada)")
    @Schema(description = "Estado actual de la multa", example = "Pendiente", allowableValues = {"Pendiente", "Pagada"}, requiredMode = Schema.RequiredMode.REQUIRED)
    private String estado;

    @Schema(description = "Fecha y hora en que se generó la multa (se asigna automáticamente)", example = "2024-06-01T10:30:00", accessMode = Schema.AccessMode.READ_ONLY)
    private LocalDateTime fechaGeneracion;
}
