package com.example.MSMultas.client;

import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

@Component
public class UsuarioClient {

    private final WebClient usuarioWebClient;

    public UsuarioClient(WebClient usuarioWebClient) {
        this.usuarioWebClient = usuarioWebClient;
    }

    public Mono<Boolean> verificarUsuarioExiste(Long usuarioId) {
        return this.usuarioWebClient.get()
                .uri("/{id}", usuarioId)
                .retrieve()
                .toBodilessEntity()
                .map(response -> response.getStatusCode().is2xxSuccessful())
                .onErrorReturn(false);
    }
}