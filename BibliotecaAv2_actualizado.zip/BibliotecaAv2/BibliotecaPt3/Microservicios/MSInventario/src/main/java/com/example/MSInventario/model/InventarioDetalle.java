package com.example.MSInventario.model;

import lombok.Data;

@Data
public class InventarioDetalle {
    private Long inventarioId;
    private Long libroId;
    private String tituloLibro;
    private String codigoBarra;
    private String estado;
}