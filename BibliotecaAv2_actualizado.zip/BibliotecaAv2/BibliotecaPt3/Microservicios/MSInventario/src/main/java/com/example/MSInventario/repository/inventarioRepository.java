package com.example.MSInventario.repository;


import com.example.MSInventario.model.Inventario;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface inventarioRepository extends JpaRepository<Inventario, Long> {
    // Para que el MSPrestamos o MSReservas valide si un código de barra específico está libre
    java.util.Optional<Inventario> findByCodigoBarra(String codigoBarra);
}