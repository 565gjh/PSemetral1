package com.example.MSInventario.model;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.EqualsAndHashCode;
import org.springframework.hateoas.RepresentationModel;

@Entity
@Table(name = "inventario")
@Data
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = false)
@Schema(description = "Ejemplar físico de un libro en el inventario de la biblioteca")
public class Inventario extends RepresentationModel<Inventario> {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Schema(description = "Identificador único del ejemplar físico", example = "1", accessMode = Schema.AccessMode.READ_ONLY)
    private Long id;

    @Column(name = "libro_id", nullable = false)
    @Schema(description = "ID del libro en el catálogo (MSCatalogo) al que pertenece este ejemplar", example = "5", requiredMode = Schema.RequiredMode.REQUIRED)
    private Long libroId;

    @Column(name = "codigo_barra", nullable = false, unique = true)
    @Schema(description = "Código de barras único del ejemplar físico", example = "BIB-2024-00123", requiredMode = Schema.RequiredMode.REQUIRED)
    private String codigoBarra;

    @Column(nullable = false, length = 50)
    @Schema(description = "Estado actual del ejemplar: DISPONIBLE, PRESTADO o MANTENIMIENTO", example = "DISPONIBLE", allowableValues = {"DISPONIBLE", "PRESTADO", "MANTENIMIENTO"}, requiredMode = Schema.RequiredMode.REQUIRED)
    private String estado;
}
