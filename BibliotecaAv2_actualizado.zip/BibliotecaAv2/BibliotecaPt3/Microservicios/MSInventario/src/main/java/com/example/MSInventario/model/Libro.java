package com.example.MSInventario.model;

import lombok.Data;

@Data
public class Libro {
    private Long id;
    private String titulo;
}
