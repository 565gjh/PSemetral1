package com.example.MSInventario.service;

import com.example.MSInventario.client.CatalogoClient;
import com.example.MSInventario.model.*;
import com.example.MSInventario.model.Inventario;
import com.example.MSInventario.repository.inventarioRepository;
import org.springframework.stereotype.Service;
import reactor.core.publisher.Mono;

@Service
public class inventarioService {

    private final inventarioRepository inventarioRepository;
    private final CatalogoClient catalogoClient;

    public inventarioService(inventarioRepository inventarioRepository, CatalogoClient catalogoClient) {
        this.inventarioRepository = inventarioRepository;
        this.catalogoClient = catalogoClient;
    }

    // 1. Obtener un ítem de inventario unificado con los datos de Catálogo
    public Mono<InventarioDetalle> obtenerItemConCatalogo(Long id) {
        return Mono.justOrEmpty(inventarioRepository.findById(id))
                .flatMap(item -> {
                    InventarioDetalle dto = new InventarioDetalle();
                    dto.setInventarioId(item.getId());
                    dto.setLibroId(item.getLibroId());
                    dto.setCodigoBarra(item.getCodigoBarra());
                    dto.setEstado(item.getEstado());

                    // Llamada al Microservicio de Catálogo
                    return catalogoClient.obtenerDatosLibro(item.getLibroId())
                            .map(libro -> {
                                dto.setTituloLibro(libro.getTitulo());
                                return dto;
                            })
                            // Si el catálogo está caído, no rompemos el flujo de inventario por completo
                            .defaultIfEmpty(dto);
                })
                .doOnNext(dto -> {
                    if (dto.getTituloLibro() == null) {
                        dto.setTituloLibro("Título no disponible temporalmente");
                    }
                });
    }

    // 2. Crear Ejemplar VALIDANDO que el libro exista en Catálogo (Como en tu guía)
    public Mono<Inventario> guardarEjemplar(Inventario nuevoItem) {
        return catalogoClient.obtenerDatosLibro(nuevoItem.getLibroId())
                // Si el Mono viene vacío significa que el libro no existe en MSCatalogo
                .switchIfEmpty(Mono.error(new RuntimeException("Error: El id de libro " + nuevoItem.getLibroId() + " no existe en el Catálogo.")))
                .map(libroDto -> {
                    // Si existía, procedemos a guardar físicamente en el inventario local
                    return inventarioRepository.save(nuevoItem);
                });
    }

    // 3. Modificar Estado (Invocado por MSPrestamos cuando alguien pide o devuelve un libro)
    public Mono<Inventario> actualizarEstado(Long id, String nuevoEstado) {
        return Mono.justOrEmpty(inventarioRepository.findById(id))
                .map(item -> {
                    item.setEstado(nuevoEstado);
                    return inventarioRepository.save(item);
                })
                .switchIfEmpty(Mono.error(new RuntimeException("Item de inventario no encontrado")));
    }
}