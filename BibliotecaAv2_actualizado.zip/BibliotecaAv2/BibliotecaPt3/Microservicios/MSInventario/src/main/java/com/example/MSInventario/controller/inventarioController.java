package com.example.MSInventario.controller;

import com.example.MSInventario.model.Inventario;
import com.example.MSInventario.service.inventarioService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;

@RestController
@RequestMapping("/api/v1/inventario")
@SecurityRequirement(name = "bearerAuth")
@Tag(name = "Inventario", description = "Control de ejemplares físicos de libros: disponibilidad, estado y códigos de barra")
public class inventarioController {

    @Autowired
    private inventarioService service;

    @Operation(
            summary = "Listar todos los ejemplares",
            description = "Retorna todos los ejemplares físicos con su estado (DISPONIBLE, PRESTADO, MANTENIMIENTO) y enlaces HATEOAS para consultar cada uno individualmente."
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Lista de ejemplares retornada correctamente"),
            @ApiResponse(responseCode = "401", description = "No autenticado")
    })
    @GetMapping
    public List<Inventario> findAll() {
        List<Inventario> ejemplares = service.findAll();
        ejemplares.forEach(inv -> {
            inv.add(linkTo(methodOn(inventarioController.class).findById(inv.getId())).withSelfRel());
            inv.add(linkTo(methodOn(inventarioController.class).findAll()).withRel("todos"));
            // Solo muestra el enlace de eliminar si el ejemplar está en MANTENIMIENTO (no prestado)
            if ("MANTENIMIENTO".equals(inv.getEstado()) || "DISPONIBLE".equals(inv.getEstado())) {
                inv.add(linkTo(methodOn(inventarioController.class).delete(inv.getId())).withRel("eliminar"));
            }
        });
        return ejemplares;
    }

    @Operation(
            summary = "Buscar ejemplar por ID",
            description = "Retorna el ejemplar físico con el ID especificado. Incluye enlace de eliminar solo si el ejemplar está DISPONIBLE o en MANTENIMIENTO (no se puede eliminar si está PRESTADO)."
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Ejemplar encontrado"),
            @ApiResponse(responseCode = "404", description = "Ejemplar no encontrado"),
            @ApiResponse(responseCode = "401", description = "No autenticado")
    })
    @GetMapping("/{id}")
    public ResponseEntity<Inventario> findById(@PathVariable Long id) {
        Inventario inventario = service.findById(id);
        if (inventario == null) return ResponseEntity.notFound().build();

        inventario.add(linkTo(methodOn(inventarioController.class).findById(id)).withSelfRel());
        inventario.add(linkTo(methodOn(inventarioController.class).findAll()).withRel("todos"));
        inventario.add(linkTo(methodOn(inventarioController.class).save(null)).withRel("registrar-nuevo-ejemplar"));
        // Enlace de eliminar solo cuando el ejemplar no está en préstamo activo
        if (!"PRESTADO".equals(inventario.getEstado())) {
            inventario.add(linkTo(methodOn(inventarioController.class).delete(id)).withRel("eliminar"));
        }
        return ResponseEntity.ok(inventario);
    }

    @Operation(
            summary = "Registrar nuevo ejemplar",
            description = "Agrega un ejemplar físico al inventario asociado a un libro del catálogo. Retorna el ejemplar creado con enlaces HATEOAS para ver todos los ejemplares o consultar el recién creado."
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "201", description = "Ejemplar registrado correctamente"),
            @ApiResponse(responseCode = "400", description = "Datos inválidos o código de barra duplicado"),
            @ApiResponse(responseCode = "401", description = "No autenticado")
    })
    @PostMapping
    public ResponseEntity<Inventario> save(@Valid @RequestBody Inventario inventario) {
        Inventario nuevo = service.save(inventario);
        nuevo.add(linkTo(methodOn(inventarioController.class).findById(nuevo.getId())).withSelfRel());
        nuevo.add(linkTo(methodOn(inventarioController.class).findAll()).withRel("todos"));
        nuevo.add(linkTo(methodOn(inventarioController.class).delete(nuevo.getId())).withRel("eliminar"));
        return new ResponseEntity<>(nuevo, HttpStatus.CREATED);
    }

    @Operation(
            summary = "Eliminar ejemplar",
            description = "Elimina un ejemplar del inventario por su ID. Solo aplicable si el ejemplar no tiene préstamos activos."
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Ejemplar eliminado correctamente"),
            @ApiResponse(responseCode = "404", description = "Ejemplar no encontrado"),
            @ApiResponse(responseCode = "401", description = "No autenticado")
    })
    @DeleteMapping("/{id}")
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}
