package com.example.MSReservas.client;

import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.client.HttpClientErrorException;

@Component
public class UsuarioClient {

    private final RestTemplate restTemplate;
    private final String USUARIO_SERVICE_URL = "http://localhost:8081/api/v1/usuarios/";

    public UsuarioClient(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    public boolean verificarUsuarioExiste(Long usuarioId) {
        try {

            restTemplate.getForEntity(USUARIO_SERVICE_URL + usuarioId, Object.class);
            return true;
        } catch (HttpClientErrorException.NotFound e) {
            return false;
        } catch (Exception e) {
            System.out.println("Error al conectar con MSUsuario: " + e.getMessage());
            return false;
        }
    }
}