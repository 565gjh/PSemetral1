package com.example.MSReservas.controller;

import com.example.MSReservas.dto.ReservaResponseDto;
import com.example.MSReservas.service.reservaService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.Link;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;

@RestController
@RequestMapping("/api/v1/reservas")
@SecurityRequirement(name = "bearerAuth")
@Tag(name = "Reservas", description = "Gestión de reservas de libros no disponibles físicamente. Consulta datos de usuario y libro desde otros microservicios.")
public class reservaController {

    @Autowired
    private reservaService reservaService;

    @Operation(
            summary = "Buscar reserva por ID",
            description = "Retorna el detalle enriquecido de una reserva: datos del usuario (desde MSusuario) y del libro reservado (desde MSCatalogo), posición en la fila y estado. Incluye enlaces HATEOAS contextuales: reservas ACTIVAS ofrecen enlace al inventario para verificar si el libro ya está disponible; reservas COMPLETADAS enlazan a préstamos."
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Reserva encontrada con datos completos del usuario y libro"),
            @ApiResponse(responseCode = "404", description = "Reserva no encontrada"),
            @ApiResponse(responseCode = "401", description = "No autenticado"),
            @ApiResponse(responseCode = "403", description = "Sin permisos suficientes")
    })
    @GetMapping("/{id}")
    public ResponseEntity<ReservaResponseDto> buscarReservaPorId(@PathVariable Long id) {
        ReservaResponseDto reserva = reservaService.obtenerPorId(id);

        // Self link
        reserva.add(linkTo(methodOn(reservaController.class).buscarReservaPorId(id)).withSelfRel());

        // Enlace al libro reservado en el catálogo
        if (reserva.getLibro() != null) {
            reserva.add(Link.of("/api/v1/catalogo/libro/" + reserva.getLibro().getId()).withRel("libro-en-catalogo"));
            // Si la reserva está ACTIVA, ofrecer enlace al inventario para verificar disponibilidad
            if ("ACTIVA".equals(reserva.getEstado())) {
                reserva.add(Link.of("/api/v1/inventario").withRel("verificar-disponibilidad-inventario"));
            }
        }

        // Enlace al perfil del usuario que reservó
        if (reserva.getUsuario() != null) {
            reserva.add(Link.of("/api/v1/usuarios/id/" + reserva.getUsuario().getId()).withRel("perfil-usuario"));
        }

        // Si la reserva está COMPLETADA, enlazar a préstamos (el libro ya fue prestado)
        if ("COMPLETADA".equals(reserva.getEstado())) {
            reserva.add(Link.of("/api/v1/prestamos").withRel("ver-prestamos"));
        }

        return ResponseEntity.ok(reserva);
    }
}
