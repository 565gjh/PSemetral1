package com.example.MSReservas.dto;

public class LibroDto {
    private Long id;
    private String titulo;
    private String isbn;

    public LibroDto() {}

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getTitulo() { return titulo; }
    public void setTitulo(String titulo) { this.titulo = titulo; }

    public String getIsbn() { return isbn; }
    public void setIsbn(String isbn) { this.isbn = isbn; }
}