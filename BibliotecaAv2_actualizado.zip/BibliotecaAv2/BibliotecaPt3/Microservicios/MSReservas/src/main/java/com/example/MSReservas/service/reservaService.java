package com.example.MSReservas.service;

import com.example.MSReservas.dto.LibroDto;
import com.example.MSReservas.dto.ReservaResponseDto;
import com.example.MSReservas.dto.UsuarioDto;
import com.example.MSReservas.model.Reserva;
import com.example.MSReservas.repository.reservaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class reservaService {

    @Autowired
    private reservaRepository reservaRepository;

    @Autowired
    private RestTemplate restTemplate;

    public ReservaResponseDto obtenerPorId(Long id) {

        Reserva reserva = reservaRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Reserva no encontrada con el ID: " + id));


        UsuarioDto usuario = null;
        try {
            String urlUsuarios = "http://localhost:8080/api/v1/usuarios/" + reserva.getUsuarioId();
            usuario = restTemplate.getForObject(urlUsuarios, UsuarioDto.class);
        } catch (Exception e) {
            usuario = new UsuarioDto();
            usuario.setId(reserva.getUsuarioId());
            usuario.setNombre("Usuario No disponible");
            usuario.setEmail("(Error de comunicación)");
        }

        LibroDto libro = null;
        try {
            String urlLibros = "http://localhost:8081/api/v1/libros/" + reserva.getLibroId();
            libro = restTemplate.getForObject(urlLibros, LibroDto.class);
        } catch (Exception e) {
            libro = new LibroDto();
            libro.setId(reserva.getLibroId());
            libro.setTitulo("Libro No disponible");
            libro.setIsbn("(Error de comunicación)");
        }

        ReservaResponseDto response = new ReservaResponseDto();
        response.setId(reserva.getId());
        response.setFechaReserva(reserva.getFechaReserva());
        response.setPosicionFila(reserva.getPosicionFila());
        response.setEstado(reserva.getEstado());
        response.setUsuario(usuario);
        response.setLibro(libro);

        return response;
    }
}