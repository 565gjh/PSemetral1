package com.example.MSReservas.client;

import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.client.HttpClientErrorException;

@Component
public class InventarioClient {

    private final RestTemplate restTemplate;
    private final String INVENTARIO_SERVICE_URL = "http://localhost:8082/api/v1/inventario/";

    public InventarioClient(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    public boolean verificarItemDisponible(Long inventarioId) {
        try {
            restTemplate.getForEntity(INVENTARIO_SERVICE_URL + inventarioId, Object.class);
            return true;
        } catch (HttpClientErrorException.NotFound e) {
            return false;
        } catch (Exception e) {
            System.out.println("Error al conectar con MSInventario: " + e.getMessage());
            return false;
        }
    }
}