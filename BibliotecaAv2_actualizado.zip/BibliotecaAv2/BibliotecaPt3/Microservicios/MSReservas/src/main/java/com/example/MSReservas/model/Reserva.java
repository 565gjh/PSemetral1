package com.example.MSReservas.model;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.EqualsAndHashCode;
import org.springframework.hateoas.RepresentationModel;
import java.time.LocalDateTime;

@Entity
@Table(name = "reservas")
@Data
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = false)
@Schema(description = "Reserva de un libro que no está disponible en inventario en el momento de la solicitud")
public class Reserva extends RepresentationModel<Reserva> {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Schema(description = "Identificador único de la reserva", example = "1", accessMode = Schema.AccessMode.READ_ONLY)
    private Long id;

    @NotNull(message = "El ID del libro es obligatorio")
    @Schema(description = "ID del libro a reservar (de MSCatalogo)", example = "3", requiredMode = Schema.RequiredMode.REQUIRED)
    private Long libroId;

    @NotNull(message = "El ID del usuario es obligatorio")
    @Schema(description = "ID del usuario que realiza la reserva (de MSusuario)", example = "7", requiredMode = Schema.RequiredMode.REQUIRED)
    private Long usuarioId;

    @NotNull(message = "La posición en la fila es obligatoria")
    @Min(value = 1, message = "La posición debe ser al menos 1")
    @Schema(description = "Posición del usuario en la lista de espera para ese libro", example = "2", minimum = "1", requiredMode = Schema.RequiredMode.REQUIRED)
    private Integer posicionFila;

    @Schema(description = "Fecha y hora en que se realizó la reserva", example = "2024-06-01T11:00:00", accessMode = Schema.AccessMode.READ_ONLY)
    private LocalDateTime fechaReserva;

    @NotBlank(message = "El estado es obligatorio (ACTIVA/CANCELADA/COMPLETADA)")
    @Schema(description = "Estado de la reserva", example = "ACTIVA", allowableValues = {"ACTIVA", "CANCELADA", "COMPLETADA"}, requiredMode = Schema.RequiredMode.REQUIRED)
    private String estado;
}
