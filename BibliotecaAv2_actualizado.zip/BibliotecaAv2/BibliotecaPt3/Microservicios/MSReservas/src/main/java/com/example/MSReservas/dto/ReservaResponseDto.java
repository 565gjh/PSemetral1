package com.example.MSReservas.dto;

import org.springframework.hateoas.RepresentationModel;
import java.time.LocalDateTime;

public class ReservaResponseDto extends RepresentationModel<ReservaResponseDto> {
    private Long id;
    private LocalDateTime fechaReserva;
    private Integer posicionFila;
    private String estado;
    private UsuarioDto usuario;
    private LibroDto libro;

    public ReservaResponseDto() {}

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public LocalDateTime getFechaReserva() { return fechaReserva; }
    public void setFechaReserva(LocalDateTime fechaReserva) { this.fechaReserva = fechaReserva; }

    public Integer getPosicionFila() { return posicionFila; }
    public void setPosicionFila(Integer posicionFila) { this.posicionFila = posicionFila; }

    public String getEstado() { return estado; }
    public void setEstado(String estado) { this.estado = estado; }

    public UsuarioDto getUsuario() { return usuario; }
    public void setUsuario(UsuarioDto usuario) { this.usuario = usuario; }

    public LibroDto getLibro() { return libro; }
    public void setLibro(LibroDto libro) { this.libro = libro; }
}
