package com.example.MSCatalogo.repository;

import com.example.MSCatalogo.model.Categoria;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CategoriaRepository extends JpaRepository<Categoria, Long> {
    // Hereda todos los métodos de JPA para la tabla categorias
}