package com.example.MSCatalogo.model;

import jakarta.persistence.*;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Entity
@Table(name = "autores")
public class Autor {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, length = 100)
    private String nombre;

    @Column(length = 50)
    private String nacionalidad;

    // COMUNICACIÓN JPA: Un Autor tiene MUCHOS Libros.
    // 'mappedBy' indica que la relación la gobierna el campo 'autor' en la clase Libro.
    // 'JsonIgnoreProperties' evita bucles infinitos al convertir a JSON.
    @OneToMany(mappedBy = "autor", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @JsonIgnoreProperties("autor")
    private List<Libro> libros = new ArrayList<>();



}