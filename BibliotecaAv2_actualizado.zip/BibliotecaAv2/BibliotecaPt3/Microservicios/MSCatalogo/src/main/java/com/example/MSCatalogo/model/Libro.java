package com.example.MSCatalogo.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.EqualsAndHashCode;
import org.springframework.hateoas.RepresentationModel;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Entity
@Table(name = "libros")
@EqualsAndHashCode(callSuper = false)
@Schema(description = "Entidad que representa un libro en el catálogo de la biblioteca")
public class Libro extends RepresentationModel<Libro> {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Schema(description = "Identificador único del libro en el catálogo", example = "1", accessMode = Schema.AccessMode.READ_ONLY)
    private Long id;

    @Column(nullable = false, length = 150)
    @Schema(description = "Título del libro", example = "Cien Años de Soledad", requiredMode = Schema.RequiredMode.REQUIRED)
    private String titulo;

    @Column(nullable = false, unique = true, length = 20)
    @Schema(description = "ISBN único del libro", example = "978-0-06-093546-9", requiredMode = Schema.RequiredMode.REQUIRED)
    private String isbn;

    @ManyToOne(fetch = FetchType.EAGER, optional = false)
    @JoinColumn(name = "autor_id", nullable = false)
    @JsonIgnoreProperties("libros")
    @Schema(description = "Autor del libro. Debe ser un autor existente en el sistema.")
    private Autor autor;

    @ManyToOne(fetch = FetchType.EAGER, optional = false)
    @JoinColumn(name = "categoria_id", nullable = false)
    @JsonIgnoreProperties("libros")
    @Schema(description = "Categoría del libro. Debe ser una categoría existente en el sistema.")
    private Categoria categoria;
}
