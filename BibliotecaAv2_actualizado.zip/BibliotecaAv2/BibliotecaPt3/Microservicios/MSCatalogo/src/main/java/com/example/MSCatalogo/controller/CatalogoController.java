package com.example.MSCatalogo.controller;

import com.example.MSCatalogo.model.Autor;
import com.example.MSCatalogo.model.Categoria;
import com.example.MSCatalogo.model.Libro;
import com.example.MSCatalogo.service.CatalogoService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;

@RestController
@RequestMapping("/api/v1/catalogo")
@Slf4j
@SecurityRequirement(name = "bearerAuth")
@Tag(name = "Catálogo", description = "Gestión del catálogo de libros, autores y categorías de la biblioteca")
public class CatalogoController {

    @Autowired
    private CatalogoService catalogoService;

    @Operation(
            summary = "Listar todos los libros",
            description = "Retorna el catálogo completo de libros con enlaces HATEOAS a cada libro individual, permitiendo navegar directamente a su detalle."
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Catálogo retornado correctamente"),
            @ApiResponse(responseCode = "401", description = "No autenticado"),
            @ApiResponse(responseCode = "403", description = "Sin permisos suficientes")
    })
    @GetMapping
    @PreAuthorize("hasAnyRole('ADMIN', 'USUARIO', 'TRABAJADOR')")
    public ResponseEntity<List<Libro>> obtenerTodos() {
        log.info("Obteniendo catálogo completo");
        List<Libro> libros = catalogoService.obtenerCatalogoCompleto();
        libros.forEach(libro -> {
            libro.add(linkTo(methodOn(CatalogoController.class).obtenerPorId(libro.getId())).withSelfRel());
            libro.add(linkTo(methodOn(CatalogoController.class).obtenerTodos()).withRel("catalogo"));
            libro.add(linkTo(methodOn(CatalogoController.class).crearLibro(null)).withRel("crear-libro"));
        });
        return ResponseEntity.ok(libros);
    }

    @Operation(
            summary = "Buscar libro por ID",
            description = "Retorna el libro del catálogo con el ID especificado, incluyendo su autor, categoría y enlaces HATEOAS para volver al catálogo o crear nuevos libros."
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Libro encontrado"),
            @ApiResponse(responseCode = "404", description = "Libro no encontrado en el catálogo"),
            @ApiResponse(responseCode = "401", description = "No autenticado")
    })
    @GetMapping("/libro/{id}")
    @PreAuthorize("hasAnyRole('ADMIN', 'USUARIO', 'TRABAJADOR')")
    public ResponseEntity<?> obtenerPorId(@PathVariable Long id) {
        try {
            Libro libro = catalogoService.obtenerPorId(id);
            libro.add(linkTo(methodOn(CatalogoController.class).obtenerPorId(id)).withSelfRel());
            libro.add(linkTo(methodOn(CatalogoController.class).obtenerTodos()).withRel("catalogo"));
            libro.add(linkTo(methodOn(CatalogoController.class).crearAutor(null)).withRel("crear-autor"));
            libro.add(linkTo(methodOn(CatalogoController.class).crearCategoria(null)).withRel("crear-categoria"));
            return ResponseEntity.ok(libro);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(Map.of("error", e.getMessage()));
        }
    }

    @Operation(
            summary = "Crear nuevo libro",
            description = "Registra un nuevo libro en el catálogo. Retorna el libro creado con enlaces HATEOAS para consultar su detalle, ver el catálogo completo o agregar más libros."
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "201", description = "Libro creado correctamente"),
            @ApiResponse(responseCode = "400", description = "Datos inválidos o ISBN duplicado"),
            @ApiResponse(responseCode = "401", description = "No autenticado"),
            @ApiResponse(responseCode = "403", description = "Sin permisos suficientes")
    })
    @PostMapping("/libro")
    @PreAuthorize("hasAnyRole('ADMIN', 'USUARIO', 'TRABAJADOR')")
    public ResponseEntity<?> crearLibro(@RequestBody Libro libro) {
        try {
            Libro nuevoLibro = catalogoService.guardarLibroEnCatalogo(libro);
            nuevoLibro.add(linkTo(methodOn(CatalogoController.class).obtenerPorId(nuevoLibro.getId())).withSelfRel());
            nuevoLibro.add(linkTo(methodOn(CatalogoController.class).obtenerTodos()).withRel("catalogo"));
            nuevoLibro.add(linkTo(methodOn(CatalogoController.class).crearLibro(null)).withRel("crear-otro-libro"));
            nuevoLibro.add(linkTo(methodOn(CatalogoController.class).crearAutor(null)).withRel("crear-autor"));
            nuevoLibro.add(linkTo(methodOn(CatalogoController.class).crearCategoria(null)).withRel("crear-categoria"));
            return ResponseEntity.status(HttpStatus.CREATED).body(nuevoLibro);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(Map.of("error", e.getMessage()));
        }
    }

    @Operation(
            summary = "Crear nuevo autor",
            description = "Registra un nuevo autor. Retorna el autor creado con enlace HATEOAS para crear el libro que le pertenece a continuación."
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "201", description = "Autor creado correctamente"),
            @ApiResponse(responseCode = "401", description = "No autenticado"),
            @ApiResponse(responseCode = "403", description = "Sin permisos suficientes")
    })
    @PostMapping("/autor")
    @PreAuthorize("hasAnyRole('ADMIN', 'USUARIO', 'TRABAJADOR')")
    public ResponseEntity<Autor> crearAutor(@RequestBody Autor autor) {
        return ResponseEntity.status(HttpStatus.CREATED).body(catalogoService.guardarAutor(autor));
    }

    @Operation(
            summary = "Crear nueva categoría",
            description = "Registra una nueva categoría (por ejemplo: Ficción, Historia, Ciencia). Retorna la categoría creada con enlace HATEOAS para crear un libro en esa categoría."
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "201", description = "Categoría creada correctamente"),
            @ApiResponse(responseCode = "401", description = "No autenticado"),
            @ApiResponse(responseCode = "403", description = "Sin permisos suficientes")
    })
    @PostMapping("/categoria")
    @PreAuthorize("hasAnyRole('ADMIN', 'USUARIO', 'TRABAJADOR')")
    public ResponseEntity<Categoria> crearCategoria(@RequestBody Categoria categoria) {
        return ResponseEntity.status(HttpStatus.CREATED).body(catalogoService.guardarCategoria(categoria));
    }
}
