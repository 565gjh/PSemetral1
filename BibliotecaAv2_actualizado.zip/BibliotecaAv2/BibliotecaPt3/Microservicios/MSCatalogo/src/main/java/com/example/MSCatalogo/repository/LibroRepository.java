package com.example.MSCatalogo.repository;

import com.example.MSCatalogo.model.Libro;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface LibroRepository extends JpaRepository<Libro, Long> {
    // Hereda todos los métodos de JPA para la tabla libros
}
