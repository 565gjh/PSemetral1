package com.example.MSCatalogo.repository;

import com.example.MSCatalogo.model.Autor;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface AutorRepository extends JpaRepository<Autor, Long> {
    // Hereda todos los métodos de JPA para la tabla autores
}