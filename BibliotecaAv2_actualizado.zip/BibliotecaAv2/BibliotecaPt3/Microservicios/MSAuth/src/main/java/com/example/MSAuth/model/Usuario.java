package com.example.MSAuth.model;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.EqualsAndHashCode;
import org.springframework.hateoas.RepresentationModel;

@Entity
@Table(name = "usuarios")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@EqualsAndHashCode(callSuper = false)
@Schema(description = "Entidad de autenticación que representa las credenciales de un usuario del sistema de biblioteca")
public class Usuario extends RepresentationModel<Usuario> {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Schema(description = "Identificador único del usuario de autenticación", example = "1", accessMode = Schema.AccessMode.READ_ONLY)
    private Long id;

    @Column(name = "correo", nullable = false, unique = true, length = 150)
    @Schema(description = "Correo electrónico del usuario, usado también como identificador único", example = "juan@biblioteca.cl", requiredMode = Schema.RequiredMode.REQUIRED)
    private String email;

    @Column(nullable = false, unique = true)
    @Schema(description = "Nombre de usuario para el login", example = "juanperez", requiredMode = Schema.RequiredMode.REQUIRED)
    private String username;

    @Column(nullable = false)
    @Schema(description = "Contraseña cifrada con BCrypt", example = "$2a$10$...", accessMode = Schema.AccessMode.WRITE_ONLY)
    private String password;

    @Column(nullable = false)
    @Schema(description = "Rol del usuario en el sistema: USUARIO, ADMIN o TRABAJADOR", example = "USUARIO", requiredMode = Schema.RequiredMode.REQUIRED)
    private String rol;

    @Column(nullable = false)
    @Schema(description = "Indica si el usuario está activo en el sistema", example = "true")
    private Boolean estado;
}
