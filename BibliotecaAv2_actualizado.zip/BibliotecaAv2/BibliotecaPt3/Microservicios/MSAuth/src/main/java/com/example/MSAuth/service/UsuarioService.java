package com.example.MSAuth.service;

import com.example.MSAuth.model.RegistroUsuarioDTO; // Tu clase DTO
import com.example.MSAuth.client.UsuarioClient;
import com.example.MSAuth.model.Usuario;
import com.example.MSAuth.repository.UsuarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;
import java.util.Map;

@Service
public class UsuarioService {

    @Autowired
    private UsuarioRepository usuarioRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private UsuarioClient usuarioClient;

    // 1. CREATE (Guardar usuario con contraseña encriptada)
    public void register(Map<String, String> body, String rol, boolean estado) {

        // 1. Guardar las credenciales en la base de datos local (ms-auth)
        Usuario nuevoUsuario = new Usuario();
        nuevoUsuario.setUsername(body.get("username"));
        // Asumiendo que usas un passwordEncoder de Spring Security:
        nuevoUsuario.setPassword(passwordEncoder.encode(body.get("password")));
        nuevoUsuario.setEmail(body.get("email"));
        nuevoUsuario.setRol(rol);
        nuevoUsuario.setEstado(estado);

        Usuario guardado = usuarioRepository.save(nuevoUsuario);

        // 2. Preparar el paquete de datos para ms-usuarios (usando el DTO de tu paquete 'model')
        RegistroUsuarioDTO perfilParaEnviar = new RegistroUsuarioDTO();
        perfilParaEnviar.setAuthId(guardado.getId()); // El ID que acabas de generar
        perfilParaEnviar.setNombre1(body.get("nombre1"));
        perfilParaEnviar.setApellido1(body.get("apellido1"));
        perfilParaEnviar.setEmail(body.get("email"));
        perfilParaEnviar.setTipoUsuario(rol);

        // 3. Enviar hacia ms-usuarios usando tu cliente HTTP
        usuarioClient.enviarPerfil(perfilParaEnviar).block();
    }


    // 2. READ (Obtener todos)
    public List<Usuario> obtenerTodos() {
        return usuarioRepository.findAll();
    }

    // 3. UPDATE
    public Usuario actualizarUsuario(Long id, Usuario datosActualizados) {
        return usuarioRepository.findById(id).map(usuario -> {
            usuario.setEstado(datosActualizados.getEstado());

            // Solo re-encriptar si el usuario envía una nueva contraseña
            if (datosActualizados.getPassword() != null && !datosActualizados.getPassword().isEmpty()) {
                usuario.setPassword(passwordEncoder.encode(datosActualizados.getPassword()));
            }
            return usuarioRepository.save(usuario);
        }).orElseThrow(() -> new RuntimeException("Usuario no encontrado con id: " + id));
    }
    public Usuario findById(Long id){
        return usuarioRepository.findById(id).get();
    }
    public Optional<Usuario> findByUsername(String username) {
        return usuarioRepository.findByUsername(username);
    }
    public Optional<Usuario> findByEmail(String email) {return usuarioRepository.findByEmail(email);}
    public List<Usuario> findByEstado(boolean estado) { return usuarioRepository.findByEstado(estado);}

}