package com.example.MSAuth.controller;

import com.example.MSAuth.model.Usuario;
import com.example.MSAuth.security.jwt.JwtService;
import com.example.MSAuth.service.UsuarioService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.hateoas.Link;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.*;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;

@RestController
@RequestMapping("/api/v1/auth")
@Tag(name = "Autenticación", description = "Endpoints para registro, login y consulta de usuarios del sistema de biblioteca")
public class AuthController {

    private final AuthenticationManager authManager;
    private final JwtService jwtService;
    private final UsuarioService usuarioService;

    public AuthController(AuthenticationManager authManager, JwtService jwtService, UsuarioService usuarioService) {
        this.authManager = authManager;
        this.jwtService = jwtService;
        this.usuarioService = usuarioService;
    }

    @Operation(
            summary = "Registrar nuevo usuario",
            description = "Crea un usuario de autenticación con username, password, email y rol. Propaga el perfil a MSusuario. La respuesta incluye enlace HATEOAS al endpoint de login para que el cliente pueda autenticarse de inmediato."
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "201", description = "Usuario registrado correctamente"),
            @ApiResponse(responseCode = "400", description = "Datos inválidos o rol no permitido"),
            @ApiResponse(responseCode = "409", description = "El username o email ya existe")
    })
    @PostMapping("/register")
    public ResponseEntity<?> register(@RequestBody Map<String, String> body) {
        try {
            String username = body.get("username");
            String password = body.get("password");
            String email    = body.get("email");
            String rol      = body.getOrDefault("rol", "USUARIO");
            String nombre1  = body.get("nombre1");
            String apellido1 = body.get("apellido1");
            boolean estado  = true;

            if (username == null || password == null || username.isBlank() || password.isBlank() ||
                    nombre1 == null || apellido1 == null || email == null) {
                return ResponseEntity.badRequest()
                        .body(Map.of("error", "Username, password, email, nombre1 y apellido1 son requeridos"));
            }

            if (!rol.equals("USUARIO") && !rol.equals("ADMIN") && !rol.equals("TRABAJADOR")) {
                return ResponseEntity.badRequest()
                        .body(Map.of("error", "Debes especificar un rol válido (USUARIO, ADMIN o TRABAJADOR)"));
            }

            usuarioService.register(body, rol, estado);

            // Tras registrarse el cliente debe ir directamente al login
            Link loginLink = linkTo(methodOn(AuthController.class).login(null)).withRel("login");
            Link todosLink = linkTo(methodOn(AuthController.class).obtenerTodos()).withRel("todos-los-usuarios");

            return ResponseEntity.status(HttpStatus.CREATED).body(Map.of(
                    "message", "Usuario registrado correctamente",
                    "rol", rol,
                    "_links", Map.of(
                            "login", Map.of("href", loginLink.getHref()),
                            "todos-los-usuarios", Map.of("href", todosLink.getHref())
                    )
            ));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.CONFLICT)
                    .body(Map.of("error", "Error al registrar el usuario: " + e.getMessage()));
        }
    }

    @Operation(
            summary = "Iniciar sesión",
            description = "Autentica al usuario con username y password. Devuelve un token JWT y enlaces HATEOAS: el perfil del usuario en MSusuario y el endpoint de validación para que el gateway pueda verificar el token."
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Login exitoso, se devuelve token JWT"),
            @ApiResponse(responseCode = "401", description = "Credenciales incorrectas"),
            @ApiResponse(responseCode = "500", description = "Error interno del servidor")
    })
    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody Map<String, String> body) {
        try {
            String username = body.get("username");
            String password = body.get("password");

            Authentication auth = authManager.authenticate(
                    new UsernamePasswordAuthenticationToken(username, password));

            if (auth.isAuthenticated()) {
                Usuario usuario = usuarioService.findByUsername(username)
                        .orElseThrow(() -> new RuntimeException("Usuario no encontrado"));
                String token = jwtService.generateToken(username, usuario.getRol());

                // Tras el login el cliente necesita: validar el token y ver su perfil en MSusuario
                Link validateLink  = linkTo(methodOn(AuthController.class).validateToken()).withRel("validar-token");
                Link perfilLink    = Link.of("/api/v1/usuarios/email/" + usuario.getEmail()).withRel("perfil-en-msusuario");

                return ResponseEntity.ok(Map.of(
                        "token", token,
                        "username", username,
                        "rol", usuario.getRol(),
                        "_links", Map.of(
                                "validar-token",       Map.of("href", validateLink.getHref()),
                                "perfil-en-msusuario", Map.of("href", perfilLink.getHref())
                        )
                ));
            }
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                    .body(Map.of("error", "Credenciales inválidas"));

        } catch (BadCredentialsException e) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                    .body(Map.of("error", "Usuario o contraseña incorrectos"));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Map.of("error", "Error al procesar la solicitud"));
        }
    }

    @Operation(
            summary = "Validar token JWT",
            description = "Verifica que el token JWT del header Authorization sea válido. Usado por el API Gateway. Si es válido, incluye enlace HATEOAS al listado de usuarios."
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Token válido"),
            @ApiResponse(responseCode = "401", description = "Token inválido o expirado")
    })
    @SecurityRequirement(name = "bearerAuth")
    @GetMapping("/validate")
    public ResponseEntity<?> validateToken() {
        Link todosLink = linkTo(methodOn(AuthController.class).obtenerTodos()).withRel("todos-los-usuarios");
        return ResponseEntity.ok(Map.of(
                "valid", true,
                "_links", Map.of("todos-los-usuarios", Map.of("href", todosLink.getHref()))
        ));
    }

    @Operation(
            summary = "Obtener todos los usuarios",
            description = "Retorna la lista completa de usuarios de autenticación con enlaces HATEOAS a su detalle individual y al perfil en MSusuario. Usuarios inactivos incluyen enlace a filtro por estado."
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Lista de usuarios retornada correctamente"),
            @ApiResponse(responseCode = "401", description = "No autenticado"),
            @ApiResponse(responseCode = "403", description = "Sin permisos")
    })
    @SecurityRequirement(name = "bearerAuth")
    @GetMapping
    public ResponseEntity<List<Usuario>> obtenerTodos() {
        List<Usuario> usuarios = usuarioService.obtenerTodos();
        usuarios.forEach(u -> {
            u.add(linkTo(methodOn(AuthController.class).findById(u.getId())).withSelfRel());
            u.add(linkTo(methodOn(AuthController.class).findByUsername(u.getUsername())).withRel("buscar-por-username"));
            u.add(linkTo(methodOn(AuthController.class).findByEmail(u.getEmail())).withRel("buscar-por-email"));
            // Enlace al perfil extendido en MSusuario
            u.add(Link.of("/api/v1/usuarios/email/" + u.getEmail()).withRel("perfil-en-msusuario"));
            // Si está inactivo, ofrecer enlace para ver todos los inactivos
            if (Boolean.FALSE.equals(u.getEstado())) {
                u.add(linkTo(methodOn(AuthController.class).findByEstado(false)).withRel("ver-usuarios-inactivos"));
            }
        });
        return ResponseEntity.ok(usuarios);
    }

    @Operation(
            summary = "Buscar usuario por ID",
            description = "Retorna el usuario de autenticación con el ID especificado. Incluye enlace HATEOAS al perfil completo en MSusuario y a la búsqueda por username."
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Usuario encontrado"),
            @ApiResponse(responseCode = "404", description = "Usuario no encontrado"),
            @ApiResponse(responseCode = "401", description = "No autenticado")
    })
    @SecurityRequirement(name = "bearerAuth")
    @GetMapping("/id/{id}")
    public ResponseEntity<Usuario> findById(@PathVariable Long id) {
        try {
            Usuario usuario = usuarioService.findById(id);
            usuario.add(linkTo(methodOn(AuthController.class).findById(id)).withSelfRel());
            usuario.add(linkTo(methodOn(AuthController.class).obtenerTodos()).withRel("todos"));
            usuario.add(linkTo(methodOn(AuthController.class).findByUsername(usuario.getUsername())).withRel("buscar-por-username"));
            usuario.add(Link.of("/api/v1/usuarios/email/" + usuario.getEmail()).withRel("perfil-en-msusuario"));
            // Si está inactivo, enlace a filtrado por estado para ver todos los inactivos
            if (Boolean.FALSE.equals(usuario.getEstado())) {
                usuario.add(linkTo(methodOn(AuthController.class).findByEstado(false)).withRel("ver-usuarios-inactivos"));
            }
            return ResponseEntity.ok(usuario);
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }

    @Operation(
            summary = "Buscar usuario por username",
            description = "Retorna el usuario cuyo username coincida, con enlace HATEOAS al perfil extendido en MSusuario."
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Usuario encontrado"),
            @ApiResponse(responseCode = "404", description = "Username no registrado"),
            @ApiResponse(responseCode = "401", description = "No autenticado")
    })
    @SecurityRequirement(name = "bearerAuth")
    @GetMapping("/username/{username}")
    public ResponseEntity<Usuario> findByUsername(@PathVariable String username) {
        return usuarioService.findByUsername(username)
                .map(u -> {
                    u.add(linkTo(methodOn(AuthController.class).findByUsername(username)).withSelfRel());
                    u.add(linkTo(methodOn(AuthController.class).findById(u.getId())).withRel("buscar-por-id"));
                    u.add(linkTo(methodOn(AuthController.class).obtenerTodos()).withRel("todos"));
                    u.add(Link.of("/api/v1/usuarios/email/" + u.getEmail()).withRel("perfil-en-msusuario"));
                    return ResponseEntity.ok(u);
                })
                .orElse(ResponseEntity.notFound().build());
    }

    @Operation(
            summary = "Buscar usuario por email",
            description = "Retorna el usuario cuyo correo electrónico coincida, con enlace HATEOAS al perfil en MSusuario."
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Usuario encontrado"),
            @ApiResponse(responseCode = "404", description = "Email no registrado"),
            @ApiResponse(responseCode = "401", description = "No autenticado")
    })
    @SecurityRequirement(name = "bearerAuth")
    @GetMapping("/email/{email}")
    public ResponseEntity<Usuario> findByEmail(@PathVariable String email) {
        return usuarioService.findByEmail(email)
                .map(u -> {
                    u.add(linkTo(methodOn(AuthController.class).findByEmail(email)).withSelfRel());
                    u.add(linkTo(methodOn(AuthController.class).findById(u.getId())).withRel("buscar-por-id"));
                    u.add(linkTo(methodOn(AuthController.class).obtenerTodos()).withRel("todos"));
                    u.add(Link.of("/api/v1/usuarios/email/" + u.getEmail()).withRel("perfil-en-msusuario"));
                    return ResponseEntity.ok(u);
                })
                .orElse(ResponseEntity.notFound().build());
    }

    @Operation(
            summary = "Filtrar usuarios por estado",
            description = "Retorna la lista de usuarios activos (true) o inactivos (false), cada uno con enlace HATEOAS a su detalle y al perfil en MSusuario."
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Lista retornada correctamente"),
            @ApiResponse(responseCode = "404", description = "No hay usuarios con ese estado"),
            @ApiResponse(responseCode = "401", description = "No autenticado")
    })
    @SecurityRequirement(name = "bearerAuth")
    @GetMapping("/estado/{estado}")
    public ResponseEntity<List<Usuario>> findByEstado(@PathVariable boolean estado) {
        try {
            List<Usuario> usuarios = usuarioService.findByEstado(estado);
            usuarios.forEach(u -> {
                u.add(linkTo(methodOn(AuthController.class).findById(u.getId())).withSelfRel());
                u.add(linkTo(methodOn(AuthController.class).obtenerTodos()).withRel("todos"));
                u.add(Link.of("/api/v1/usuarios/email/" + u.getEmail()).withRel("perfil-en-msusuario"));
            });
            return ResponseEntity.ok(usuarios);
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }
}
