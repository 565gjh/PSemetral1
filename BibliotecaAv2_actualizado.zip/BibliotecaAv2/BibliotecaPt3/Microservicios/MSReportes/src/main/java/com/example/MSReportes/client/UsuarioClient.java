package com.example.MSReportes.client;

import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Flux;

@Component
public class UsuarioClient {

    private final WebClient usuarioWebClient;

    public UsuarioClient(WebClient usuarioWebClient) {
        this.usuarioWebClient = usuarioWebClient;
    }

    public Flux<Object> obtenerTodosLosUsuarios() {
        return this.usuarioWebClient.get()
                .retrieve()
                .bodyToFlux(Object.class) // Cambiable por UsuarioDTO en el futuro si gustas
                .onErrorResume(e -> Flux.empty());
    }
}