package com.example.MSReportes.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.reactive.function.client.WebClient;

@Configuration
public class WebClientConfig {

    @Bean
    public WebClient prestamoWebClient() {
        return WebClient.builder()
                // Asumimos el puerto de MSPrestamo. Modifícalo si usas otro.
                .baseUrl("http://localhost:8080/api/v1/prestamos")
                .build();
    }

    @Bean
    public WebClient usuarioWebClient() {
        return WebClient.builder()
                // Puerto de MSUsuario
                .baseUrl("http://localhost:8081/api/v1/usuarios")
                .build();
    }
}