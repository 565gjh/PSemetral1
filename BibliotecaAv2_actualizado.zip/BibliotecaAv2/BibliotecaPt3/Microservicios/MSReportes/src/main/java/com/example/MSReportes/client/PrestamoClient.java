package com.example.MSReportes.client;

import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Flux;

@Component
public class PrestamoClient {

    private final WebClient prestamoWebClient;

    public PrestamoClient(WebClient prestamoWebClient) {
        this.prestamoWebClient = prestamoWebClient;
    }

    // Usamos Flux porque el reporte usualmente necesita una LISTA (flujo) de datos, no uno solo
    public Flux<Object> obtenerTodosLosPrestamos() {
        return this.prestamoWebClient.get()
                .retrieve()
                .bodyToFlux(Object.class) // Puedes cambiar 'Object' por tu PrestamoDTO si lo tienes mapeado
                .onErrorResume(e -> Flux.empty());
    }
}