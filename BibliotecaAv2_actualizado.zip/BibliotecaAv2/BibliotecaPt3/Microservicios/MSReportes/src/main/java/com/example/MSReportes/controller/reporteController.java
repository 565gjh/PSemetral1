package com.example.MSReportes.controller;

import com.example.MSReportes.model.Reporte;
import com.example.MSReportes.service.reporteService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.Link;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;

@RestController
@RequestMapping("/api/v1/reportes")
@SecurityRequirement(name = "bearerAuth")
@Tag(name = "Reportes", description = "Generación y consulta de reportes estadísticos: uso de libros, actividad de usuarios e inventario")
public class reporteController {

    @Autowired
    private reporteService service;

    @Operation(
            summary = "Listar todos los reportes",
            description = "Retorna todos los reportes generados con enlaces HATEOAS a cada uno. Los reportes de tipo 'Stock' incluyen enlace al inventario para navegar directamente; los de tipo 'Uso' incluyen enlace al catálogo."
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Lista de reportes retornada correctamente"),
            @ApiResponse(responseCode = "401", description = "No autenticado")
    })
    @GetMapping
    public List<Reporte> findAll() {
        List<Reporte> reportes = service.findAll();
        reportes.forEach(r -> {
            r.add(linkTo(methodOn(reporteController.class).findById(r.getId())).withSelfRel());
            r.add(linkTo(methodOn(reporteController.class).findAll()).withRel("todos"));
            r.add(linkTo(methodOn(reporteController.class).delete(r.getId())).withRel("eliminar"));
            // Enlace contextual según el tipo de reporte
            if ("Stock".equals(r.getTipoReporte())) {
                r.add(Link.of("/api/v1/inventario").withRel("ver-inventario"));
            } else if ("Uso".equals(r.getTipoReporte())) {
                r.add(Link.of("/api/v1/catalogo").withRel("ver-catalogo"));
            } else if ("Actividad".equals(r.getTipoReporte())) {
                r.add(Link.of("/api/v1/prestamos").withRel("ver-prestamos"));
            }
        });
        return reportes;
    }

    @Operation(
            summary = "Buscar reporte por ID",
            description = "Retorna el reporte con el ID especificado. Incluye enlaces HATEOAS contextuales: reportes de Stock llevan al inventario, de Uso al catálogo y de Actividad a préstamos."
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Reporte encontrado"),
            @ApiResponse(responseCode = "404", description = "Reporte no encontrado"),
            @ApiResponse(responseCode = "401", description = "No autenticado")
    })
    @GetMapping("/{id}")
    public ResponseEntity<Reporte> findById(@PathVariable Long id) {
        Reporte reporte = service.findById(id);
        if (reporte == null) return ResponseEntity.notFound().build();

        reporte.add(linkTo(methodOn(reporteController.class).findById(id)).withSelfRel());
        reporte.add(linkTo(methodOn(reporteController.class).findAll()).withRel("todos"));
        reporte.add(linkTo(methodOn(reporteController.class).delete(id)).withRel("eliminar"));
        if ("Stock".equals(reporte.getTipoReporte())) {
            reporte.add(Link.of("/api/v1/inventario").withRel("ver-inventario"));
        } else if ("Uso".equals(reporte.getTipoReporte())) {
            reporte.add(Link.of("/api/v1/catalogo").withRel("ver-catalogo"));
        } else if ("Actividad".equals(reporte.getTipoReporte())) {
            reporte.add(Link.of("/api/v1/prestamos").withRel("ver-prestamos"));
        }
        return ResponseEntity.ok(reporte);
    }

    @Operation(
            summary = "Generar nuevo reporte",
            description = "Crea un reporte de tipo Uso, Actividad o Stock. Retorna el reporte con enlaces HATEOAS que guían al recurso fuente correspondiente para facilitar auditoría."
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "201", description = "Reporte creado correctamente"),
            @ApiResponse(responseCode = "400", description = "Datos inválidos: tipo, datosJson o generadoPor faltantes"),
            @ApiResponse(responseCode = "401", description = "No autenticado")
    })
    @PostMapping
    public ResponseEntity<Reporte> save(@Valid @RequestBody Reporte reporte) {
        Reporte nuevo = service.save(reporte);
        nuevo.add(linkTo(methodOn(reporteController.class).findById(nuevo.getId())).withSelfRel());
        nuevo.add(linkTo(methodOn(reporteController.class).findAll()).withRel("todos"));
        if ("Stock".equals(nuevo.getTipoReporte())) {
            nuevo.add(Link.of("/api/v1/inventario").withRel("ver-inventario"));
        } else if ("Uso".equals(nuevo.getTipoReporte())) {
            nuevo.add(Link.of("/api/v1/catalogo").withRel("ver-catalogo"));
        } else if ("Actividad".equals(nuevo.getTipoReporte())) {
            nuevo.add(Link.of("/api/v1/prestamos").withRel("ver-prestamos"));
        }
        return new ResponseEntity<>(nuevo, HttpStatus.CREATED);
    }

    @Operation(
            summary = "Eliminar reporte",
            description = "Elimina un reporte del sistema por su ID."
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Reporte eliminado correctamente"),
            @ApiResponse(responseCode = "404", description = "Reporte no encontrado"),
            @ApiResponse(responseCode = "401", description = "No autenticado")
    })
    @DeleteMapping("/{id}")
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}
