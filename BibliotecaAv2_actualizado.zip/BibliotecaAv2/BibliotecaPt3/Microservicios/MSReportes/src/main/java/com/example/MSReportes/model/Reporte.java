package com.example.MSReportes.model;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.EqualsAndHashCode;
import org.springframework.hateoas.RepresentationModel;
import java.time.LocalDateTime;

@Entity
@Table(name = "reportes")
@Data
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = false)
@Schema(description = "Reporte estadístico generado por el sistema de biblioteca")
public class Reporte extends RepresentationModel<Reporte> {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Schema(description = "Identificador único del reporte", example = "1", accessMode = Schema.AccessMode.READ_ONLY)
    private Long id;

    @NotBlank(message = "El tipo de reporte es obligatorio (Uso/Actividad/Stock)")
    @Schema(description = "Tipo de reporte generado", example = "Uso", allowableValues = {"Uso", "Actividad", "Stock"}, requiredMode = Schema.RequiredMode.REQUIRED)
    private String tipoReporte;

    @NotBlank(message = "El contenido del reporte es obligatorio")
    @Column(columnDefinition = "TEXT")
    @Schema(description = "Datos del reporte en formato JSON string", example = "{\"totalPrestamos\": 120, \"libroMasPrestado\": \"Cien Años de Soledad\"}", requiredMode = Schema.RequiredMode.REQUIRED)
    private String datosJson;

    @NotBlank(message = "El autor del reporte es obligatorio")
    @Schema(description = "Username del administrador o trabajador que generó el reporte", example = "admin_biblioteca", requiredMode = Schema.RequiredMode.REQUIRED)
    private String generadoPor;

    @Schema(description = "Fecha y hora en que se creó el reporte", example = "2024-06-01T08:00:00", accessMode = Schema.AccessMode.READ_ONLY)
    private LocalDateTime fechaCreacion;
}
