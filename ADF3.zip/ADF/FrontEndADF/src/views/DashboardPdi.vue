<template>
  <div class="dashboard-container">
    <aside class="sidebar">
      <div class="brand-logo-card">
        <img src="../assets/pdi.png" alt="Aduanas Chile" class="logo-img" />
        <div class="logo-divider"></div>
        <p class="logo-subtitle">Central Aduanas</p>
      </div>
      
      <div class="menu">
        <button 
          class="menu-item" 
          :class="{ 'activo': vistaActual === 'control' }"
          @click="cambiarVista('control')"
        >
          🛂 Control Migratorio
        </button>

        <button class="menu-item">
          🚨 Alertas Interpol
        </button>

        <button 
          class="menu-item" 
          :class="{ 'activo': vistaActual === 'consultas' }"
          @click="cambiarVista('consultas')"
        >
          📄 Consultar Pasajeros
        </button>
      </div>

      <div class="sidebar-footer">
        <div class="user-info">
          <p class="user-name">FuncionarioPDI</p>
          <p class="user-rut">RUT: {{ officerRut }}</p>
        </div>
        <button @click="handleLogout" class="btn-logout">Cerrar Sesión</button>
      </div>
    </aside>

    <main class="main-content">
      <header class="content-header">
        <div class="welcome">
          <h1>Jefatura Nacional de Migraciones y Policía Internacional</h1>
          <p>Sistema de control fronterizo, validación de identidad y permisos de menores.</p>
        </div>
        <button @click="mostrarModalRegistro = true" class="btn-registrar-pasajero">
           Registrar Pasajero
        </button>
      </header>

      <section class="stats-grid">
        <div class="stat-card">
          <div class="stat-icon blue">🛂</div>
          <div>
            <h3>Pasajeros Controlados</h3>
            <p class="stat-number">2,845</p>
          </div>
        </div>
        <div class="stat-card alert">
          <div class="stat-icon red">🚨</div>
          <div>
            <h3>Órdenes de Arraigo / Rechazos</h3>
            <p class="stat-number">7</p>
          </div>
        </div>
        <div class="stat-card warning">
          <div class="stat-icon orange">👶</div>
          <div>
            <h3>Menores de Edad Fiscalizados</h3>
            <p class="stat-number">312</p>
          </div>
        </div>
      </section>

      <section class="work-panel">
        <div class="panel-header">
          <div>
            <h2 v-if="vistaActual === 'control'">Control de Identidad y Frontera</h2>
            <h2 v-else>Búsqueda Avanzada de Pasajeros</h2>
            <p class="panel-subtitle">Microservicio de Migración</p>
          </div>
          <button @click="obtenerMigracion" class="btn-primary" :disabled="isLoading">
            <span v-if="isLoading">🔄 Verificando...</span>
            <span v-else>🔄 Sincronizar Pasajeros</span>
          </button>
        </div>

        <div v-if="vistaActual === 'consultas' && !isLoading && !errorApi" class="panel-busqueda">
          <div class="busqueda-controles">
            <select v-model="criterioBusqueda" class="input-busqueda">
              <option value="todos">Todos los campos</option>
              <option value="nombre">Nombre</option>
              <option value="documento">Documento de Identidad</option>
              <option value="patente">Patente del Vehículo</option>
              <option value="resolucion">Resolución</option>

            </select>
            
            <input 
              type="text" 
              v-model="terminoBusqueda" 
              placeholder="Escriba para filtrar la tabla al instante..." 
              class="input-busqueda input-texto"
            />
          </div>
        </div>

        <div v-if="isLoading" class="loading-state">
          <div class="spinner"></div>
          <p>Consultando bases de datos de Policía Internacional...</p>
        </div>
        
        <div v-else-if="errorApi" class="error-state">
          <div class="error-icon">⚠️</div>
          <p>{{ errorApi }}</p>
          <button @click="obtenerMigracion" class="btn-retry">Reintentar Conexión</button>
        </div>

        <div v-else class="table-responsive">
          <table class="data-table">
            <thead>
              <tr>
                <th>Documento / Nombre</th>
                <th>Nacionalidad</th>
                <th>Fecha Nacimiento</th>
                <th>Vehículo Asociado</th>
                <th>Control Menores (Ley 21.325)</th>
                <th>Resolución</th>
                <th class="text-center">Acción</th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="item in pasajerosFiltrados" :key="item.id" class="table-row">
                
                <td>
                  <div class="person-info">
                    <span class="person-name">{{ item.nombresCompletos }}</span>
                    <span class="person-doc">ID: {{ item.documentoIdentidad }}</span>
                  </div>
                </td>

                <td>
                  <span class="country-badge">{{ item.nacionalidad }}</span>
                </td>
                
                <td>
                  <div class="dob-info">
                    <span class="dob-date">{{ item.fechaNacimiento }}</span>
                    <span v-if="item.menorDeEdad" class="minor-alert">MENOR DE EDAD</span>
                  </div>
                </td>
                
                <td>
                  <span class="plate-text">{{ item.patenteVehiculoAsociado }}</span>
                </td>
                
                <td>
                  <span v-if="!item.menorDeEdad" class="minor-badge adult">
                    Adulto (No aplica)
                  </span>
                  
                  <span v-else-if="item.viajaConAmbosPadres" class="minor-badge ok">
                    👨‍👩‍👧 Viaja con ambos padres
                  </span>

                  <div v-else-if="item.folioPermisoNotarial" class="folio-box notarial">
                    <span class="folio-title">📜 Notarial</span>
                    <span class="folio-number">{{ item.folioPermisoNotarial }}</span>
                  </div>

                  <div v-else-if="item.folioJuzgadoFamilia" class="folio-box juzgado">
                    <span class="folio-title">⚖️ Juzgado Flia.</span>
                    <span class="folio-number">{{ item.folioJuzgadoFamilia }}</span>
                  </div>

                  <span v-else class="minor-badge danger">
                    🚫 FALTAN PERMISOS
                  </span>
                </td>
                
                <td>
                  <span :class="['status-pill', item.estado.toLowerCase()]">
                    <span class="led-dot"></span>
                    {{ item.estado }}
                  </span>
                </td>
                
                <td class="text-center">
                  <button class="btn-action-inspect">
                    <span>Control</span>
                  </button>
                </td>
              </tr>
              
              <tr v-if="pasajerosFiltrados.length === 0">
                <td colspan="7" class="empty-state">
                  <span v-if="vistaActual === 'consultas'">🔍 No se encontraron pasajeros con los criterios de búsqueda actuales.</span>
                  <span v-else>📭 No hay pasajeros en espera de control migratorio.</span>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </section>
    </main>
  </div>
  <div v-if="mostrarModalRegistro" class="modal-overlay">
    <div class="modal-card">
      <div class="modal-header">
        <h2>Registro de Pasajero - PDI</h2>
        <button class="btn-close" @click="cerrarModal">✖</button>
      </div>

      <form @submit.prevent="registrarPasajero" class="modal-form">
        <div class="form-row">
          <div class="form-group">
            <label>Nombres Completos *</label>
            <input type="text" v-model="formRegistro.nombres_completos" required />
          </div>
          <div class="form-group">
            <label>Documento de Identidad *</label>
            <input type="text" v-model="formRegistro.documento_identidad" required />
          </div>
        </div>

        <div class="form-row">
          <div class="form-group">
            <label>Fecha de Nacimiento *</label>
            <input type="date" v-model="formRegistro.fecha_nacimiento" required />
          </div>
          <div class="form-group">
            <label>Nacionalidad *</label>
            <input type="text" v-model="formRegistro.nacionalidad" required />
          </div>
        </div>

        <div class="form-row">
          <div class="form-group">
            <label>Vehículo Asociado (Patente) *</label>
            <input type="text" v-model="formRegistro.patente_vehiculo_asociado" maxlength="10" required />
          </div>
        </div>

        <div v-if="esMenorDeEdad" class="minor-section">
        <div class="form-group checkbox-group">
          <label>
            <input type="checkbox" v-model="formRegistro.viaja_con_ambos_padres" />
            ¿El menor viaja con ambos padres?
          </label>
        </div>

        <div class="form-row" v-if="!formRegistro.viaja_con_ambos_padres">
          <div class="form-group">
            <label>Folio Juzgado de Familia</label>
            <input type="text" v-model="formRegistro.folio_juzgado_familia" placeholder="Ej: JUZ-1234" />
          </div>
          <div class="form-group">
            <label>Folio Permiso Notarial</label>
            <input type="text" v-model="formRegistro.folio_permiso_notarial" placeholder="Ej: NOT-5678" />
          </div>
        </div>
      </div>

        <div class="modal-actions">
          <button type="button" class="btn-cancel" @click="cerrarModal">Cancelar</button>
          <button type="submit" class="btn-submit" :disabled="isSubmitting">
            {{ isSubmitting ? 'Guardando...' : 'Registrar Pasajero' }}
          </button>
        </div>
      </form>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted, computed } from 'vue';
import { useRouter } from 'vue-router';

const router = useRouter();
const officerRut = ref('Cargando...');
const currentDate = ref(new Date().toLocaleDateString('es-CL', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' }));

const listaPasajeros = ref([]);
const isLoading = ref(true);
const errorApi = ref(null);
const mostrarModalRegistro = ref(false);
const isSubmitting = ref(false);

  // 1. Control de vistas del menú
const vistaActual = ref('control'); // 'control' o 'consultas'

// 2. Variables para el buscador
const terminoBusqueda = ref('');
const criterioBusqueda = ref('todos');

const parseJwt = (token) => {
  try {
    const base64Url = token.split('.')[1];
    const base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
    return JSON.parse(window.atob(base64));
  } catch (e) {
    return null;
  }
};

const obtenerMigracion = async () => {
  isLoading.value = true;
  errorApi.value = null;
  try {
    const token = localStorage.getItem('user_token');
    
    // 🚧 CAMBIA ESTE PUERTO AL QUE USE TU MICROSERVICIO PDI (ej: 9094)
    const response = await fetch('http://localhost:9093/api/v1/migracion', {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}` 
      }
    });

    if (!response.ok) {
      throw new Error(`Error en el servidor: ${response.status}`);
    }

    const data = await response.json();
    listaPasajeros.value = data;
  } catch (err) {
    console.error("Error al conectar con PDI:", err);
    errorApi.value = "No se pudo enlazar con la base de datos de Policía Internacional.";
  } finally {
    isLoading.value = false;
  }
};

// Objeto para atrapar los datos del formulario
const formRegistro = ref({
  nombres_completos: '',
  documento_identidad: '',
  fecha_nacimiento: '',
  nacionalidad: '',
  patente_vehiculo_asociado: '',
  viaja_con_ambos_padres: false,
  folio_juzgado_familia: '',
  folio_permiso_notarial: ''
});
// 🧮 Calculadora automática de edad
const esMenorDeEdad = computed(() => {
  if (!formRegistro.value.fecha_nacimiento) return false;

  const fechaNac = new Date(formRegistro.value.fecha_nacimiento);
  const hoy = new Date();
  
  let edad = hoy.getFullYear() - fechaNac.getFullYear();
  const mes = hoy.getMonth() - fechaNac.getMonth();

  // Si aún no ha pasado su mes de cumpleaños, o es el mes pero no ha llegado el día, restamos 1 año
  if (mes < 0 || (mes === 0 && hoy.getDate() < fechaNac.getDate())) {
    edad--;
  }

  return edad < 18;
});

// Función para cerrar el modal y limpiar los datos
const cerrarModal = () => {
  mostrarModalRegistro.value = false;
  formRegistro.value = {
    nombres_completos: '',
    documento_identidad: '',
    fecha_nacimiento: '',
    nacionalidad: '',
    patente_vehiculo_asociado: '',
    viaja_con_ambos_padres: false,
    folio_juzgado_familia: '',
    folio_permiso_notarial: ''
  };
};

// Función para registrar
const registrarPasajero = async () => {
  isSubmitting.value = true;

  const payload = {
    documentoIdentidad: formRegistro.value.documento_identidad,
    estado: "En revision", // ⬅️ Estado inyectado automáticamente
    fechaNacimiento: formRegistro.value.fecha_nacimiento,
    nacionalidad: formRegistro.value.nacionalidad,
    nombresCompletos: formRegistro.value.nombres_completos,
    patenteVehiculoAsociado: formRegistro.value.patente_vehiculo_asociado,
    viajaConAmbosPadres: (esMenorDeEdad.value && formRegistro.value.viajaConAmbosPadres) ? 1 : 0,
    folioJuzgadoFamilia: (esMenorDeEdad.value && !formRegistro.value.folioJuzgadoFamilia) ? formRegistro.value.folioJuzgadoFamilia || null : null,
    folioPermisoNotarial: (esMenorDeEdad.value && !formRegistro.value.folioPermisoNotarial) ? formRegistro.value.folioPermisoNotarial || null : null
  };

  try {
    const token = localStorage.getItem('user_token');
    
    // Recuerda verificar tu puerto (aquí asumo 9093 como en mensajes anteriores)
    const response = await fetch('http://localhost:9093/api/v1/migracion/pasajero', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      },
      body: JSON.stringify(payload)
    });

    if (!response.ok) throw new Error('Error en el registro');

    alert("✅ ingresado para revision");
    
    cerrarModal(); // Cierra el modal y limpia el formulario
    
    // Opcional: Si tienes una función para recargar la tabla principal (ej: cargarPasajeros()), llámala aquí.

  } catch (error) {
    console.error(error);
    alert("⚠️ Error al registrar el pasajero.");
  } finally {
    isSubmitting.value = false;
  }
};


// 2. Extrae el RUT del token para mostrarlo en el menú
  const token = localStorage.getItem('user_token');
  if (token) {
    const datosUsuario = parseJwt(token);
    
    // Aquí actualizamos la variable. 
    // Nota: Dependiendo de cómo programaste tu backend, el RUT podría llamarse 'rut', 'sub' o 'id' dentro del token.
    if (datosUsuario) {
      officerRut.value = datosUsuario.rut || datosUsuario.sub || 'RUT no encontrado';
    } else {
      officerRut.value = 'Error al leer credencial';
    }
  } else {
    officerRut.value = 'No autenticado';
  }


// 3. 🧲 Filtro Mágico (Reemplazará a listaPasajeros en tu HTML)
const pasajerosFiltrados = computed(() => {
  // Si no hay texto en el buscador, mostramos toda la lista
  if (!terminoBusqueda.value) return listaPasajeros.value;

  const texto = terminoBusqueda.value.toLowerCase();

  return listaPasajeros.value.filter(pasajero => {
    // Si el usuario seleccionó un filtro específico
    if (criterioBusqueda.value === 'nombre') return pasajero.nombresCompletos?.toLowerCase().includes(texto);
    if (criterioBusqueda.value === 'documento') return pasajero.documentoIdentidad?.toLowerCase().includes(texto);
    if (criterioBusqueda.value === 'patente') return pasajero.patenteVehiculoAsociado?.toLowerCase().includes(texto);
    if (criterioBusqueda.value === 'resolucion') return pasajero.estado?.toLowerCase().includes(texto);
    // Si está en 'todos', busca coincidencias en cualquiera de los 3 campos principales
    return (
      pasajero.nombresCompletos?.toLowerCase().includes(texto) ||
      pasajero.documentoIdentidad?.toLowerCase().includes(texto) ||
      pasajero.patenteVehiculoAsociado?.toLowerCase().includes(texto)||
      pasajero.estado?.toLowerCase().includes(texto)
    );
  });
});

// Función opcional para limpiar el buscador al cambiar de pestaña
const cambiarVista = (vista) => {
  vistaActual.value = vista;
  terminoBusqueda.value = ''; 
  criterioBusqueda.value = 'todos';
};

onMounted(() => {
  obtenerMigracion();
  // ... (tu código del token)
});


const handleLogout = () => {
  localStorage.clear();
  router.push('/');
};
</script>

<style scoped>
/* 🌍 Layout General */
.dashboard-container {
  display: flex; height: 100vh; width: 100vw; background-color: #f0f4f8;
  font-family: 'Segoe UI', system-ui, -apple-system, sans-serif; position: fixed; top: 0; left: 0;
}

/* 🛂 Sidebar PDI (Azul PDI muy oscuro) */
.sidebar {
  width: 260px; background-color: #08377e; color: #ecf0f1; display: flex; flex-direction: column;
  justify-content: space-between; padding: 24px; box-shadow: 4px 0 15px rgba(0,0,0,0.1);
}
.brand-logo-card {
  display: flex;
  flex-direction: column;
  align-items: center;
  width: 100%;
  margin-bottom: 10px; /* Da espacio antes de que empiece el menú */
}

.logo-img {
  width: 100%;
  max-width: 160px; /* ⬅️ Esto evita que el logo se vea gigante */
  height: auto;
  object-fit: contain;
}

.logo-divider {
  width: 100%;
  height: 1px;
  background-color: rgba(255, 255, 255, 0.15); /* Línea blanca semitransparente */
  margin: 16px 0 12px 0;
}

.logo-subtitle {
  font-size: 0.75rem;
  font-weight: 600;
  color: #ecf0f1; /* Blanco hueso para contrastar con el fondo azul */
  text-align: center;
  text-transform: uppercase;
  letter-spacing: 1px;
  margin: 0;
}
.menu { display: flex; flex-direction: column; gap: 8px; margin-top: 40px; flex-grow: 1; }
.menu-item {
  background: none; border: none; color: #8fa0b3; text-align: left; padding: 12px 16px; border-radius: 8px;
  cursor: pointer; font-size: 0.95rem; font-weight: 500; transition: all 0.2s ease; display: flex; align-items: center; gap: 10px;
}

/* Estilos para el menú activo */
.menu-item.activo {
  background-color: #1a4a98; /* Un azul un poco más claro que el fondo */
  color: #ffffff;
  font-weight: 700;
  border-left: 4px solid #f1c40f; /* Línea amarilla PDI al costado */
}

/* Estilos para el panel de búsqueda */
.panel-busqueda {
  background-color: #f8fafc;
  padding: 16px 20px;
  border-radius: 8px;
  border: 1px solid #e2e8f0;
  margin-bottom: 20px;
}

.panel-busqueda h3 {
  margin: 0 0 12px 0;
  font-size: 1rem;
  color: #334155;
}

.busqueda-controles {
  display: flex;
  gap: 12px;
}

.input-busqueda {
  padding: 10px;
  border: 1px solid #cbd5e1;
  border-radius: 6px;
  font-size: 0.9rem;
  outline: none;
}

.input-busqueda:focus {
  border-color: #093b84;
}

.input-texto {
  flex-grow: 1; /* Hace que el buscador de texto ocupe todo el espacio disponible */
}

.sin-resultados {
  text-align: center;
  padding: 30px;
  color: #64748b;
  font-style: italic;
}

.menu-item:hover, .menu-item.active { background-color: #003366; color: #fff; }
.menu-item.active { border-left: 4px solid #3498db; }
.sidebar-footer { border-top: 1px solid #003366; padding-top: 20px; }
.user-name { font-weight: 600; margin: 0; font-size: 1.2rem;}
.user-rut { font-size: 0.8rem; color: #ffffff; margin: 2px 0 15px 0; font-family: monospace; }
.btn-logout { width: 100%; background-color: #34495e; color: white; border: 1px solid #455a64; padding: 10px; border-radius: 6px; cursor: pointer; font-weight: 600; transition: background 0.2s; }
.btn-logout:hover { background-color: #c0392b; border-color: #c0392b; }

/* 🖥️ Main Content */
.main-content { flex-grow: 1; padding: 40px; overflow-y: auto; }
.content-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 30px; }
.content-header h1 { margin: 0 0 5px 0; color: #003366; font-size: 1.7rem; font-weight: 800; }
.content-header p { margin: 0; color: #576574; font-size: 0.95rem; }
.date-badge { background-color: #ffffff; padding: 10px 18px; border-radius: 30px; box-shadow: 0 2px 6px rgba(0,0,0,0.03); font-size: 0.85rem; font-weight: 600; color: #2c3e50; }

/* 📊 Stats Grid */
.stats-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 24px; margin-bottom: 35px; }
.stat-card { background: white; padding: 24px; border-radius: 16px; box-shadow: 0 4px 12px rgba(0,0,0,0.03); display: flex; align-items: center; gap: 20px; }
.stat-icon { width: 48px; height: 48px; border-radius: 12px; display: flex; align-items: center; justify-content: center; font-size: 1.4rem; }
.stat-icon.blue { background-color: #e0f2fe; }
.stat-icon.red { background-color: #fee2e2; }
.stat-icon.orange { background-color: #ffedd5; }
.stat-number { font-size: 1.8rem; font-weight: 700; margin: 4px 0 0 0; color: #001f3f; }
.stat-card h3 { margin: 0; font-size: 0.8rem; color: #576574; text-transform: uppercase; font-weight: 700;}

/* 🛂 Panel Principal */
.work-panel { background: white; padding: 30px; border-radius: 16px; box-shadow: 0 4px 20px rgba(0,0,0,0.03); }
.panel-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 25px; }
.panel-header h2 { margin: 0; font-size: 1.3rem; color: #001f3f; font-weight: 800; }
.panel-subtitle { margin: 2px 0 0 0; font-size: 0.85rem; color: #8395a7; }

.btn-primary { background: linear-gradient(135deg, #001f3f 0%, #003366 100%); color: white; border: none; padding: 12px 20px; border-radius: 8px; cursor: pointer; font-weight: 600; }
.btn-primary:active { transform: scale(0.98); }

/* 📋 Tabla PDI */
.table-responsive { overflow-x: auto; }
.data-table { width: 100%; border-collapse: separate; border-spacing: 0 10px; text-align: left; }
.data-table th { padding: 12px 16px; color: #576574; font-size: 0.75rem; font-weight: 800; text-transform: uppercase; border-bottom: 1px solid #e2e8f0; }
.table-row { background-color: #ffffff; transition: all 0.2s ease; border: 1px solid transparent;}
.table-row:hover { background-color: #f8fafc; transform: translateY(-2px); box-shadow: 0 4px 12px rgba(0,0,0,0.04); }
.table-row td { padding: 14px 16px; border-top: 1px solid #e2e8f0; border-bottom: 1px solid #e2e8f0; font-size: 0.9rem; vertical-align: middle; }
.table-row td:first-child { border-left: 1px solid #e2e8f0; border-top-left-radius: 8px; border-bottom-left-radius: 8px; }
.table-row td:last-child { border-right: 1px solid #e2e8f0; border-top-right-radius: 8px; border-bottom-right-radius: 8px; }

/* Persona */
.person-info { display: flex; flex-direction: column; }
.person-name { font-weight: 700; color: #001f3f; font-size: 0.95rem;}
.person-doc { font-size: 0.8rem; color: #576574; font-family: monospace; background: #f1f2f6; padding: 2px 6px; border-radius: 4px; width: max-content; margin-top: 4px;}

/* Nacionalidad y Patente */
.country-badge { font-weight: 600; color: #34495e; }
.plate-text { font-family: 'Consolas', monospace; font-weight: 700; border: 1px solid #bdc3c7; padding: 2px 6px; border-radius: 4px; background: #fff;}

/* Nacimiento y Alerta Menor */
.dob-info { display: flex; flex-direction: column; gap: px; }
.dob-date { color: #2c3e50; font-weight: 500;}
.minor-alert { background-color: #ffebd2; color: #d35400; font-size: 0.65rem; font-weight: 800; padding: 2px 6px; border-radius: 4px; width: max-content; }

/* 👶 Control de Menores Badges */
.minor-badge { font-size: 0.75rem; font-weight: 700; padding: 4px 8px; border-radius: 6px; display: inline-block;}
.minor-badge.adult { background-color: #f1f2f6; color: #7f8c8d; }
.minor-badge.ok { background-color: #dcfce7; color: #16a34a; }
.minor-badge.danger { background-color: #fee2e2; color: #c0392b; font-weight: 800;}

/* Folios Notariales / Juzgado */
.folio-box { display: inline-flex; flex-direction: column; border: 1px solid #e2e8f0; border-radius: 6px; overflow: hidden; }
.folio-title { font-size: 0.65rem; font-weight: 800; padding: 2px 6px; color: white; }
.folio-number { font-size: 0.75rem; font-family: monospace; padding: 2px 6px; background: white; font-weight: 600; color: #2c3e50;}
.folio-box.notarial { border-color: #3498db; }
.folio-box.notarial .folio-title { background-color: #3498db; }
.folio-box.juzgado { border-color: #9b59b6; }
.folio-box.juzgado .folio-title { background-color: #9b59b6; }

/* 🟢 Pill de Estados */
.status-pill { display: inline-flex; align-items: center; gap: 6px; padding: 6px 14px; border-radius: 50px; font-size: 0.75rem; font-weight: 800; text-transform: uppercase; }
.status-pill .led-dot { width: 8px; height: 8px; border-radius: 50%; display: inline-block; }

.status-pill.aprobado { background-color: #dcfce7; color: #15803d; }
.status-pill.aprobado .led-dot { background-color: #22c55e; box-shadow: 0 0 8px #22c55e; }
.status-pill.retenido { background-color: #fee2e2; color: #b91c1c; }
.status-pill.retenido .led-dot { background-color: #ef4444; box-shadow: 0 0 8px #ef4444; }
.status-pill.pendiente { background-color: #fee2e2; color: #eb8d22; }
.status-pill.pendiente .led-dot { background-color: #dc742f; box-shadow: 0 0 8px #dc742f; }

/* Botones */
.btn-action-inspect { background-color: #f1f5f9; border: 1px solid #cbd5e1; color: #001f3f; padding: 6px 16px; border-radius: 6px; font-weight: 700; cursor: pointer; transition: all 0.2s; }
.btn-action-inspect:hover { background-color: #001f3f; color: #ffffff; border-color: #001f3f;}
.btn-retry { background-color: #e74c3c; color: white; border: none; padding: 8px 15px; border-radius: 4px; cursor: pointer; margin-top: 10px; }

.pdi-actions-footer {
  margin-top: 40px;
  display: flex;
  justify-content: center;
}
.btn-registrar-pasajero {
  background-color: #003366; /* Azul PDI */
  color: white;
  padding: 16px 32px;
  border-radius: 6px;
  font-weight: bold;
  border: none;
  cursor: pointer;
  box-shadow: 0 4px 6px rgba(0,0,0,0.1);
}
.btn-registrar-pasajero:hover { background-color: #002244; }

/* =========================================================
   ESTILOS DEL MODAL DE REGISTRO
========================================================= */
.modal-overlay {
  position: fixed;
  top: 0;
  left: 0;
  width: 100vw;
  height: 100vh;
  background-color: rgba(0, 31, 63, 0.8); /* Fondo azul oscuro semitransparente */
  display: flex;
  justify-content: center;
  align-items: center;
  z-index: 9999;
}

.modal-card {
  background: white;
  width: 100%;
  max-width: 650px;
  border-radius: 8px;
  box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
  overflow: hidden;
  max-height: 90vh; /* Para pantallas pequeñas */
  overflow-y: auto; 
}

.modal-header {
  background-color: #093b84; /* Azul PDI exacto */
  color: white;
  padding: 16px 24px;
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.modal-header h2 { margin: 0; font-size: 1.2rem; }

.btn-close {
  background: none;
  border: none;
  color: white;
  font-size: 1.2rem;
  cursor: pointer;
}

.modal-form {
  padding: 24px;
  display: flex;
  flex-direction: column;
  gap: 16px;
}

.form-row {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 16px;
}

.form-group {
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.form-group label {
  font-size: 0.85rem;
  font-weight: 600;
  color: #334155;
}

.form-group input {
  padding: 10px;
  border: 1px solid #cbd5e1;
  border-radius: 6px;
  font-size: 0.9rem;
}

.checkbox-group {
  background-color: #f8fafc;
  padding: 12px;
  border-radius: 6px;
  border: 1px solid #e2e8f0;
}

.modal-actions {
  display: flex;
  justify-content: flex-end;
  gap: 10px;
  margin-top: 10px;
  padding-top: 16px;
  border-top: 1px solid #e2e8f0;
}

.btn-cancel {
  background: #f1f5f9;
  border: 1px solid #cbd5e1;
  padding: 10px 20px;
  border-radius: 6px;
  cursor: pointer;
  color: #475569;
}

.btn-submit {
  background: #093b84;
  color: white;
  border: none;
  padding: 10px 24px;
  border-radius: 6px;
  font-weight: 600;
  cursor: pointer;
}
.btn-submit:disabled { background: #94a3b8; }
/* Spinner */
.loading-state, .error-state, .empty-state { text-align: center; padding: 50px; color: #64748b; }
.spinner { border: 3px solid #f3f3f3; border-top: 3px solid #001f3f; border-radius: 50%; width: 30px; height: 30px; animation: spin 1s linear infinite; margin: 0 auto 15px auto; }
@keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }
</style>