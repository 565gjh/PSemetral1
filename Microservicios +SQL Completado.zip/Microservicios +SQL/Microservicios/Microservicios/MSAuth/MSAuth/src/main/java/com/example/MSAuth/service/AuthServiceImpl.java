package com.example.MSAuth.service;

import com.example.MSAuth.dto.LoginRequestDto;
import com.example.MSAuth.exception.ResourceNotFoundException;
import com.example.MSAuth.model.Usuario;
import com.example.MSAuth.repository.UsuarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.UUID;

@Service
public class AuthServiceImpl implements AuthService {

    @Autowired
    private UsuarioRepository usuarioRepository;

    @Override
    public LoginRequestDto login(LoginRequestDto loginDto) {
        Usuario usuario = usuarioRepository.findByUsername(loginDto.getUsername())
                .orElseThrow(() -> new ResourceNotFoundException("Credenciales incorrectas. Usuario no encontrado."));

        if (usuario.getPassword().equals(loginDto.getPassword())) {
            String tokenGenerado = UUID.randomUUID().toString().replace("-", "");
            return new LoginRequestDto(tokenGenerado, usuario.getUsername());
        } else {
            throw new ResourceNotFoundException("Credenciales incorrectas. Contraseña inválida.");
        }
    }
}