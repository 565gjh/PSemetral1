package com.example.MSAuth.service;

import com.example.MSAuth.dto.LoginRequestDto;

public interface AuthService {
    LoginRequestDto login(LoginRequestDto loginDto);
}