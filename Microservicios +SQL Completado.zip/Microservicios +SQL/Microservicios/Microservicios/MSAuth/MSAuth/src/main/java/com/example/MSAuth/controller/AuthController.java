package com.example.MSAuth.controller;

import com.example.MSAuth.dto.LoginRequestDto;
import com.example.MSAuth.service.AuthService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/auth")
public class AuthController {

    @Autowired
    private AuthService authService;

    @PostMapping("/login")
    public ResponseEntity<LoginRequestDto> autenticarUsuario(@Valid @RequestBody LoginRequestDto loginRequest) {
        LoginRequestDto response = authService.login(loginRequest);
        return ResponseEntity.ok(response);
    }
}