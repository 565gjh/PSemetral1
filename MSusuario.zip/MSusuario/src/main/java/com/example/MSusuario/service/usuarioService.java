package com.example.MSusuario.service;

import com.example.MSusuario.model.Usuario;
import com.example.MSusuario.repository.usuarioRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
@Slf4j
public class usuarioService {
    @Autowired
    private usuarioRepository repository;


    public List<Usuario> findAll() {
        log.info("Obteniendo lista de todos los usuarios.");
        return repository.findAll();
    }

    public Usuario findById(Long id) {
        log.info("buscando usuario por id.");
        return repository.findById(id).get();
    }

    public Usuario save(Usuario usuario) {
        log.info("Guardando el usuario.");
        return repository.save(usuario);
    }
    public void delete(Long id){
        log.info("eliminando al usuario seleccionado.");
        repository.deleteById(id);
    }
}



